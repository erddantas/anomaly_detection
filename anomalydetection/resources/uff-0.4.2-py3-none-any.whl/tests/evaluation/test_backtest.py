#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from typing import List

import numpy as np
import pandas as pd
import pytest

from uff import TimeIndexedData
from uff.base import Estimator, Forecaster, InitializationSpec, Transformer
from uff.evaluation.backtest import BackTester

from ..mocks import create_assertive_estimator


def t(i: int) -> pd.Timestamp:
    if i < 0:
        return pd.Timestamp("2022-01-01")
    elif i > 30:
        return pd.Timestamp("2022-02-01")
    else:
        return pd.Timestamp(f"2022-1-{i + 1}")


def _january_data():
    ts = [f"2022-01-{x}" for x in range(1, 32)]
    v = np.arange(31)
    return TimeIndexedData(ts, v, granularity="D")


def _january_data_with_missing():
    data = _january_data()
    mask = np.ones(len(data), dtype=bool)
    mask[[13, 15, 18, 19]] = False
    return data.mask(mask)


def _estimator_combinations(assert_in_sample: bool = False) -> List[Estimator]:
    return [
        InitializationSpec(create_assertive_estimator(mixin, assert_in_sample=assert_in_sample))
        for mixin in (Forecaster, Transformer)
    ]


@pytest.mark.parametrize("data", [_january_data(), _january_data_with_missing()])
@pytest.mark.parametrize("step_size", [1, 3, 5])
@pytest.mark.parametrize("min_fit_window_size", [1, 10])
@pytest.mark.parametrize("fit_window_type", ["rolling", "expanding"])
@pytest.mark.parametrize("estimator", _estimator_combinations())
def test_data_leakage(data, step_size, min_fit_window_size, fit_window_type, estimator):
    tester = BackTester(
        data=data,
        step_size=step_size,
        min_fit_window_size=min_fit_window_size,
        fit_window_type=fit_window_type,
    )
    for res in tester.evaluate(estimator):
        if len(res.fit_data) > 0 and len(res.eval_data) > 0:
            assert res.fit_data.strictly_before(res.eval_data)


@pytest.mark.parametrize("data", [_january_data()])
@pytest.mark.parametrize("step_size", [1, 3, 5])
@pytest.mark.parametrize("min_fit_window_size", [1, 10])
@pytest.mark.parametrize("fit_window_type", ["rolling", "expanding"])
@pytest.mark.parametrize("estimator", _estimator_combinations())
def test_window_sizes(data, step_size, min_fit_window_size, fit_window_type, estimator):
    tester = BackTester(
        data=data,
        step_size=step_size,
        min_fit_window_size=min_fit_window_size,
        fit_window_type=fit_window_type,
    )
    for res in tester.evaluate(estimator):
        assert len(res.fit_data) >= tester._min_fit_window_size
        assert len(res.eval_data) == tester._evaluation_window_size


@pytest.mark.parametrize("data", [_january_data_with_missing()])
@pytest.mark.parametrize("step_size", [1, 3, 5])
@pytest.mark.parametrize("min_fit_window_size", [1, 10])
@pytest.mark.parametrize("fit_window_type", ["rolling", "expanding"])
@pytest.mark.parametrize("estimator", _estimator_combinations())
def test_window_size_samples(data, step_size, min_fit_window_size, fit_window_type, estimator):
    tester = BackTester(
        data=data,
        step_size=step_size,
        min_fit_window_size=min_fit_window_size,
        fit_window_type=fit_window_type,
        step_mode="samples",
    )
    for res in tester.evaluate(estimator):
        assert len(res.fit_data) >= tester._min_fit_window_size
        assert len(res.eval_data) == tester._evaluation_window_size


@pytest.mark.parametrize("data", [_january_data_with_missing()])
@pytest.mark.parametrize("step_size", [1, 3, 5])
@pytest.mark.parametrize("step_mode", ["time", "samples"])
@pytest.mark.parametrize("estimator", _estimator_combinations())
def test_fit_zero(data, step_size, step_mode, estimator):
    tester = BackTester(
        data=data,
        step_size=step_size,
        step_mode=step_mode,
    )
    assert min(len(res.fit_data) for res in tester.evaluate(estimator)) == 0


def test_bad_input():
    bad_input = [
        {"step_size": -1},
        {"min_fit_window_size": -1},
        {"min_fit_window_size": 0, "fit_window_type": "rolling"},
        {"fit_window_type": "some random string"},
        {"step_mode": "some random string"},
        {"evaluation_window_size": 0},
        {"min_fit_window_size": 10, "fit_window_type": "rolling", "evaluation_window_size": -14},
    ]
    for kwargs in bad_input:
        with pytest.raises(ValueError):
            BackTester(_january_data(), **kwargs)


@pytest.mark.parametrize("data", [_january_data()])
@pytest.mark.parametrize("step_size", [1, 3, 5])
def test_expanding_training_window(data, step_size):
    tester = BackTester(data=data, step_size=step_size, fit_window_type="expanding")
    windows = tester._get_time_slice_pairs()
    expected = [
        (pd.Timestamp("2022-01-01"), t(i))
        for i in range(0, 31, tester._step_size)
        if i <= 31 - tester._step_size
    ]
    assert [w.fit for w in windows] == expected


@pytest.mark.parametrize("data", [_january_data()])
@pytest.mark.parametrize("step_size", [1, 3, 5])
def test_rolling_training_window(data, step_size):
    tester = BackTester(
        data=data, step_size=step_size, min_fit_window_size=3, fit_window_type="rolling"
    )
    first_train_end = int(np.ceil(3 / tester._step_size)) * tester._step_size
    expected = [
        (t(i - 3), t(i))
        for i in range(first_train_end, 31, tester._step_size)
        if i + tester._evaluation_window_size <= 31
    ]
    assert [s.fit for s in tester._slices] == expected


@pytest.mark.parametrize("data", [_january_data(), _january_data_with_missing()])
@pytest.mark.parametrize("step_size", [1, 3, 5])
@pytest.mark.parametrize("min_fit_window_size", [0, 3, 15])
@pytest.mark.parametrize("evaluation_window_size", [-3, 3])
def test_evaluation_windows(data, step_size, min_fit_window_size, evaluation_window_size):
    tester = BackTester(
        data=data,
        step_size=step_size,
        min_fit_window_size=min_fit_window_size,
        evaluation_window_size=evaluation_window_size,
    )
    first_train_end = (
        int(np.ceil(tester._min_fit_window_size / tester._step_size)) * tester._step_size
    )
    expected = []
    for train_end in range(first_train_end, 31, tester._step_size):
        e1, e2 = sorted((train_end, train_end + tester._evaluation_window_size))
        if 0 <= e1 < e2 <= 31:
            expected.append((t(e1), t(e2)))

    assert [s.evaluate for s in tester._slices] == expected


@pytest.mark.parametrize("step_size", [1, 3, 5])
@pytest.mark.parametrize("evaluation_window_size", [-3, 3])
@pytest.mark.parametrize("right_align", [False, True])
def test_alignment(step_size, evaluation_window_size, right_align):
    data = _january_data()
    max_t = data.future_time_index(1).pd_timestamp_index()[0]
    tester = BackTester(
        data=data,
        step_size=step_size,
        evaluation_window_size=evaluation_window_size,
        right_align=right_align,
    )
    if right_align:
        assert tester._slices[-1].evaluate[1] == max_t
        if tester._evaluation_window_size <= 0:
            assert tester._slices[-1].fit[1] == max_t
        else:
            assert tester._slices[-1].fit[1] == t(31 - tester._evaluation_window_size)
    else:
        assert tester._slices[0].fit[0] == t(0)


@pytest.mark.parametrize("estimator", _estimator_combinations())
def test_valid_estimator_data_flow(estimator):
    tester = BackTester(_january_data(), step_size=1)
    res = tester.evaluate(estimator)  # Fit all
    assert len(res) == 31

    res = tester.evaluate(estimator, max_evaluations=5)
    assert len(res) == 5

    res = tester.evaluate(estimator, max_evaluations=5, most_recent_first=True)
    assert len(res) == 5

    tester.score_results(res, lambda x: 10.0)


def test_string_metric():
    tester = BackTester(_january_data(), step_size=7)
    estimator = InitializationSpec(create_assertive_estimator(Forecaster))
    res = tester.evaluate(estimator)

    tester.score_results(res, "mse")  # Injected
    tester.score_results(res, "smape")  # UFF
    tester.score_results(res, "r2")  # Sklearn


@pytest.mark.parametrize("estimator", _estimator_combinations(assert_in_sample=True))
def test_in_sample(estimator):
    tester = BackTester(_january_data(), step_size=1)
    res = tester.evaluate(estimator, in_sample=True)
    assert len(res) == 31


@pytest.mark.parametrize("estimator", _estimator_combinations(assert_in_sample=True))
def test_in_sample_bad_input(estimator):
    tester = BackTester(_january_data(), step_size=1)
    with pytest.raises(AssertionError):
        tester.evaluate(estimator, in_sample=False)
