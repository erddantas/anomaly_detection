#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from typing import Union

import numpy as np
import pandas as pd
from hyperopt import Trials, hp

from uff import TimeIndexedData
from uff.base import Forecaster, InitializationSpec
from uff.evaluation.hyperopt import HyperoptTuner, _to_dict
from uff.forecasters.arima import ArimaForecaster
from uff.meta import ColumnEnsembleEstimator

from ..mocks import create_assertive_estimator


def _same_list(l1: Union[list, tuple], l2: list) -> bool:
    """Compare two lists that could be nested"""
    if type(l1) != type(l2):
        return False
    if len(l1) != len(l2):
        return False
    for i in range(len(l2)):
        if isinstance(l1[i], list) and isinstance(l2[i], list):
            if not _same_list(l1[i], l2[i]):
                return False
        else:
            if l1[i] != l2[i]:
                return False
    return True


def test_hyperopt_simple_e2e():
    t = np.arange(28)

    # Stationary time series with weekly seasonality
    data = TimeIndexedData(t, np.sin(2 * np.pi * t / 7), unixtime_unit=pd.Timedelta(days=1))

    obj = HyperoptTuner(data=data)

    best, trials = obj.run(
        loss="mean_squared_error",
        reduce=np.max,
        models=[
            ArimaForecaster.search_space(
                ar_order=hp.choice("ar_order", [1, 2, 3]),
            ),
        ],
        max_evals=1,
    )
    assert isinstance(best, ArimaForecaster)
    assert isinstance(trials, Trials)


def test_sanitize():
    """https://github.com/hyperopt/hyperopt/issues/526"""
    t = np.arange(2)
    data = TimeIndexedData(t, np.zeros(2), unixtime_unit=pd.Timedelta(days=1))
    estimator_cls = create_assertive_estimator(Forecaster)
    obj = HyperoptTuner(data=data)
    args = [[1, 2], [3, 4]]
    kwargs = {"a": [1, 2]}
    best, _ = obj.run(
        loss="mean_squared_error",
        models=[
            estimator_cls.search_space(
                args,
                dict_arg=kwargs,
            ),
        ],
        max_evals=1,
    )
    assert _same_list(best.args[0], args)
    assert _same_list(best.kwargs["dict_arg"]["a"], kwargs["a"])


def test_to_dict():
    model = InitializationSpec(
        ColumnEnsembleEstimator,
        InitializationSpec(ArimaForecaster, 2),
        column_specific_estimators={"y0": InitializationSpec(ArimaForecaster, 3, periodicity=7)},
    )

    assert _to_dict(model) == {
        "cls": ColumnEnsembleEstimator,
        "args": (
            {
                "cls": ArimaForecaster,
                "args": (2,),
                "kwargs": {},
            },
        ),
        "kwargs": {
            "column_specific_estimators": {
                "y0": {
                    "cls": ArimaForecaster,
                    "args": (3,),
                    "kwargs": {"periodicity": 7},
                }
            },
        },
    }
