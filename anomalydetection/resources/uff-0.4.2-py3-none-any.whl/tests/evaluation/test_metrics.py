#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import numpy as np

from uff.evaluation.metrics import gmrae, mape, mase, mdrae, smape, wmape, wsmape


def test_mape():
    actual = np.array([1, 2, 1, 2])
    prediction = np.array([1, 4, 2, 4])
    assert mape(actual, prediction) == 0.75

    # with nan value
    actual = np.array([0, 0, 2, 2])
    prediction = np.array([0, 0, 2, 3])
    assert mape(actual, prediction) == 0.25


def test_smape():
    actual = np.array([1, 2, 1, 2])
    prediction = np.array([1, 4, 2, 4])
    assert smape(actual, prediction) == 0.5

    # with nan value
    actual = np.array([0, 0, 3, 2])
    prediction = np.array([0, 0, 2, 3])
    assert smape(actual, prediction) == 0.4


def test_wmape():
    actual = np.array([1, 4, 1, 4])
    prediction = np.array([1, 4, 2, 4])
    assert wmape(actual, prediction) == 0.1

    # with nan value
    actual = np.array([0, 0, 2, 2])
    prediction = np.array([0, 0, 2, 3])
    assert wmape(actual, prediction) == 0.25


def test_wsmape():
    actual = np.array([1, 4, 1, 4])
    prediction = np.array([1, 4, 3, 4])
    assert wsmape(actual, prediction) == 0.1

    # with nan value
    actual = np.array([0, 0, 2, 2])
    prediction = np.array([0, 0, 2, 3])
    assert wsmape(actual, prediction) == 0.2


def test_mdrae():
    actual = np.array([3, 4, 3, 4])
    prediction = np.array([4, 4, 4, 4])
    benchmark = np.array([2.5, 2.5, 2.5, 2.5])
    assert mdrae(actual, prediction, benchmark) == 1.0

    # with nan value
    actual = np.array([1, 2, 3, 4])
    prediction = np.array([1, 1, 2, 4])
    benchmark = np.array([1, 1, 1, 1])
    assert mdrae(actual, prediction, benchmark) == 0.5


def test_gmrae():
    actual = np.array([3, 3, 3, 3])
    prediction = np.array([4, 4, 4, 4])
    benchmark = np.array([2, 2, 2, 2])
    assert gmrae(actual, prediction, benchmark) == 1.0

    # with nan value
    actual = np.array([0, 0, 2, 2])
    prediction = np.array([0, 0, 2, 3])
    benchmark = np.array([0, 0, 0, 0])
    assert gmrae(actual, prediction, benchmark) == 0.5


def test_mase():
    actual = np.array([2, 3, 3, 4])
    prediction = np.array([3, 3, 2, 3])
    training = np.array([2, 3, 2, 3])
    assert mase(actual, prediction, training) == 0.75
