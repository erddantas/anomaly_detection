#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from typing import Tuple

import numpy as np
import pandas as pd
import pytest
from scipy.stats import randint, uniform

from uff import TimeIndexedData
from uff.base import Estimator, InitializationSpec
from uff.evaluation.tune import (
    Choice,
    Distribution,
    GridSearchTuner,
    Parameter,
    RandomSearchTuner,
    Ref,
    recursive_search,
)
from uff.forecasters.arima import ArimaForecaster
from uff.meta import ColumnEnsembleEstimator


class MyEstimator(Estimator):
    def __init__(self, a, b, c=None):
        self.a = a
        self.b = b
        self.c = c


def get_data():
    t = np.arange(28)
    return TimeIndexedData(t, np.sin(2 * np.pi * t / 7), unixtime_unit=pd.Timedelta(days=1))


def test_random_simple_e2e():
    data = get_data()
    obj = RandomSearchTuner(data=data)
    res = obj.run(
        loss="mean_squared_error",
        models=[
            ArimaForecaster.search_space(ar_order=Ref("ar_order")),
        ],
        parameters={"ar_order": Choice(1, 2, 3)},
        reduce=np.mean,
        n_trials=2,
    )
    assert isinstance(res.best, ArimaForecaster)
    assert res.best.init_kwargs["order"][0] in (1, 2, 3)


def test_random_nested_e2e():
    data = get_data()
    obj = RandomSearchTuner(data=data)
    res = obj.run(
        loss="mean_squared_error",
        models=[
            ColumnEnsembleEstimator.search_space(
                ArimaForecaster.search_space(ar_order=Ref("ar_order")),
            ),
        ],
        parameters={"ar_order": Choice(1, 2, 3)},
        reduce=np.mean,
        n_trials=2,
    )
    assert isinstance(res.best, ColumnEnsembleEstimator)
    assert res.best._default_estimator.init_kwargs["order"][0] in (1, 2, 3)


def test_random_nested_parameters():
    data = get_data()
    obj = RandomSearchTuner(data=data)
    res = obj.run(
        loss="mean_squared_error",
        models=[
            ColumnEnsembleEstimator.search_space(
                ArimaForecaster.search_space(ar_order=Ref("ar_order")),
            ),
        ],
        parameters={"ar_order": Choice(1, 2, Distribution(randint(3, 10)))},
        reduce=np.mean,
        n_trials=2,
    )
    assert isinstance(res.best, ColumnEnsembleEstimator)
    assert res.best._default_estimator.init_kwargs["order"][0] in (1, 2, 3, 4, 5, 6, 7, 8, 9)


def test_random_sample():
    grid = {"a": Choice(1, 4, 9), "b": Distribution(uniform(0, 4))}
    space = MyEstimator.search_space(a=Ref("a"), b=Ref("b"))
    for spec in [RandomSearchTuner._sample(space, grid) for _ in range(100)]:
        est = spec.create_instance()
        assert est.a in (1, 4, 9)
        assert 0 <= est.b <= 4


def test_random_sample_collection():
    grid = {"a": Choice(1, 4, 9), "b": Distribution(uniform(0, 4))}
    space = MyEstimator.search_space(a=Ref("a"), b=[1, Ref("b"), 2])
    for spec in [RandomSearchTuner._sample(space, grid) for _ in range(100)]:
        est = spec.create_instance()
        assert est.a in (1, 4, 9)
        assert est.b[0] == 1 and 0 <= est.b[1] <= 4 and est.b[2] == 2


def test_grid_search_basic():
    param_grid = {
        "p1": Choice(7, 12),
        "ar": Choice(1, 2, 3),
        "p2": Choice(8, 14),
    }
    models = [
        ArimaForecaster.search_space(
            ar_order=Ref("ar"),
            periodicity=Ref("p1"),
        ),
        ArimaForecaster.search_space(ar_order=17, periodicity=Ref("p2")),
    ]

    def sort_key(spec: InitializationSpec) -> Tuple[int, int]:
        return spec.kwargs["ar_order"], spec.kwargs["periodicity"]

    specs = sorted(GridSearchTuner(get_data()).generate_specs(models, param_grid), key=sort_key)
    assert specs == [
        InitializationSpec(ArimaForecaster, ar_order=1, periodicity=7),
        InitializationSpec(ArimaForecaster, ar_order=1, periodicity=12),
        InitializationSpec(ArimaForecaster, ar_order=2, periodicity=7),
        InitializationSpec(ArimaForecaster, ar_order=2, periodicity=12),
        InitializationSpec(ArimaForecaster, ar_order=3, periodicity=7),
        InitializationSpec(ArimaForecaster, ar_order=3, periodicity=12),
        InitializationSpec(ArimaForecaster, ar_order=17, periodicity=8),
        InitializationSpec(ArimaForecaster, ar_order=17, periodicity=14),
    ]


def test_grid_search_bad_input():
    # Grid search parameters cannot be nested
    with pytest.raises(ValueError):
        GridSearchTuner(get_data()).generate_specs(
            [MyEstimator.search_space(a=Ref("a"), b=1)],
            {"a": Choice(Choice(1, 2), 3)},
        )

    # Models should contain only references, no parameters
    with pytest.raises(ValueError):
        GridSearchTuner(get_data()).generate_specs(
            [MyEstimator.search_space(a=Choice("a"), b=1)],
            {"a": Choice(1, 2, 3)},
        )

    # Grid search does not support distributions
    with pytest.raises(ValueError):
        GridSearchTuner(get_data()).generate_specs(
            [MyEstimator.search_space(a=Ref("a"), b=1)],
            {"a": Distribution(uniform(0, 1))},
        )


def test_recursive_search_basic():
    basic_item = Choice(Choice(1, 2), Choice(Choice(1, 2, 3), 4, Distribution(uniform(0, 1))))
    hidden_item = {"a": [1, 2, {"b": basic_item}, 4], "c": 1}

    for item in (basic_item, hidden_item):
        assert len(recursive_search(item, Parameter)) == 5
        assert len(recursive_search(item, Choice)) == 4
        assert len(recursive_search(item, Distribution)) == 1


def test_recursive_search_init_spec():
    models = [
        ArimaForecaster.search_space(ar_order=Choice(1, 2)),
        MyEstimator.search_space(a=Distribution(uniform(0, 1)), b=2),
    ]

    assert len(recursive_search(models, Parameter)) == 2


def test_recursive_search_no_copy():
    a = Choice(1, 2)
    b = Choice(2, 3, 4)
    f1, f2 = recursive_search(ArimaForecaster.search_space(ar_order=a, ma_order=b), Choice)
    assert (a is f1 and b is f2) or (a is f2 and b is f1)
