#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from uff.feature_selectors import ColumnsAsStringsSelector
from uff.tstypes import TimeIndexedData

from .. import utils


def test_column_as_strings():
    d1 = TimeIndexedData([1, 2], [[1, 1], [2, 3]], column_names=[("a", 1), ("b", 2)])
    d2 = TimeIndexedData([1, 2], [1, 2], column_names=[("a", 1)])
    d3 = TimeIndexedData([1, 2], [1, 2], column_names=["hi"])

    for data in (d1, d2, d3):
        for separator in (" ", "_"):
            res = ColumnsAsStringsSelector(separator=separator).transform_covariates(data)
            assert res.out == data.set_column_index_to_strings(separator=separator, in_place=False)
            assert res.out.column_names == [
                separator.join([str(c) for c in tup]) for tup in data.column_tuples
            ]


def test_ray_serialize():
    utils.assert_ray_serializable_or_flagged(ColumnsAsStringsSelector())


def test_joblib_serialize():
    utils.assert_joblib_serializable_or_flagged(ColumnsAsStringsSelector())


def test_lifecycle_updates():
    utils.assert_lifecycle_updates(ColumnsAsStringsSelector())
