#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from uff.feature_selectors import QuerySelector
from uff.tstypes import TimeIndexedData

from .. import utils


def test_query_selector_basic():
    data = TimeIndexedData([1, 2], [1, 2])
    covariates = TimeIndexedData([1, 2], [[1, 2], [1, 2]], column_names=["a", "b"])

    res = QuerySelector("col == 'a'").fit(data, covariates).transform_covariates(covariates)
    assert res.out == covariates.select(["a"])


def test_ray_serialize():
    utils.assert_ray_serializable_or_flagged(QuerySelector("col == 'x1'"))


def test_joblib_serialize():
    utils.assert_joblib_serializable_or_flagged(QuerySelector("col == 'x1'"))


def test_lifecycle_updates():
    utils.assert_lifecycle_updates(QuerySelector("col == 'x1'"))
