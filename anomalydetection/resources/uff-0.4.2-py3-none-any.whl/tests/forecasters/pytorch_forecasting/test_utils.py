#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import numpy as np
import pytest

import uff
from uff.forecasters.pytorch_forecasting import utils


def test_create_time_series_dataset_bad_input():
    bad_args = [
        # Different time scales
        (uff.TimeIndexedData([1, 2, 3], [1, 2, 3]), uff.TimeIndexedData([2, 3, 4], [1, 2, 3])),
        # NaNs
        (uff.TimeIndexedData([1, 2, 3], [1, np.nan, 3]),),
        # Missing values
        (uff.TimeIndexedData([1, 2, 4], [1, 2, 3]),),
        # Too short
        (uff.TimeIndexedData([1], [1]),),
    ]
    for args in bad_args:
        with pytest.raises(ValueError):
            utils.create_time_series_dataset(*args)


def test_create_time_series_dataset():
    as_short_as_possible = uff.TimeIndexedData([1, 2], [3, 4])
    _ = utils.create_time_series_dataset(as_short_as_possible)

    data = uff.TimeIndexedData([1, 2, 3, 4, 5, 6, 7], np.arange(14).reshape(7, 2))
    cov = uff.TimeIndexedData([1, 2, 3, 4, 5, 6, 7], np.arange(7))
    no_cov = utils.create_time_series_dataset(data)
    with_cov = utils.create_time_series_dataset(data, cov)
    for res in (no_cov, with_cov):
        for i, col in enumerate(data.column_tuples):
            assert np.allclose(res.data["target"][i], data[col])
