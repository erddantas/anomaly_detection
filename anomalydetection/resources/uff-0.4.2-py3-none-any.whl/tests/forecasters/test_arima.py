#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import numpy as np
import pandas as pd
import pytest

from uff.forecasters.arima import ArimaForecaster
from uff.tstypes import TimeIndex, TimeIndexedData

from .. import utils


def test_arima_basic():
    data = TimeIndexedData([1, 2, 3, 4], [1, 2, 3, 4])
    model = ArimaForecaster(
        ar_order=1,
        integration_order=1,
        enforce_stationarity=False,
        enforce_invertibility=False,
    ).fit(data)
    future = TimeIndex([4, 5, 6, 7])
    pred = model.forecast(future)
    assert pred.out.time_index == future
    assert np.allclose(pred.out.values, [4, 5, 6, 7], atol=0.01)
    assert isinstance(pred.sse, float)


def test_arima_cov_warning():
    t = pd.date_range("2023-01-03", "2023-02-03", freq="B")
    values = np.arange(len(t)) + np.random.normal(0, 0.2, size=len(t))
    regressors = np.random.random((len(t), 5))

    data = TimeIndexedData(t, values, granularity="B")
    cov = TimeIndexedData(t, regressors, granularity="B")

    model = ArimaForecaster().fit(data, cov)

    # Test warning on covariate overwrite
    with pytest.warns(UserWarning):
        model.forecast(cov)


def test_arima_scale_mismatch():
    t = pd.date_range("2023-01-03", "2023-02-03", freq="B")
    values = np.arange(len(t)) + np.random.normal(0, 0.2)
    regressors = np.random.random((len(t), 5))

    data = TimeIndexedData(t, values, granularity="B")
    cov = TimeIndexedData(t, regressors, granularity="B")

    model = ArimaForecaster().fit(data, cov)

    pred = TimeIndexedData([f"2023-02-{d}" for d in range(3, 12)], np.random.random((9, 5)))
    fcst = model.forecast(pred).out
    assert fcst.time_index == pred.time_index

    not_business_days = {pd.Timestamp(f"2023-02-{d}") for d in (4, 5, 11)}
    for i in range(len(fcst)):
        t = fcst.time_index.timestamp_values[i]
        v = fcst.values[i]
        if t in not_business_days:
            assert np.isnan(v)
        else:
            assert not np.isnan(v)


def test_skipped():
    data = TimeIndexedData([1, 2, 3, 4], [1, 2, 3, 4])
    model = ArimaForecaster().fit(data)

    future = TimeIndex([6, 7])
    pred = model.forecast(future)
    assert pred.out.time_index == future
    assert pred.std_dev.time_index == future


def test_search_space():
    spec = ArimaForecaster.search_space(ar_order=[1, 2, 3])
    model = spec.create_instance()
    assert model.init_kwargs["order"][0] == [1, 2, 3]


def test_lifecycle():
    utils.assert_lifecycle_updates(
        ArimaForecaster(enforce_stationarity=False, enforce_invertibility=False)
    )


def test_ray_serialize():
    utils.assert_ray_serializable_or_flagged(
        ArimaForecaster(enforce_stationarity=False, enforce_invertibility=False)
    )


def test_joblib_serialize():
    utils.assert_joblib_serializable_or_flagged(
        ArimaForecaster(enforce_stationarity=False, enforce_invertibility=False)
    )
