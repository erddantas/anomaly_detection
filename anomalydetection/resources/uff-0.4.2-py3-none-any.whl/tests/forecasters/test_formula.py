#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import numpy as np

from uff.forecasters.formula import FormulaForecaster, FormulaForecasterOutput
from uff.tstypes import TimeIndexedData, TimeIndexedOutputWithInterval
from uff.utils import temporal_split

from .. import utils


def test_basic_case_with_intercept():
    def f(t):
        return 0.3 * t + 10

    t = np.arange(100)
    y = f(t)

    future_t = np.arange(100, 110)
    future_y = f(future_t)

    time_series = TimeIndexedData(t, y)
    model = FormulaForecaster(
        formula="any_value_it_doesnt_matter ~ my_var", time_regressor="my_var"
    ).fit(time_series)
    result = model.forecast(time_series.future_time_index(10))
    assert isinstance(result, FormulaForecasterOutput)
    assert np.allclose(result.out.values, future_y)


def test_with_global_vectorized_func():
    def f(t):
        return 0.3 * np.log(t + 1) + 10

    t = np.arange(100)
    y = f(t)

    future_t = np.arange(100, 110)
    future_y = f(future_t)

    time_series = TimeIndexedData(t, y)
    model = FormulaForecaster(formula="y ~ np.log(t + 1)").fit(time_series)
    result = model.forecast(time_series.future_time_index(10))
    assert isinstance(result, FormulaForecasterOutput)
    assert np.allclose(result.out.values, future_y)


def test_with_covariates():
    def f(t, x):
        return 0.3 * t + 0.5 * x + 10

    t = np.arange(100)
    x = np.random.randn(100)
    y = f(t, x)

    all_data = TimeIndexedData(t, y)
    all_covariates = TimeIndexedData(t, x, column_names=["special_covariate"])

    past_data, _ = temporal_split(all_data, 0.5)
    past_covariates, future_covariates = temporal_split(all_covariates, 0.5)

    model = FormulaForecaster("y ~ t + special_covariate").fit(past_data, past_covariates)
    result = model.forecast(future_covariates)
    assert isinstance(result, FormulaForecasterOutput)


def test_with_automatic_time_covariates_override():
    def f(t, x):
        return 0.3 * t + 0.5 * x + 10

    t = np.arange(100)
    x = np.random.randn(100)
    y = f(t, x)

    data = TimeIndexedData(t, y)
    past, future = temporal_split(data, 0.5)
    model = FormulaForecaster("y ~ t + month_of_year").fit(past)
    prediction_a = model.forecast(future)

    # Users can override the default covariates
    covariates = TimeIndexedData(t, x, column_names=["month_of_year"])
    past_cov, future_cov = temporal_split(covariates, 0.5)
    model = FormulaForecaster("y ~ t + month_of_year").fit(past, past_cov)
    prediction_b = model.forecast(future_cov)

    res_a, res_b = prediction_a.out, prediction_b.out
    assert res_a.time_index == res_b.time_index
    assert res_a.shape == res_b.shape
    assert not np.allclose(res_a.values, res_b.values)


def test_search_space():
    formula = "target ~ I(t + 1)"
    spec = FormulaForecaster.search_space(formula=formula)
    model = spec.create_instance()
    assert model._formula == formula


def test_lifecycle():
    utils.assert_lifecycle_updates(FormulaForecaster("y ~ t"))


def test_ray_serialize():
    utils.assert_ray_serializable_or_flagged(FormulaForecaster("y ~ t"))


def test_joblib_serialize():
    utils.assert_joblib_serializable_or_flagged(FormulaForecaster("y ~ t"))
