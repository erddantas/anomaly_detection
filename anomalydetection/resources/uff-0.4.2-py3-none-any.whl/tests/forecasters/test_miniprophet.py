#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import numpy as np
import pandas as pd
import pytest

import uff
from uff.consts import (
    ONE_DAY,
    ONE_HOUR,
    ONE_MILLISECOND,
    ONE_MINUTE,
    ONE_NANOSECOND,
    ONE_SECOND,
)
from uff.forecasters.miniprophet import MiniProphetForecaster
from uff.forecasters.miniprophet._miniprophet_impl import _estimate_changepoints
from uff.tstypes import TimeIndex, TimeIndexedData


@pytest.mark.parametrize("scale", [0.1, 1, 10])
def test_miniprophet_linear_trend(scale):
    data = TimeIndexedData([1, 2, 3, 4], [1, 2, 3, 4]) * scale
    model = MiniProphetForecaster(lambda_reg=0).fit(data)
    future = TimeIndex([4, 5, 6, 7])
    pred = model.forecast(future)
    assert pred.out.time_index == future
    assert np.allclose(pred.out.values, np.array([4, 5, 6, 7]) * scale, atol=0.001, rtol=0.001)


def test_miniprophet_linear_trend_with_noise():
    with uff.deterministic_rng(42):
        data = TimeIndexedData(range(100), range(100), unixtime_unit="1D") + np.random.normal(
            scale=2, size=100
        )
        model = MiniProphetForecaster(lambda_reg=0.0, max_changepoints=0).fit(data)
        pred = model.forecast(data.future_time_index(n_steps=10, n_steps_past=10))
        assert np.allclose(pred.out.values, range(90, 110), atol=0.5, rtol=0.1)


def test_miniprophet_holidays():
    with uff.deterministic_rng(42):
        past = TimeIndex([1, 2, 3, 4, 5], unixtime_unit="1D")
        holidays = TimeIndex([3, 7], unixtime_unit="1D").timestamp_values

        data = TimeIndexedData.from_time_index(past, [1, 2, 20, 4, 5])
        model = MiniProphetForecaster(holidays=holidays, lambda_reg=0.0, max_changepoints=0).fit(
            data
        )

        pred = model.forecast(past)
        assert pred.out.time_index == past
        assert np.allclose(pred.out.values[2], [20], rtol=0.1)

        future = past.future(2)
        pred = model.forecast(future)
        assert pred.out.time_index == future
        assert np.allclose(pred.out.values[1], [20], rtol=0.15)


def test_changepoints_found():
    t = range(100)
    x = [0] * 50 + [1] * 50
    data = TimeIndexedData(t, x, unixtime_unit="1D")
    model = MiniProphetForecaster(max_changepoints=1, lambda_reg=0.0).fit(data)
    assert len(model._point_model.changepoints) == 1

    # Test no changepoints found if the series is too short
    t = range(10)
    x = [0] * 5 + [1] * 5
    data = TimeIndexedData(t, x, unixtime_unit="1D")
    model = MiniProphetForecaster(lambda_reg=0.0, min_changepoint_samples=10).fit(data)
    assert len(model._point_model.changepoints) == 0


@pytest.mark.parametrize(
    "unit, expected",
    [
        (ONE_HOUR, 336),
        (22 * ONE_HOUR, 15),  # A weird example.
        (ONE_DAY, 14),
        (365 * ONE_DAY, 3),
    ],
)
def test_auto_changepoint_min_samples(unit, expected):
    t = range(100)
    x = [0] * 50 + [1] * 50
    data = TimeIndexedData(t, x, unixtime_unit=unit)
    model = MiniProphetForecaster(min_changepoint_samples="auto").fit(data)
    assert model._point_model.min_changepoint_samples == expected


@pytest.mark.parametrize("num_observations", [2, 10, 100])
@pytest.mark.parametrize(
    "temporal_unit", [ONE_NANOSECOND, ONE_MILLISECOND, ONE_SECOND, ONE_MINUTE, ONE_HOUR, ONE_DAY]
)
@pytest.mark.parametrize("fraction_nan", [0, 0.1, 1.0])
@pytest.mark.parametrize("fraction_missing_data", [0, 0.1, 1.0])
def test_miniprophet_heterogeneous_data(
    num_observations, temporal_unit, fraction_nan, fraction_missing_data
):
    """Test miniprophet handles various types of input data.

    This test is not testing for quality of predictions.
    """
    with uff.deterministic_rng(42):
        x, y = list(range(num_observations)), np.arange(num_observations, dtype=np.float64)
        nan_idxs = np.random.permutation(y)[: int(fraction_nan * num_observations)].astype(np.int64)
        missing_idxs = np.random.permutation(y)[
            : int(fraction_missing_data * num_observations)
        ].astype(np.int64)

        y[nan_idxs] = np.nan
        x = np.delete(x, missing_idxs).tolist()
        y = np.delete(y, missing_idxs)

        data = TimeIndexedData(x, y, unixtime_unit=temporal_unit)

        if (len(data) < 2) or (temporal_unit == ONE_NANOSECOND) or (fraction_nan == 1.0):
            with pytest.raises(ValueError):
                MiniProphetForecaster(lambda_reg=0.0).fit(data)
        else:
            model = MiniProphetForecaster(lambda_reg=0.0).fit(data)
            pred = model.forecast(data.future_time_index(n_steps=10, n_steps_past=10))
            assert not np.isnan(pred.out.values).any()
            assert not np.isnan(pred.lower.values).any()
            assert not np.isnan(pred.upper.values).any()


@pytest.mark.parametrize(
    "change_points",
    [
        [{"start_idx": 50, "end_idx": None, "scale": 10}],
        [
            {"start_idx": 25, "end_idx": 50, "scale": 5},
            {"start_idx": 50, "end_idx": 75, "scale": 10},
            {"start_idx": 75, "end_idx": None, "scale": 20},
        ],
    ],
)
def test_estimate_changepoints(change_points):
    """Check scale changes in the input data are detected by automatic change point detection."""
    y = np.ones(100)

    expected_change_point_idxs = []
    for change_point in change_points:
        y[change_point["start_idx"] : change_point["end_idx"]] *= change_point["scale"]
        expected_change_point_idxs.append(change_point["start_idx"])

    min_ind, max_idx = 2, len(y) - 3
    estimated_change_points = _estimate_changepoints(y, min_ind, max_idx, 10)

    assert len(estimated_change_points) == len(set(estimated_change_points))
    assert set(estimated_change_points).issubset(set(estimated_change_points))


def test_ordered_and_well_behaved_prediction_intervals():
    """Test that the prediction intervals are ordered correctly.

    The test case is a heteroskedastic time series where the standard deviation decreases over time.
    """
    np.random.seed(42)
    x = np.arange(1000)
    y = np.random.normal(0, (np.arange(1000) * 0.3)[::-1])
    data = TimeIndexedData(x, y)
    model = MiniProphetForecaster()
    model.fit(data)
    point, upper, lower, _ = model.forecast(data.future_time_index(n_steps=1000))
    assert np.all(upper.values >= point.values)
    assert np.all(point.values >= lower.values)

    differences = upper.values - lower.values
    diff_in_diff = np.diff(differences)
    assert np.all(diff_in_diff >= 0), "Prediction intervals should diverge over time."


def fourier_series(x: np.array, a: np.array, b: np.array, T: float) -> np.array:
    res = np.zeros_like(x).astype(np.float64)
    for i, (an, bn) in enumerate(zip(a, b)):
        n = i + 1
        phase = 2 * np.pi * n * x / T
        res += an * np.cos(phase)
        res += bn * np.sin(phase)
    return res


def get_t_series(
    intercept: float,
    slope: float,
    a_day: np.array,
    b_day: np.array,
    a_week: np.array,
    b_week: np.array,
) -> TimeIndexedData:
    x = np.arange(1000)
    y = ((slope * x) + intercept).astype(np.float64)
    y += fourier_series(x, a_day, b_day, 24)
    y += fourier_series(x, a_week, b_week, 24 * 7)
    return TimeIndexedData(x, y, unixtime_unit=pd.Timedelta(hours=1))


@pytest.mark.parametrize("intercept", [50])
@pytest.mark.parametrize("slope", [-0.1, 0.7])
@pytest.mark.parametrize("a_day, b_day", [[[0], [0]], [[1, 3, 2], [-1, 2, 1]]])
@pytest.mark.parametrize("a_week, b_week", [[[0], [0]], [[2, 1], [1, 5]]])
@pytest.mark.parametrize("lambda_reg", [0, 0.001])
def test_basic_fit_quality(intercept, slope, a_day, b_day, a_week, b_week, lambda_reg):
    with uff.deterministic_rng(42):  # Just in case
        data = get_t_series(intercept, slope, a_day, b_day, a_week, b_week)
        train, test = uff.temporal_split(data, 0.8)
        model = MiniProphetForecaster(max_changepoints=0, lambda_reg=lambda_reg).fit(train)
        pred = model.forecast(test.time_index)
        atol = 0.1 if lambda_reg == 0 else 2.6  # Determined empirically across all the test cases
        assert np.allclose(pred.out.values, test.values, atol=atol)


@pytest.mark.parametrize("a_day, b_day", [[[0], [0]], [[1, 3, 2], [-1, 2, 1]]])
@pytest.mark.parametrize("a_week, b_week", [[[0], [0]], [[2, 1], [1, 5]]])
@pytest.mark.parametrize("lambda_reg", [0, 0.001])
def test_fit_quality_with_changepoints(a_day, b_day, a_week, b_week, lambda_reg):
    with uff.deterministic_rng(42):  # Just in case
        d1 = get_t_series(500, 0, a_day, b_day, a_week, b_week)
        d2 = get_t_series(1000, -1, a_day, b_day, a_week, b_week)
        d3 = get_t_series(200, 0.5, a_day, b_day, a_week, b_week)

        data = uff.concatenate([d1.slice(0, 500), d2.slice(500, 800), d3.slice(800)])
        model = MiniProphetForecaster(
            daily_order=0,  # Test trend only
            weekly_order=0,
            min_changepoint_samples=24,
            max_changepoints=3,
            lambda_reg=lambda_reg,
        )
        model.fit(data)
        pred = model.forecast(data.time_index)
        assert np.allclose(pred.out.values, data.values, rtol=0.1)


def test_long_horizon_reduces_changepoints():
    data = TimeIndexedData(range(100), range(100), unixtime_unit="1D")
    horizon = data.future_time_index(n_steps=1000).last_timestamp()
    model = MiniProphetForecaster(horizon=horizon).fit(data)
    # In extreme scenarios there should be no changepoints
    assert len(model._point_model.changepoints) == 0
