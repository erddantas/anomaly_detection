#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from inspect import signature

import numpy as np
import pytest

import uff
from uff.base import InitializationSpec
from uff.consts import ONE_DAY
from uff.forecasters.orbit import (
    OrbitDltForecaster,
    OrbitEtsForecaster,
    OrbitKtrForecaster,
    OrbitKtrLiteForecaster,
    OrbitLgtForecaster,
)
from uff.tstypes import TimeIndexedData

from .. import utils

ALL_MODELS = (
    OrbitDltForecaster,
    OrbitEtsForecaster,
    OrbitKtrForecaster,
    OrbitKtrLiteForecaster,
    OrbitLgtForecaster,
)


def test_dlt_init():
    OrbitDltForecaster()
    OrbitDltForecaster(regression_penalty="lasso")
    OrbitDltForecaster(
        regressors=[
            {"name": "hello"},
            {"name": "goodbye", "sign": "+", "beta_prior": 1, "sigma_prior": 0.5},
        ]
    )
    with pytest.raises(ValueError):
        OrbitDltForecaster(global_trend_option="some random string")


def test_ets_init():
    OrbitEtsForecaster()
    OrbitEtsForecaster(estimator="stan-map")
    with pytest.raises(ValueError):
        OrbitEtsForecaster(estimator="some random string")


def test_ktr_init():
    OrbitKtrForecaster()
    OrbitKtrForecaster(seasonality=7)
    OrbitKtrForecaster(
        regressors=[
            {"name": "hello"},
            {
                "name": "goodbye",
                "sign": "+",
                "init_knot_loc": 2,
                "init_knot_scale": 0.5,
                "knot_scale": 1,
            },
        ]
    )


def test_ktr_lite_init():
    OrbitKtrLiteForecaster()
    OrbitKtrLiteForecaster(seasonality=7)


def test_lgt_init():
    OrbitLgtForecaster()
    OrbitLgtForecaster(regression_penalty="lasso")
    OrbitLgtForecaster(estimator="pyro-svi")
    with pytest.raises(ValueError):
        OrbitLgtForecaster(estimator="some random string")


@pytest.mark.parametrize("cls", ALL_MODELS)
def test_model_init_combinations(cls):
    t = np.arange(100)

    data = TimeIndexedData(t, np.random.poisson(10, size=100), unixtime_unit=ONE_DAY)
    covariates = TimeIndexedData(
        t, np.random.poisson(10, size=(100, 2)), column_names=["x1", "x2"], unixtime_unit=ONE_DAY
    )
    train, test = uff.temporal_split(data, 0.9)
    train_cov, test_cov = uff.temporal_split(covariates, 0.9)

    defaults = (
        {"num_warmup": 2, "num_sample": 2, "chains": 2, "cores": 2}
        if cls != OrbitKtrForecaster
        else {"num_sample": 2, "num_particles": 2}
    )
    specs = [
        InitializationSpec(cls, n_bootstrap_draws=1, **defaults),
        InitializationSpec(cls, n_bootstrap_draws=1, **defaults),
    ]

    if "point_method" in signature(cls.__init__).parameters:
        specs.append(
            InitializationSpec(
                cls, n_bootstrap_draws=2, estimator="stan-mcmc", point_method="median", **defaults
            )
        )

    for spec in specs:
        utils.assert_lifecycle_updates(spec)

        for res in (
            spec.create_instance().fit(train).forecast(test),
            spec.create_instance().fit(train).forecast(test.time_index),
            spec.create_instance().fit(train, train_cov).forecast(test_cov),
        ):
            assert res.out.column_names == train.column_names
            assert res.out.shape[1:] == train.shape[1:]
            assert res.out.time_index == test.time_index


@pytest.mark.parametrize("cls", ALL_MODELS)
def test_ray_serialize(cls):
    utils.assert_ray_serializable_or_flagged(cls())


@pytest.mark.parametrize("cls", ALL_MODELS)
def test_joblib_serialize(cls):
    utils.assert_joblib_serializable_or_flagged(cls())
