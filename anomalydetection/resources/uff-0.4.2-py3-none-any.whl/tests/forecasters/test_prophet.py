#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import numpy as np
import pandas as pd
import pytest

from uff.consts import ONE_SECOND
from uff.forecasters.prophet import PermissiveProphetForecaster, ProphetForecaster
from uff.tstypes import TimeIndex, TimeIndexedData
from uff.utils import concatenate

from .. import utils


def test_basic_case():
    linear_model = ProphetForecaster(
        growth="linear",
        yearly_seasonality=False,
        weekly_seasonality=False,
        daily_seasonality=False,
        n_changepoints=0,
    )

    m, b = 0.3, 10
    t = np.arange(10)

    time_series = TimeIndexedData(
        time_array=t,
        values=(m * t) + b,
    )
    future = time_series.future_time_index(n_steps=5, n_steps_past=3)
    res = linear_model.fit(time_series).forecast(future)
    fcst = res.out

    new_t = np.arange(7, 15)
    assert fcst.shape == (8,)
    assert np.allclose(fcst, m * new_t + b)
    assert np.array_equal(res.out.int_time_index(), new_t)


@pytest.mark.parametrize("extra_regressors", [None, [{"name": c} for c in ("x1", "x2")]])
def test_covariates(extra_regressors):
    linear_model = ProphetForecaster(
        growth="linear",
        yearly_seasonality=False,
        weekly_seasonality=False,
        daily_seasonality=False,
        n_changepoints=0,
        extra_regressors=extra_regressors,
    )

    df = pd.DataFrame(
        {
            "ds": [1, 2, 3, 4, 5],
            "y": [3, 4, 5, 6, 7],
            "x1": [1.5, 2, 2.5, 3, 3.5],
            "x2": [1, 2, 1, 2, 1],
        }
    )

    data = TimeIndexedData.from_pandas(df, time_col="ds", value_col="y")
    covariates = TimeIndexedData.from_pandas(df, time_col="ds", value_col=["x1", "x2"])
    linear_model.fit(data, covariates)

    # Must supply covariates during forecast() if you supplied them during fit()
    with pytest.raises(ValueError):
        linear_model.forecast(data.future_time_index(n_steps=1))

    future_cov = TimeIndexedData(
        time_array=[6],
        values=[[4, 2]],
        column_names=["x1", "x2"],
        granularity=data.granularity,
        unixtime_t0=data.unixtime_t0,
        unixtime_unit=data.unixtime_unit,
    )
    res = linear_model.forecast(future_cov)
    assert len(res.out) == 1

    # Include some past data
    cov = concatenate((covariates.slice(-3), future_cov))
    res = linear_model.forecast(cov)
    assert len(res.out) == 4


def test_bad_input():
    # Cannot call forecast before fit
    with pytest.raises(RuntimeError):
        ProphetForecaster().forecast(TimeIndex([1, 2, 3]))

    # Cannot have data and covariates with non-matching time indices
    data = TimeIndexedData([1], [1], granularity=ONE_SECOND)
    cov = TimeIndexedData([2], [2], granularity=ONE_SECOND)
    with pytest.raises(ValueError):
        ProphetForecaster().fit(data, cov)

    # Cannot name your covariates "ds" or "y"
    cov = TimeIndexedData([1], [[1, 1]], column_names=["ds", "y"], granularity=ONE_SECOND)
    with pytest.raises(ValueError):
        ProphetForecaster().fit(data, cov)


def test_permissive():
    # Test 1D and 2D
    for shape in [(1,), (1, 1)]:
        model = PermissiveProphetForecaster()
        data = TimeIndexedData([1], [1]).reshape(
            shape
        )  # Length 1 throws an error in regular prophet

        model.fit(data)
        res = model.forecast(data.future_time_index(4))

        assert np.allclose(res.upper.values, 0)
        assert np.allclose(res.out.values, 0)
        assert np.allclose(res.lower.values, 0)
        assert res.out.shape[1:] == shape[1:]


def test_search_space():
    regressors = [{"name": "x1"}, {"name": "x2"}]
    spec = ProphetForecaster.search_space(extra_regressors=regressors)
    model = spec.create_instance()
    assert model.extra_regressors == regressors


def test_lifecycle():
    utils.assert_lifecycle_updates(ProphetForecaster())


def test_ray_serialize():
    utils.assert_ray_serializable_or_flagged(ProphetForecaster())


def test_joblib_serialize():
    utils.assert_joblib_serializable_or_flagged(ProphetForecaster())
