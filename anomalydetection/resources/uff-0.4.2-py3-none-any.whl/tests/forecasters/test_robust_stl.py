#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import datetime

import numpy as np
import pandas as pd
import pytest

from uff.forecasters.robust_stl import RobustStlModel
from uff.tstypes import TimeIndex, TimeIndexedData


@pytest.fixture
def synthetic_hourly_time_series():
    """
    Builds a synthetic hourly time series with exponential growth trend and weekly seasonality
    """
    Fs = 24
    f = 1
    sample = 24 * 365 * 0.6
    np.random.seed(0)
    x = np.arange(sample)
    y = np.exp(0.00008 * x) * (
        100 + 25 * np.cos(2 * np.pi * f * x / Fs) + np.random.normal(0, 2, len(x))
    )

    start_timestamp = pd.Timestamp("2021-12-24 21:59:59.999000")
    date_range = pd.date_range(start_timestamp, periods=len(y), freq="1h")

    test_series = pd.Series(data=y, index=date_range)

    test_num_obs = int(24 * 4.2)
    train_values = test_series.iloc[:-test_num_obs]
    test_values = test_series.iloc[-test_num_obs:]
    return train_values, test_values


def test_robust_stl_forecast(synthetic_hourly_time_series):
    # check forecast() works, both specifying `n_steps` as well as `future`
    train_values, test_values = synthetic_hourly_time_series
    test_model = RobustStlModel(
        trend_lookback=datetime.timedelta(days=360),
        seasonality_lookback=datetime.timedelta(weeks=3),
    )
    test_model.fit(data=TimeIndexedData.from_pandas(train_values.to_frame(name="val"), "val"))
    future_projected_vals = test_model.forecast(TimeIndex(values=test_values.index)).out.values
    # check all values are within 6% (true for random seed = 0)
    assert max(abs(test_values - future_projected_vals) / test_values) < 0.06


def test_robust_stl_transform(synthetic_hourly_time_series):
    # check transform() works
    train_values, test_values = synthetic_hourly_time_series
    test_model = RobustStlModel(
        trend_lookback=datetime.timedelta(days=360),
        seasonality_lookback=datetime.timedelta(weeks=3),
    )
    test_model.fit(data=TimeIndexedData.from_pandas(train_values.to_frame(name="val"), "val"))
    test_model.transform(TimeIndexedData.from_pandas(test_values.to_frame(name="val"), "val"))


def test_robust_stl_forecast_with_slice(synthetic_hourly_time_series):
    train_values, test_values = synthetic_hourly_time_series
    test_model = RobustStlModel(
        trend_lookback=datetime.timedelta(days=7),
        seasonality_lookback=datetime.timedelta(days=7),
    )
    test_model.fit(data=TimeIndexedData.from_pandas(train_values.to_frame(name="val"), "val"))
    test_model.forecast(TimeIndex(values=test_values.index)).out.values


def test_robust_stl_forecast_irregular_input(synthetic_hourly_time_series):
    # check forecast() works in the following cases
    #   1. missing observations
    #   2. non-uniformly spaved observations
    train_values, test_values = synthetic_hourly_time_series
    assert len(train_values) > 10
    # 1. drop observations
    train_values = train_values.drop(labels=[train_values.index[4], train_values.index[-4]])
    # 2. mess up indices
    train_values.rename(
        {
            train_values.index[1]: train_values.index[1] + datetime.timedelta(milliseconds=700),
            train_values.index[5]: train_values.index[5] - datetime.timedelta(milliseconds=1000),
        },
        inplace=True,
    )
    test_model = RobustStlModel(
        trend_lookback=datetime.timedelta(days=360),
        seasonality_lookback=datetime.timedelta(weeks=3),
    )
    test_model.fit(data=TimeIndexedData.from_pandas(train_values.to_frame(name="val"), "val"))
    future_projected_vals = test_model.forecast(TimeIndex(values=test_values.index)).out.values
    assert max(abs(test_values - future_projected_vals) / test_values) < 0.06
