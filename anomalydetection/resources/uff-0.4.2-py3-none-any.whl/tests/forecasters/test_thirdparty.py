#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import pandas as pd
import pytest

from uff.forecasters.third_party import ThirdPartyRegressor
from uff.tstypes import TimeIndex, TimeIndexedData
from uff.utils import concatenate, load_multi_from_pandas

from ..mocks import MockSklearnEstimator


def test_basic_case():
    forecaster = ThirdPartyRegressor(MockSklearnEstimator, n_estimators=100)
    df = pd.DataFrame(
        {
            "ds": [1, 2, 3, 4, 5],
            "y": [3, 4, 5, 6, 7],
            "x1": [2, 2, 4, 4, 6],
            "x2": [1, 2, 1, 2, 1],
        }
    )

    data, cov = load_multi_from_pandas(df, (["y"], ["x1", "x2"]), time_col="ds")
    future_cov = TimeIndexedData(
        time_array=[6],
        values=[[4, 2]],
        column_names=["x1", "x2"],
        granularity=data.granularity,
        unixtime_t0=data.unixtime_t0,
        unixtime_unit=data.unixtime_unit,
    )
    forecaster.fit(data, cov)

    res = forecaster.forecast(future_cov)
    assert len(res.out) == 1

    cov = concatenate((cov.slice(-3), future_cov))
    res = forecaster.forecast(cov)
    assert len(res.out) == 4


def test_bad_input():
    forecaster = ThirdPartyRegressor(MockSklearnEstimator, n_estimators=100)

    df = pd.DataFrame(
        {
            "ds": [1, 2, 3, 4, 5],
            "y": [3, 4, 5, 6, 7],
            "x1": [2, 2, 4, 4, 6],
            "x2": [1, 2, 1, 2, 1],
        }
    )
    data = TimeIndexedData.from_pandas(df, time_col="ds", value_col="y")
    covariates = TimeIndexedData.from_pandas(df, time_col="ds", value_col=["x1", "x2"])

    # Cannot call forecast before fit
    with pytest.raises(RuntimeError):
        forecaster.forecast(covariates)
    forecaster.fit(data, covariates)

    # Forecast data must be TimeIndexedData if predict data preparation not provided
    with pytest.raises(ValueError):
        forecaster.forecast(TimeIndex([1, 2, 3]))


def test_search_space():
    params = {"n_estimators": 50, "max_depth": 10}
    spec = ThirdPartyRegressor.search_space(MockSklearnEstimator, **params)
    spec.create_instance()
