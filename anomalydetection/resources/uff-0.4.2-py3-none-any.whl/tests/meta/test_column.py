#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from tempfile import NamedTemporaryFile, TemporaryDirectory

import numpy as np
import pytest
from hyperopt import hp

import uff
from uff.base import FeatureSelector, Forecaster, InitializationSpec, Transformer
from uff.evaluation.hyperopt import HyperoptTuner
from uff.meta import ColumnEnsembleEstimator, IntervalBoundedForecaster

from ..mocks import create_assertive_estimator

AssertiveForecaster = create_assertive_estimator(Forecaster)
AssertiveTransformer = create_assertive_estimator(Transformer, requires_fit=False)
AssertiveFeatureSelector = create_assertive_estimator(FeatureSelector, requires_covariates=True)


class MyRandomForecaster(AssertiveForecaster):
    pass


def get_time_index():
    x = uff.time_range("2022-01-01", periods=100, freq="H")
    return uff.TimeIndex(x)


def get_data(index=None):
    index = index or get_time_index()
    y1 = np.random.normal(loc=10, scale=1, size=(len(index), 1))

    # Inject a NaN value
    y1[len(index) // 2] = np.nan

    ystack = np.random.normal(loc=1, scale=4, size=(len(index), 5))
    return uff.TimeIndexedData.from_time_index(
        index, np.hstack((y1, ystack)), column_names=[f"y{x}" for x in range(6)]
    )


def get_covariates(index=None):
    index = index or get_time_index()
    return uff.TimeIndexedData.from_time_index(index, np.random.rand(len(index), 5))


def compare_ensembles(m1: ColumnEnsembleEstimator, m2: ColumnEnsembleEstimator):
    assert m1._mixins == m2._mixins
    assert m1._default_estimator == m2._default_estimator
    assert m1._column_specific_estimators.keys() == m2._column_specific_estimators.keys()
    assert m1._column_subset_estimators.keys() == m2._column_subset_estimators.keys()
    assert m1.ordered_columns == m2.ordered_columns
    assert m1.models.keys() == m2.models.keys()
    assert m1._cache_dir_prefix == m2._cache_dir_prefix
    assert m1._permissive == m2._permissive
    assert m1.models_have_been_initialized == m2.models_have_been_initialized
    assert m1.requires_fit == m2.requires_fit
    assert m1.requires_covariates == m2.requires_covariates
    assert m1.ray_serializable == m2.ray_serializable
    assert m1.joblib_serializable == m2.joblib_serializable

    for k in m1._column_specific_estimators:
        assert m1._column_specific_estimators[k] == m2._column_specific_estimators[k]
    for k in m1._column_subset_estimators:
        assert m1._column_subset_estimators[k] == m2._column_subset_estimators[k]

    for k in m1.models:
        fitted1 = m1.models[k]
        fitted2 = m2.models[k]
        assert fitted1 == fitted2
        if fitted1.fit_data is None:
            assert fitted2.fit_data is None
        else:
            np.testing.assert_equal(fitted1.fit_data.values, fitted2.fit_data.values)
            assert fitted1.fit_data.same_shape(fitted2.fit_data)
        if fitted1.fit_covariates is None:
            assert fitted2.fit_covariates is None
        else:
            np.testing.assert_equal(fitted1.fit_covariates.values, fitted2.fit_covariates.values)
            assert fitted1.fit_covariates.same_shape(fitted2.fit_covariates)


def test_init():
    params = {"cls": AssertiveForecaster, "args": [2], "kwargs": {}}
    init_args = [params, InitializationSpec.from_dict(params), AssertiveForecaster(2)]
    for args in init_args:
        model = ColumnEnsembleEstimator(args)
        assert model.is_forecaster()
        assert not model.is_transformer()


@pytest.mark.parametrize("tmp_dir", [TemporaryDirectory()])
@pytest.mark.parametrize("permissive", [True, False])
@pytest.mark.parametrize(
    "column_subset_estimators", [None, {"col.isin(('y2', 'y3'))": MyRandomForecaster(5)}]
)
@pytest.mark.parametrize("column_specific_estimators", [None, {"y0": MyRandomForecaster(3)}])
def test_unfitted_serialize(
    tmp_dir,
    permissive,
    column_subset_estimators,
    column_specific_estimators,
):
    f = NamedTemporaryFile()
    base_estimator = AssertiveForecaster(2)
    model = ColumnEnsembleEstimator(
        base_estimator,
        column_specific_estimators=column_specific_estimators,
        column_subset_estimators=column_subset_estimators,
        cache_dir=tmp_dir.name if isinstance(tmp_dir, TemporaryDirectory) else None,
        permissive=permissive,
    )
    model.save(f.name)
    new_model = ColumnEnsembleEstimator.load(f.name)
    compare_ensembles(model, new_model)


@pytest.mark.parametrize("tmp_dir", [TemporaryDirectory()])
@pytest.mark.parametrize("permissive", [True, False])
@pytest.mark.parametrize(
    "column_subset_estimators", [None, {"col.isin(('y2', 'y3'))": MyRandomForecaster(5)}]
)
@pytest.mark.parametrize("column_specific_estimators", [None, {"y0": MyRandomForecaster(3)}])
@pytest.mark.parametrize("data", [get_data()])
@pytest.mark.parametrize("covariates", [None, get_covariates()])
def test_fit_serialize(
    tmp_dir,
    permissive,
    column_subset_estimators,
    column_specific_estimators,
    data,
    covariates,
):
    f = NamedTemporaryFile()
    base_estimator = AssertiveForecaster(2)
    model = ColumnEnsembleEstimator(
        base_estimator,
        column_specific_estimators=column_specific_estimators,
        column_subset_estimators=column_subset_estimators,
        cache_dir=tmp_dir.name if isinstance(tmp_dir, TemporaryDirectory) else None,
        permissive=permissive,
    )

    model.fit(data, covariates)
    model.save(f.name)
    new_model = ColumnEnsembleEstimator.load(f.name)

    compare_ensembles(model, new_model)


@pytest.mark.parametrize("column_specific_estimators", [None, {"y0": MyRandomForecaster(3)}])
@pytest.mark.parametrize("data", [get_data()])
@pytest.mark.parametrize("covariates", [None, get_covariates()])
def test_e2e_forecaster(column_specific_estimators, data, covariates):
    base_estimator = AssertiveForecaster(2)
    model = ColumnEnsembleEstimator(
        base_estimator, column_specific_estimators=column_specific_estimators
    )
    model.fit(data, covariates)

    future = (
        data.future_time_index(5)
        if covariates is None
        else uff.TimeIndexedData.from_time_index(
            data.future_time_index(5),
            np.random.rand(5, 5),
        )
    )

    res = model.forecast(future)

    assert res.out == uff.hstack([r.out for r in res.column_output])


def test_complex_composition():
    base_estimator = AssertiveForecaster(2)
    data = uff.TimeIndexedData(
        range(100),
        np.vstack([np.arange(100), np.random.rand(100)]).T,
        column_names=["top_line", "ratio"],
    )

    model = ColumnEnsembleEstimator(
        base_estimator,
        column_specific_estimators={
            "ratio": IntervalBoundedForecaster(base_estimator, lower=0, upper=1)
        },
    )
    model.fit(data)
    res = model.forecast(data.future_time_index(10))
    assert 0 <= res.out["ratio"].min() <= res.out["ratio"].max() <= 1


def test_e2e_transformer():
    model = ColumnEnsembleEstimator(AssertiveTransformer(2))

    data = get_data()
    res = model.transform(data)

    np.testing.assert_equal(res.out.values, uff.hstack([r.out for r in res.column_output]).values)
    assert res.out.same_shape(data)
    assert res.out.time_index == data.time_index


def test_feature_selectors_not_allowed():
    with pytest.raises(ValueError, match="Expected Forecaster or Transformer"):
        ColumnEnsembleEstimator(AssertiveFeatureSelector(2))


def test_model_assignment():
    query = f"col.isin(('y1', 'y2', 'y3'))"

    base_estimator = AssertiveForecaster(1)
    y1_model = AssertiveForecaster(2)
    y23_model = AssertiveForecaster(3)

    model = ColumnEnsembleEstimator(
        base_estimator,
        column_specific_estimators={"y1": y1_model},
        column_subset_estimators={query: y23_model},
    )
    model.fit(get_data())
    assert model.models[("y1",)] == y1_model
    assert model.models[("y2",)] == y23_model
    assert model.models[("y3",)] == y23_model
    assert model.models[("y4",)] == base_estimator


def test_parameter_search():
    tuner = HyperoptTuner(get_data())
    best, _ = tuner.run(
        "mse",
        [
            ColumnEnsembleEstimator.search_space(
                AssertiveForecaster.search_space(
                    ar_order=hp.choice("ar", [1, 2, 3]),
                ),
                column_specific_estimators={
                    "y0": AssertiveForecaster.search_space(periodicity=hp.choice("p", [4, 7])),
                },
            ),
        ],
        max_evals=1,
    )

    assert isinstance(best, ColumnEnsembleEstimator)
    assert isinstance(best._default_estimator, AssertiveForecaster)
    assert best._default_estimator.kwargs["ar_order"] in {1, 2, 3}
    assert best._column_specific_estimators[("y0",)].kwargs["periodicity"] in {4, 7}
