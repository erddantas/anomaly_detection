#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import numpy as np
import pytest

from uff import TimeIndexedData
from uff.meta import IntervalBoundedForecaster

from .. import utils as test_utils
from . import utils as meta_utils


@pytest.mark.parametrize("forecaster", meta_utils.forecast_specifications())
@pytest.mark.parametrize("lower", [-1, 2, None])
@pytest.mark.parametrize("upper", [98, 101, None])
@pytest.mark.parametrize("inclusive", ["both", "left", "right", "neither"])
def test_simple_e2e(forecaster, lower, upper, inclusive):
    if lower is None and upper is None:
        return

    data = TimeIndexedData(range(100), np.arange(100) + 0.1)

    model = IntervalBoundedForecaster(
        forecaster=forecaster, lower=lower, upper=upper, inclusive=inclusive
    )
    model.fit(data)
    res = model.forecast(data.future_time_index(10))

    min_v = res.out.values.min()
    max_v = res.out.values.max()

    if lower is not None:
        if inclusive in ("both", "left"):
            assert lower <= min_v
        else:
            assert lower < min_v

    if upper is not None:
        if inclusive in ("right", "both"):
            assert upper >= max_v
        else:
            assert upper > max_v


@pytest.mark.parametrize("forecaster", meta_utils.forecast_specifications(n=2))
def test_ray_serialize(forecaster):
    test_utils.assert_ray_serializable_or_flagged(
        IntervalBoundedForecaster(forecaster=forecaster, lower=1)
    )


@pytest.mark.parametrize("forecaster", meta_utils.forecast_specifications(n=2))
def test_joblib_serialize(forecaster):
    test_utils.assert_joblib_serializable_or_flagged(
        IntervalBoundedForecaster(forecaster=forecaster, lower=1)
    )


@pytest.mark.parametrize("forecaster", meta_utils.forecast_specifications(n=2))
def test_lifecycle(forecaster):
    test_utils.assert_lifecycle_updates(IntervalBoundedForecaster(forecaster=forecaster, lower=1))
