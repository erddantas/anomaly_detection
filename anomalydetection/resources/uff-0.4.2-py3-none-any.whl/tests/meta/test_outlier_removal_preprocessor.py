#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import numpy as np
import pytest

from uff.base import Forecaster
from uff.meta import OutlierRemovalPreprocessor
from uff.tstypes import TimeIndexedData

from .. import mocks
from .. import utils as test_utils
from . import utils as meta_utils


def test_all_same_data():
    values = np.ones(100)
    forecaster = mocks.create_assertive_estimator(Forecaster)()
    est = OutlierRemovalPreprocessor(forecaster, contamination=0.1)
    est.fit(TimeIndexedData(range(100), values))

    fit_values = forecaster.fit_data.values
    assert len(fit_values) == 100  # Should be no outliers


def test_outlier_removal_high_dim():
    values = np.clip(np.random.randn(100, 2, 4), -10, 10)
    values[25] = 100  # Add an obvious outlier

    forecaster = mocks.create_assertive_estimator(Forecaster)()
    est = OutlierRemovalPreprocessor(forecaster, contamination=0.01)
    est.fit(TimeIndexedData(range(100), values))

    fit_values = forecaster.fit_data.values
    assert fit_values.ndim == 3
    assert len(fit_values) == 99
    assert -10 <= fit_values.min() <= fit_values.max() <= 10


def test_outlier_removal():
    values = np.clip(np.random.randn(100), -10, 10)
    values[25] = 100  # Add an obvious outlier

    forecaster = mocks.create_assertive_estimator(Forecaster)()
    est = OutlierRemovalPreprocessor(forecaster, contamination=0.01)
    est.fit(TimeIndexedData(range(100), values))

    fit_values = forecaster.fit_data.values
    assert len(fit_values) == 99
    assert -10 <= fit_values.min() <= fit_values.max() <= 10


def test_corresponding_outlier_removal():
    values = np.clip(np.random.randn(100), -10, 10)
    values[25] = 100  # Add an obvious outlier
    data = TimeIndexedData(range(100), values)

    cov_values = np.tile([1, 2, 3], 34)[:100]
    cov_values[25] = 4  # Add a unique value to test later, but not an outlier
    covariates = TimeIndexedData(range(100), cov_values)

    forecaster = mocks.create_assertive_estimator(Forecaster)()
    est = OutlierRemovalPreprocessor(forecaster, contamination=0.01)
    est.fit(data, covariates)

    fit_values = forecaster.fit_data.values
    fit_cov_values = forecaster.fit_covariates.values
    assert len(fit_values) == 99
    assert -10 <= fit_values.min() <= fit_values.max() <= 10
    assert len(fit_cov_values) == 99
    assert set(fit_cov_values) == {1, 2, 3}  # The correponding entry in covariates was removed


@pytest.mark.parametrize("estimator", meta_utils.get_all_base_estimator_combinations())
def test_shared_properties(estimator):
    meta_utils.assert_shared_init_properties(OutlierRemovalPreprocessor(estimator), estimator)


@pytest.mark.parametrize("estimator", meta_utils.get_all_base_estimator_combinations())
def test_lifecycle(estimator):
    test_utils.assert_lifecycle_updates(OutlierRemovalPreprocessor(estimator))
