#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import numpy as np
import pytest

from uff import TimeIndexedData
from uff.base import Forecaster
from uff.feature_selectors import QuerySelector
from uff.meta import TransformedOutputForecaster
from uff.transformers.math import IdentityTransformer, ScaledLogitTransformer

from .. import mocks
from .. import utils as test_utils
from . import utils as meta_utils


def get_default_forecaster(forecaster):
    return TransformedOutputForecaster(
        transformers=[IdentityTransformer(), ScaledLogitTransformer(0, 100)],
        forecaster=forecaster,
    )


def get_forecaster_with_feature_selection(forecaster):
    return TransformedOutputForecaster(
        transformers=[IdentityTransformer(), QuerySelector("col.str.startswith('a')")],
        forecaster=forecaster,
    )


@pytest.mark.parametrize("forecaster", meta_utils.forecast_specifications())
def test_simple_e2e(forecaster):
    data = TimeIndexedData(range(100), np.arange(100) + 0.1)

    model = get_default_forecaster(forecaster)
    model.fit(data)
    res = model.forecast(data.future_time_index(10))

    assert 0 < res.out.values.min() <= res.out.values.max() < 100


@pytest.mark.parametrize("forecaster", meta_utils.forecast_specifications())
def test_with_feature_selection(forecaster):
    data = TimeIndexedData(range(100), np.arange(100) + 0.1)
    covariates = TimeIndexedData(
        range(100), np.random.rand(100, 5), column_names=["a1", "a2", "b1", "b2", "b3"]
    )

    past_data, past_covariates = data.slice(0, 50), covariates.slice(0, 50)
    future_covariates = covariates.slice(50)

    model = get_forecaster_with_feature_selection(forecaster)
    model.fit(past_data, past_covariates)
    _ = model.forecast(future_covariates)  # Confirm no errors during prediction

    assert model._forecaster.was_fit_with_covariates

    underlying_forecaster = model
    while isinstance(underlying_forecaster, TransformedOutputForecaster):
        underlying_forecaster = underlying_forecaster._forecaster
    assert underlying_forecaster.fit_covariates.column_names == ["a1", "a2"]


def test_complex_pipeline():
    data = TimeIndexedData(range(100), np.arange(100) + 0.1)
    covariates = TimeIndexedData(
        range(100), np.random.rand(100, 5), column_names=["a1", "a2", "b1", "b2", "b3"]
    )

    past_data, past_covariates = data.slice(0, 50), covariates.slice(0, 50)
    future_covariates = covariates.slice(50)

    underlying_model_class = mocks.create_assertive_estimator(Forecaster)

    model = TransformedOutputForecaster(
        transformers=[
            IdentityTransformer(),
            ScaledLogitTransformer(0, 100),
            QuerySelector("col.str.startswith('a')"),
            ScaledLogitTransformer(-10, 110),
            QuerySelector("col.str.contains('2')"),
            IdentityTransformer(),
        ],
        forecaster=underlying_model_class(),
    )

    model.fit(past_data, past_covariates)
    _ = model.forecast(future_covariates)  # Confirm no errors during prediction

    assert model._forecaster.was_fit_with_covariates

    underlying_forecaster = model
    while isinstance(underlying_forecaster, TransformedOutputForecaster):
        underlying_forecaster = underlying_forecaster._forecaster
    assert underlying_forecaster.fit_covariates.column_names == ["a2"]


@pytest.mark.parametrize("forecaster", meta_utils.forecast_specifications(n=2))
def test_ray_serialize(forecaster):
    test_utils.assert_ray_serializable_or_flagged(get_default_forecaster(forecaster))


@pytest.mark.parametrize("forecaster", meta_utils.forecast_specifications(n=2))
def test_joblib_serialize(forecaster):
    test_utils.assert_joblib_serializable_or_flagged(get_default_forecaster(forecaster))


@pytest.mark.parametrize("forecaster", meta_utils.forecast_specifications(n=2))
def test_lifecycle(forecaster):
    test_utils.assert_lifecycle_updates(get_default_forecaster(forecaster))
