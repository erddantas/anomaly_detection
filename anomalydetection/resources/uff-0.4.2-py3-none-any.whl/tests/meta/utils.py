#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from typing import List, Optional

import numpy as np

from uff.base import (
    Estimator,
    FeatureSelector,
    Forecaster,
    ReversibleTransformer,
    Transformer,
)
from uff.meta import TransformedOutputForecaster
from uff.meta.base import EstimatorSpecification
from uff.transformers.math import IdentityTransformer

from .. import mocks

AssertiveForecaster = mocks.create_assertive_estimator(Forecaster)
AssertiveTransformer = mocks.create_assertive_estimator(Transformer)
AssertiveReversibleTransformer = mocks.create_assertive_estimator(ReversibleTransformer)
AssertiveFeatureSelector = mocks.create_assertive_estimator(FeatureSelector)


def get_all_base_estimator_combinations() -> List[Estimator]:
    all_estimators = []
    for mixin in [Forecaster, Transformer, ReversibleTransformer, FeatureSelector]:
        for ray_serializable in [True, False]:
            for joblib_serializable in [True, False]:
                est_class = mocks.create_assertive_estimator(
                    mixin,
                    ray_serializable=ray_serializable,
                    joblib_serializable=joblib_serializable,
                )
                all_estimators.append(est_class())
    return all_estimators


def assert_shared_init_properties(meta_estimator: Estimator, base_estimator: Estimator) -> None:
    assert meta_estimator.ray_serializable == base_estimator.ray_serializable
    assert meta_estimator.joblib_serializable == base_estimator.joblib_serializable
    assert meta_estimator.requires_covariates == base_estimator.requires_covariates
    assert meta_estimator.requires_fit == base_estimator.requires_fit
    assert meta_estimator.is_transformer() == base_estimator.is_transformer()
    assert meta_estimator.is_reversible_transformer() == base_estimator.is_reversible_transformer()
    assert meta_estimator.is_feature_selector() == base_estimator.is_feature_selector()
    assert meta_estimator.is_forecaster() == base_estimator.is_forecaster()
    assert (
        meta_estimator.is_forecaster_with_interval() == base_estimator.is_forecaster_with_interval()
    )
    if meta_estimator.is_forecaster_with_interval():
        assert np.isclose(
            meta_estimator.predicition_interval_width, base_estimator.predicition_interval_width
        )


def forecast_specifications(n: Optional[int] = None) -> List[EstimatorSpecification]:
    regular_forecasters = [
        AssertiveForecaster(),
        AssertiveForecaster().params,
        {"cls": AssertiveForecaster, "args": [], "kwargs": {}},
    ]

    regular_identity_transformers = [
        IdentityTransformer(),
        IdentityTransformer().params,
        {"cls": IdentityTransformer, "args": [], "kwargs": {}},
    ]

    meta_estimators = []
    for fcst_spec in regular_forecasters:
        for transform_spc in regular_identity_transformers:
            pipeline = TransformedOutputForecaster([transform_spc], fcst_spec)
            meta_estimators += [
                pipeline,
                pipeline.params,
                {
                    "cls": TransformedOutputForecaster,
                    "args": ([transform_spc], fcst_spec),
                    "kwargs": {},
                },
            ]

    if n is None:
        return regular_forecasters + meta_estimators

    res = []
    pull_from = [regular_forecasters, meta_estimators]
    i = 0
    while len(res) < n:
        if max(len(x) for x in pull_from) == 0:
            break

        collection = pull_from[i % len(pull_from)]
        if len(collection) > 0:
            res.append(collection.pop())

        i += 1

    return res
