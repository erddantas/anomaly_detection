#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

from typing import Optional, Tuple, Union

import numpy as np

from uff.base import (
    FeatureSelector,
    Forecaster,
    ReversibleTransformer,
    TimeIndex,
    TimeIndexedData,
    TimeIndexedOutput,
    Transformer,
    decorators,
)


@decorators.check_state_and_input
def _mock_transform(self, data: TimeIndexedData, **kwargs) -> TimeIndexedOutput:
    if self.assert_in_sample:
        assert all(t in self.fit_ts for t in data.pd_timestamp_index())
    assert isinstance(data, TimeIndexedData)
    return TimeIndexedOutput(data)


@decorators.check_state_and_input
def _mock_forecast(self, data: Union[TimeIndex, TimeIndexedData], **kwargs) -> TimeIndexedOutput:
    assert isinstance(data, (TimeIndex, TimeIndexedData))
    index = data if isinstance(data, TimeIndex) else data.time_index
    if self.assert_in_sample:
        assert all(t in self.fit_ts for t in index.pd_timestamp_index())
    out_shape = (len(index),) + self.fit_shape[1:]
    out = TimeIndexedData.from_time_index(
        index, values=np.random.random(out_shape), column_names=self.fit_columns
    )
    return TimeIndexedOutput(out)


def create_assertive_estimator(
    *mixins,
    assert_in_sample: bool = False,
    requires_fit: bool = True,
    requires_covariates: bool = False,
    ray_serializable: Optional[bool] = None,
    joblib_serializable: Optional[bool] = None,
):
    class MockEstimator(*mixins):
        @decorators.set_init_attributes(
            requires_fit=requires_fit,
            requires_covariates=requires_covariates,
            ray_serializable=ray_serializable,
            joblib_serializable=joblib_serializable,
        )
        def __init__(self, *args, **kwargs):
            self.is_fit = False
            self.fit_shape = None
            self.fit_ts = None
            self.fit_data = None
            self.fit_covariates = None
            self.assert_in_sample = assert_in_sample
            self.args = args
            self.kwargs = kwargs

        def __eq__(self, other):
            return (
                type(self) is type(other)
                and self.args == other.args
                and self.kwargs == other.kwargs
            )

        @decorators.update_fit_attributes
        def fit(
            self, data: TimeIndexedData, covariates: Optional[TimeIndexedData] = None, **kwargs
        ) -> MockEstimator:
            assert isinstance(data, TimeIndexedData)
            assert covariates is None or isinstance(covariates, TimeIndexedData)
            self.is_fit = True
            self.fit_ts = set(data.pd_timestamp_index())
            self.fit_shape = data.shape
            self.fit_columns = data.column_names
            self.fit_data = data
            self.fit_covariates = covariates
            return self

    # Patch individual methods
    for mixin in mixins:
        if mixin == Transformer:
            MockEstimator.transform = _mock_transform
        elif mixin == Forecaster:
            MockEstimator.forecast = _mock_forecast
        elif mixin == ReversibleTransformer:
            MockEstimator.inverse_transform = _mock_transform
        elif mixin == FeatureSelector:
            MockEstimator.transform_covariates = _mock_transform

    return MockEstimator


class MockSklearnEstimator:
    def __init__(self, *args, **kwargs):
        self.out_shape: Union[Tuple, None] = None

    def fit(self, X: np.array, y: np.array) -> MockSklearnEstimator:
        self.out_shape = y.shape[1:]
        return self

    def predict(self, X: np.array) -> np.array:
        return np.ones((len(np.atleast_1d(X)),) + self.out_shape)
