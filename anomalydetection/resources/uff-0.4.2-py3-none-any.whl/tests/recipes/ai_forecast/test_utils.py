#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from typing import Any, Dict, Union

import numpy as np
import pandas as pd

from uff.recipes.ai_forecast import utils
from uff.tstypes import TimeIndexedData

# import pytest


def check_equal(
    arg1: Union[TimeIndexedData, Dict[Any, TimeIndexedData]],
    arg2: Union[TimeIndexedData, Dict[Any, TimeIndexedData]],
) -> None:
    if isinstance(arg1, dict):
        assert arg1.keys() == arg2.keys()
        for key in arg1:
            ts1, ts2 = arg1[key], arg2[key]
            assert ts1.time_index == ts2.time_index
            assert ts1.column_names == ts2.column_names
            assert ts1.shape == ts2.shape
            assert np.allclose(ts1.values, ts2.values)


def test_cohorts_basic():
    ts = [pd.Timestamp(f"2023-01-{x}") for x in range(1, 4)]
    values = np.array([[1, np.nan], [2, 4], [3, 6]])
    data = TimeIndexedData(ts, values, column_names=["a", "b"])

    check_equal(
        utils.get_cohorts(data),
        {
            pd.Timestamp("2023-01-01"): TimeIndexedData(
                ts,
                [[1], [2], [3]],
                column_names=["a"],
            ),
            pd.Timestamp("2023-01-02"): TimeIndexedData(
                ts[1:],
                [[4], [6]],
                column_names=["b"],
            ),
        },
    )


def test_multivariate_interp_basic():
    ts = [pd.Timestamp(f"2023-01-{x}") for x in range(1, 4)]
    values = np.array([[1, 2, np.nan], [2, np.nan, 4.5], [3, 6, np.nan]])
    data = TimeIndexedData(ts, values, column_names=["a", "b", "c"])

    check_equal(
        utils.multivariate_interpolate_invalid_data(data),
        TimeIndexedData(ts, [[1, 2, 4.5], [2, 4, 4.5], [3, 6, 4.5]], column_names=["a", "b", "c"]),
    )


def test_multivariate_no_data():
    ts = [pd.Timestamp(f"2023-01-{x}") for x in range(1, 4)]
    values = np.array([[1, np.nan], [np.nan, np.nan], [3, np.nan]])
    data = TimeIndexedData(ts, values, column_names=["a", "b"])

    check_equal(
        utils.multivariate_interpolate_invalid_data(data),
        TimeIndexedData(ts, [[1, 0], [2, 0], [3, 0]], column_names=["a", "b"]),
    )


def test_multivariate_left_and_right():
    ts = [pd.Timestamp(f"2023-01-{x}") for x in range(1, 4)]
    values = np.array([[1, np.nan], [np.nan, np.nan], [3, np.nan]])
    data = TimeIndexedData(ts, values, column_names=["a", "b"])

    check_equal(
        utils.multivariate_interpolate_invalid_data(data),
        TimeIndexedData(ts, [[1, 0], [2, 0], [3, 0]], column_names=["a", "b"]),
    )
