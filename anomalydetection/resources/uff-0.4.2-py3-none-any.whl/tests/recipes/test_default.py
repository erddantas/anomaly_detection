#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import numpy as np
import pandas as pd
import pytest

from uff.recipes.default import default_univariate_forecast


@pytest.mark.parametrize(
    "time_array",
    [
        [pd.Timestamp("2022-01-01") + pd.Timedelta(days=x) for x in range(60)],
        [pd.Timestamp("2022-01-01") + pd.Timedelta(days=x) for x in range(60)] * 2,
        [pd.Timestamp("2022-01-30") - pd.Timedelta(days=x) for x in range(20)],
    ],
)
@pytest.mark.parametrize(
    "kwargs",
    [{"on_duplicate": np.mean}, {"prediction_interval_width": 0.99}],
)
def test_successful_e2e(time_array, kwargs):
    value = np.random.random(size=len(time_array))
    default_univariate_forecast(time_array, value, horizon=3, granularity="D", **kwargs)


def test_bad_input():
    with pytest.raises(ValueError):
        default_univariate_forecast([1, 2, 3, 4], [4, 5, 6], horizon=3, granularity="D")

    with pytest.raises(ValueError):
        default_univariate_forecast(
            [1, 2, 3, 4],
            [4, 5, 6, 7],
            horizon=3,
            granularity="D",
            on_duplicate="unrecognized option",
        )


def test_duplicate_raise():
    with pytest.raises(RuntimeError):
        default_univariate_forecast([1, 1, 2, 2], [1, 2, 3, 4], 3, "D", on_duplicate="raise")
