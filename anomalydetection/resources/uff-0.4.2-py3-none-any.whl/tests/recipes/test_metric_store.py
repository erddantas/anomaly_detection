#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from functools import partial
from typing import Generator

import numpy as np
import pandas as pd
import pytest
from pandas.api.types import is_integer_dtype

from uff.recipes import metric_store as ms


class MockSparkDf(ms.SparkDataFrame):
    def __init__(self, df: pd.DataFrame) -> None:
        self.df = df

    def toPandas(self) -> pd.DataFrame:
        return self.df.copy()


class MockSpark(ms.SparkContext):
    def createDataFrame(self, df: pd.DataFrame) -> MockSparkDf:
        return MockSparkDf(pd.DataFrame(df))


def generate_cases() -> Generator[partial, None, None]:
    kwargs = {"horizon": 3, "time_granularity": "DAY", "time_col": "ds"}

    n = 10
    time_stamps = [pd.Timestamp("2023-01-01") + pd.Timedelta(days=x) for x in range(n)]
    v1 = pd.Series(np.random.randn(n), dtype=float)
    v2 = pd.Series(np.random.randint(-3, 3, size=n), dtype=int)

    dfs = [
        pd.DataFrame({"v1": v1, "ds": time_stamps}),
        pd.DataFrame({"v1": v2, "ds": time_stamps}),
        pd.DataFrame({"v1": v1, "v2": v2, "ds": time_stamps}),
    ]

    dim_cols = [
        {
            "names": ["d1"],
            "values": [["a"], ["b"]],
            "dtypes": [np.dtype("object")],
        },
        {
            "names": ["d1", "d2"],
            "values": [["a", 1], ["b", 1], ["a", 2], ["b", 2]],
            "dtypes": [np.dtype("object"), np.dtype("int64")],
        },
    ]

    unused_cols = [
        {
            "name": "u1",
            "value": "unused",
            "dtype": np.dtype("object"),
        },
        {
            "name": "u1",
            "value": 1,
            "dtype": np.dtype("int64"),
        },
        {
            "name": "u1",
            "value": 1,
            "dtype": np.dtype("uint32"),
        },
    ]

    for df in dfs:
        value_cols = list(set(df.columns) - {"ds"})
        yield partial(ms.forecast_pandas_dataframe, df, value_cols=value_cols, **kwargs)

        for dim_col in dim_cols:
            dim_df = None
            for values in dim_col["values"]:
                grp_df = pd.DataFrame(
                    {
                        name: pd.Series([values[i]] * len(df), dtype=dim_col["dtypes"][i])
                        for i, name in enumerate(dim_col["names"])
                    }
                )
                joined = df.join(grp_df)
                if dim_df is None:
                    dim_df = joined
                else:
                    dim_df = pd.concat((dim_df, joined), ignore_index=True)

            yield partial(
                ms.forecast_pandas_dataframe,
                dim_df,
                value_cols=value_cols,
                dimension_cols=dim_col["names"],
                **kwargs,
            )

            for unused in unused_cols:
                new_col_df = pd.DataFrame(
                    {
                        unused["name"]: pd.Series(
                            [unused["value"]] * len(dim_df), dtype=unused["dtype"]
                        )
                    }
                )
                yield partial(
                    ms.forecast_pandas_dataframe,
                    dim_df.join(new_col_df),
                    value_cols=value_cols,
                    dimension_cols=dim_col["names"],
                    **kwargs,
                )


@pytest.mark.parametrize("task", list(generate_cases()))
def test_e2e(task):
    df = task.args[0]
    kwargs = task.keywords

    used_cols = set([kwargs["time_col"]] + kwargs["value_cols"] + kwargs.get("dimension_cols", []))
    unused_cols = set(df.columns) - used_cols

    res = task()

    for c in used_cols:
        assert res[c].dtype == df[c].dtype
    for c in unused_cols:
        coaleced_type = ms._STR_TO_NULLABLE_DTYPE.get(df[c].dtype.name.lower(), pd.Int64Dtype())
        assert res[c].dtype == coaleced_type if is_integer_dtype(df[c].dtype) else df[c].dtype
    for v in kwargs["value_cols"]:
        assert not res[v].isnull().any()
        for suffix in ("upper", "lower"):
            assert res[f"{v}_{suffix}"].dtype == np.dtype("float64")
            assert not res[f"{v}_{suffix}"].isnull().any()

    exp_columns = list(df.columns) + [
        f"{c}_{suf}" for c in kwargs["value_cols"] for suf in ("upper", "lower")
    ]
    assert list(res.columns) == list(exp_columns)

    if kwargs.get("dimension_cols"):
        assert all(
            len(grp_df) == kwargs["horizon"] for _, grp_df in res.groupby(kwargs["dimension_cols"])
        )
    else:
        assert len(res) == kwargs["horizon"]


def test_report_table_fcst():
    df = pd.DataFrame(
        {
            "time_granularity_start": ["2023-01-01", "2023-02-01", "2023-03-01"],
            "time_granularity_end": ["2023-01-31", "2023-02-28", "2023-03-31"],
            "time_granularity_id": ["calendar_month", "calendar_month", "calendar_month"],
            "metric_value": [1.0, 2.1, 3.0],
            "dimension_value": ["d1", "d1", "d1"],
            "metric_granularity": ["string", "string", "string"],
            "metric_granularity_id": ["string_id", "string_id", "string_id"],
            "metric_id": ["linear_metric", "linear_metric", "linear_metric"],
            "metric_name": ["linear metric", "linear metric", "linear metric"],
        }
    )

    spark = MockSpark()
    spark_df = MockSparkDf(df)
    horizon = 2

    fcst = ms.forecast_report_table(spark=spark, spark_df=spark_df, horizon=horizon)
    assert len(fcst.df) == horizon

    exp_columns = {c for c in df.columns if c != "metric_value"} | {
        "forecast",
        "forecast_upper",
        "forecast_lower",
    }
    assert set(fcst.df.columns) == exp_columns
