#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import pytest

import uff
from uff.base import Estimator, Forecaster, Transformer
from uff.forecasters.arima import ArimaForecaster
from uff.transformers import StlTransformer
from uff.utils import _ModelLookup


def test_names_unique():
    m = _ModelLookup()
    assert len(m._estimator_dict) == len(m.all_estimators)


def test_model_lookup():
    assert uff.get_estimator("ArimaForecaster") is ArimaForecaster

    with pytest.raises(KeyError):
        uff.get_estimator("NonExistentClassName")


def test_multi_model_lookup():
    assert uff.get_estimator(["ArimaForecaster", "StlTransformer"]) == [
        ArimaForecaster,
        StlTransformer,
    ]


def test_get_short_name():
    assert uff.get_estimator("ARIMA") is ArimaForecaster
    assert uff.get_estimator("SARIMAX") is ArimaForecaster


def test_all_estimators():
    all_est = uff.all_estimators()
    n_est = len(all_est)
    assert all(issubclass(e, Estimator) for e in all_est)

    forecasters = uff.all_estimators(subclasses=Forecaster)
    n_fcsts = len(forecasters)
    assert n_fcsts < n_est
    assert all(issubclass(e, Forecaster) for e in forecasters)

    forecasters_or_transformers = uff.all_estimators(subclasses=(Forecaster, Transformer))
    assert n_fcsts <= len(forecasters_or_transformers) <= n_est
    assert all(issubclass(e, (Forecaster, Transformer)) for e in forecasters)
