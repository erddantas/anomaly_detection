#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

from collections import OrderedDict
from tempfile import NamedTemporaryFile
from typing import Dict, List, Tuple

import cloudpickle
import pytest
from patsy.design_info import DesignInfo

from uff._dill import dump, dumps, load, loads


class MockClass:
    def __init__(self) -> None:
        self.design_info: DesignInfo = DesignInfo(["col1", "col2"])
        self.tuple_attr: Tuple = ("foo", "bar")
        self.list_attr: List = ["foo", "bar"]
        self.dict_attr: Dict = {"foo": "bar"}

    def __eq__(self, o: MockClass) -> bool:
        return (
            all([a == b for a, b in zip(self.design_info.column_names, o.design_info.column_names)])
            and self.tuple_attr == o.tuple_attr
            and self.list_attr == o.list_attr
            and self.dict_attr == o.dict_attr
        )


def test_cloudpickle_fails() -> None:
    # if fails, it indicates the workaround may no longer be needed
    with pytest.raises(NotImplementedError):
        cloudpickle.dumps(MockClass())


def test_dumps_loads() -> None:
    obj = MockClass()
    s = dumps(obj)
    assert isinstance(loads(s, recursive=False), OrderedDict)
    assert obj == loads(s)


def test_dump_load() -> None:
    obj = MockClass()
    with NamedTemporaryFile() as f:
        with open(f.name, "wb") as w:
            dump(obj, w)
        with open(f.name, "rb") as r:
            assert isinstance(load(r, recursive=False), OrderedDict)
            r.seek(0)  # reset read position
            assert obj == load(r)
