#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from functools import partial
from tempfile import TemporaryDirectory
from typing import Optional

import numpy as np
import pytest

from uff import TimeIndexedData, distributed
from uff.evaluation.backtest import BackTester
from uff.forecasters.arima import ArimaForecaster
from uff.meta import ColumnEnsembleEstimator


def test_traversal():
    input_output_pairs = [
        ([], []),
        ([1, 2, 3], [((0,), 1), ((1,), 2), ((2,), 3)]),
        (
            [[1, 2], [3, 4, 5], [90, [7, 8], 91]],
            [
                ((0, 0), 1),
                ((0, 1), 2),
                ((1, 0), 3),
                ((1, 1), 4),
                ((1, 2), 5),
                ((2, 0), 90),
                ((2, 1, 0), 7),
                ((2, 1, 1), 8),
                ((2, 2), 91),
            ],
        ),
        (
            [[1, 2], 90, 92, [6, 5, 4]],
            [
                ((0, 0), 1),
                ((0, 1), 2),
                ((1,), 90),
                ((2,), 92),
                ((3, 0), 6),
                ((3, 1), 5),
                ((3, 2), 4),
            ],
        ),
    ]
    for arg, exp in input_output_pairs:
        assert list(distributed._inorder_traversal(arg)) == exp


def test_apply_shape():
    assert distributed._apply_shape([], []) == []
    assert distributed._apply_shape([1, 2, 3], [None, None, None]) == [None, None, None]
    res = distributed._apply_shape(
        [None, [None, None], [None, [None]]],
        list(range(5)),
    )
    assert res == [0, [1, 2], [3, [4]]]
    res = distributed._apply_shape(
        [None, [None, None], None, [None, [None]]],
        list(range(6)),
    )
    assert res == [0, [1, 2], 3, [4, [5]]]


def test_conditional_execution_no_parallel():
    tasks = [
        partial(lambda x, y: x + y, 1, 2),
        partial(lambda x, y: x + y, 4, 2),
        partial(lambda x, y: x + y, 0, 2),
    ]
    assert distributed.conditional_distributed_evaluate(tasks) == [3, 6, 2]


def test_backtest():
    model = ArimaForecaster(enforce_invertibility=False, enforce_stationarity=False)
    back_tester = BackTester(
        TimeIndexedData(range(100), range(100)), min_fit_window_size=10, step_size=50
    )
    with distributed.distribute():
        back_tester.evaluate(model.params)


def _fit_forecast_column_ensemble(cache_dir: Optional[str] = None):
    ColumnEnsembleEstimator.min_distribution_size = 2
    model = ColumnEnsembleEstimator(
        ArimaForecaster(enforce_invertibility=False, enforce_stationarity=False),
        cache_dir=cache_dir,
    )
    data = TimeIndexedData(range(100), np.arange(200).reshape(100, 2))
    model.fit(data)
    model.forecast(data.future_time_index(10))


def test_non_serializable_ray():
    import ray

    ctx = ray.init()

    # If this doesn't break it means that ARIMA is serializable by ray.
    with pytest.raises(Exception):
        with distributed.distribute(ctx):
            _fit_forecast_column_ensemble()

    temp_dir = TemporaryDirectory()
    with distributed.distribute(ctx):
        _fit_forecast_column_ensemble(temp_dir.name)
