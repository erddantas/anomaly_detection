#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import pandas as pd

from uff import TimeIndex, TimeIndexedData
from uff.holidays import get_country_holidays


def test_get_country_holidays_empty():
    # Empty index yields an empty result by default
    assert get_country_holidays(TimeIndex([]), "US").shape == (0, 0)

    # Empty index yields a valid result with min_t and max_t
    res = get_country_holidays(
        TimeIndex([]), "US", min_t=pd.Timestamp("2020-01-01"), max_t=pd.Timestamp("2020-12-31")
    )
    assert res.shape == (0, 11)
    assert res.column_names == [
        "Christmas Day",
        "Columbus Day",
        "Independence Day",
        "Independence Day (observed)",
        "Labor Day",
        "Martin Luther King Jr. Day",
        "Memorial Day",
        "New Year's Day",
        "Thanksgiving",
        "Veterans Day",
        "Washington's Birthday",
    ]


def test_get_country_holidays_basic():
    index = TimeIndex(pd.date_range("2020-01-01", "2020-01-10"))
    res = get_country_holidays(index, "US")
    exp = TimeIndexedData.from_time_index(
        index,
        values=[[1], [0], [0], [0], [0], [0], [0], [0], [0], [0]],
        column_names=["New Year's Day"],
    )
    assert res == exp


def test_get_country_holidays_basic_with_kwarg():
    index = TimeIndex(pd.date_range("2020-01-01", "2020-01-10"))
    res = get_country_holidays(index, "US", subdiv="PR")
    exp = TimeIndexedData.from_time_index(
        index,
        values=[
            [0.0, 1.0],
            [0.0, 0.0],
            [0.0, 0.0],
            [0.0, 0.0],
            [0.0, 0.0],
            [1.0, 0.0],
            [0.0, 0.0],
            [0.0, 0.0],
            [0.0, 0.0],
            [0.0, 0.0],
        ],
        column_names=["Epiphany", "New Year's Day"],
    )
    assert res == exp


def test_get_country_holidays_basic_with_data():
    index = TimeIndex(pd.date_range("2020-01-01", "2020-01-10"))
    data = TimeIndexedData.from_time_index(index, range(10))
    res = get_country_holidays(data, "US")
    exp = TimeIndexedData.from_time_index(
        index,
        values=[[1], [0], [0], [0], [0], [0], [0], [0], [0], [0]],
        column_names=["New Year's Day"],
    )
    assert res == exp


def test_get_country_holidays_basic_with_ranges():
    index = TimeIndex(pd.date_range("2020-01-01", "2020-01-10"))
    res = get_country_holidays(
        index, "US", days_after={"Christmas Day": 10}, days_before={"Washington's Birthday": 40}
    )

    exp_columns = ["Christmas Day", "New Year's Day", "Washington's Birthday"]
    exp_values = [
        [1, 1, 0],
        [1, 0, 0],
        [1, 0, 0],
        [1, 0, 0],
        [0, 0, 0],
        [0, 0, 0],
        [0, 0, 0],
        [0, 0, 1],
        [0, 0, 1],
        [0, 0, 1],
    ]
    exp = TimeIndexedData.from_time_index(index, values=exp_values, column_names=exp_columns)
    assert res == exp


def test_get_country_holidays_basic_with_time_range():
    index = TimeIndex(pd.date_range("2020-01-01", "2020-01-10"))
    res = get_country_holidays(
        index, "US", min_t=pd.Timestamp("2019-01-01"), max_t=pd.Timestamp("2021-12-31")
    )
    exp_columns = [
        "Christmas Day",
        "Christmas Day (observed)",
        "Columbus Day",
        "Independence Day",
        "Independence Day (observed)",
        "Juneteenth National Independence Day",
        "Juneteenth National Independence Day (observed)",
        "Labor Day",
        "Martin Luther King Jr. Day",
        "Memorial Day",
        "New Year's Day",
        "New Year's Day (observed)",
        "Thanksgiving",
        "Veterans Day",
        "Washington's Birthday",
    ]
    exp_values = [
        [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
    ]
    exp = TimeIndexedData.from_time_index(index, values=exp_values, column_names=exp_columns)
    assert res == exp
