#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from tempfile import NamedTemporaryFile

from uff import io
from uff.base import Estimator
from uff.forecasters.arima import ArimaForecaster
from uff.transformers.stl import StlTransformer


class MyRandomEstimator(Estimator):
    def __init__(self, arg):
        self.arg = arg


def test_save_multiple():
    arima = ArimaForecaster(2, 1, 2)
    stl = StlTransformer(7)
    rand = MyRandomEstimator(42)

    f = NamedTemporaryFile()
    io.save_multiple([arima, stl, rand], f.name)

    arima2, stl2, rand2 = io.load_multiple(f.name)

    assert isinstance(arima2, ArimaForecaster)
    assert arima2.init_kwargs == arima.init_kwargs
    assert isinstance(stl2, StlTransformer)
    assert stl2.kwargs == stl.kwargs
    assert isinstance(rand2, MyRandomEstimator)
    assert rand2.arg == rand.arg
