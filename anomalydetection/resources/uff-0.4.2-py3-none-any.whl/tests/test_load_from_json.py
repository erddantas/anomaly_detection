#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import json
from typing import List

import numpy as np
import pytest

from uff import load_estimator_from_json
from uff.base import Estimator
from uff.forecasters.miniprophet import MiniProphetForecaster
from uff.meta import ColumnEnsembleEstimator, TransformedOutputForecaster
from uff.transformers.math import LogTransformer


def eval_combinations(spec) -> List[Estimator]:
    return [
        load_estimator_from_json(json.dumps(spec)),
        load_estimator_from_json(spec),
    ]


def mini_prophet_spec():
    return {
        "cls": "MiniProphetForecaster",
        "kwargs": {"prediction_interval_width": 0.8},
    }


def meta_spec():
    return {
        "cls": "TransformedOutputForecaster",
        "kwargs": {"transformers": [{"cls": "LogTransformer"}], "forecaster": mini_prophet_spec()},
    }


def nested_meta_spec():
    return {
        "cls": "ColumnEnsembleEstimator",
        "kwargs": {
            "estimator": meta_spec(),
        },
    }


@pytest.mark.parametrize("est", eval_combinations(mini_prophet_spec()))
def test_basic(est):
    assert np.isclose(est.prediction_interval_width, 0.8)
    assert isinstance(est, MiniProphetForecaster)


@pytest.mark.parametrize("est", eval_combinations(meta_spec()))
def test_composition(est):
    assert isinstance(est, TransformedOutputForecaster)
    assert np.isclose(est.prediction_interval_width, 0.8)
    assert isinstance(est._forecaster, MiniProphetForecaster)
    assert isinstance(est._transformers[0], LogTransformer)


@pytest.mark.parametrize("est", eval_combinations(nested_meta_spec()))
def test_nested_composition(est):
    assert isinstance(est, ColumnEnsembleEstimator)
    assert np.isclose(est.prediction_interval_width, 0.8)
    assert isinstance(est._default_estimator, TransformedOutputForecaster)
    assert np.isclose(est._default_estimator.prediction_interval_width, 0.8)
    assert isinstance(est._default_estimator._forecaster, MiniProphetForecaster)
    assert isinstance(est._default_estimator._transformers[0], LogTransformer)


def test_raise_on_missing_cls():
    with pytest.raises(ValueError) as exc_info:
        load_estimator_from_json({"args": [1, 2]})

    assert str(exc_info.value) == "Expected a dictionary with a 'cls' key."


def test_raise_on_extra_keys():
    spec = mini_prophet_spec()
    spec["unrecognized_key"] = 1
    with pytest.raises(ValueError) as exc_info:
        load_estimator_from_json(spec)

    assert str(exc_info.value) == "Unexpected keys in dictionary: unrecognized_key"
