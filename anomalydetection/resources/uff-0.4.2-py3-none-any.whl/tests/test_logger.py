#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import warnings

import pytest

from uff import logger


def test_get_logger_singleton():
    l1 = logger.get_logger()
    l2 = logger.get_logger()
    assert l1 is l2


def test_no_bugs():
    logger.info("info")
    logger.warning("warning")
    logger.set_level(20)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        logger.raise_warning("raised warning")


def test_route_raised_warnings_to_logger():
    with pytest.warns(UserWarning):
        logger.raise_warning("raised warning")

    with logger.route_raised_warnings_to_logger():
        # Will trow an error if a warnings is thrown
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            logger.raise_warning("raised warning")
