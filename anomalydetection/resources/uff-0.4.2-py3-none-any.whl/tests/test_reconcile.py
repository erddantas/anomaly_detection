#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from typing import List, Optional, Tuple, Type

import numpy as np
import pandas as pd
import pytest
from pandas.testing import assert_frame_equal

import uff
from uff.reconcile import (
    BaseReconciler,
    BottomUpReconciler,
    ErmReconciler,
    MiddleOutReconciler,
    MinTraceReconciler,
    OptimalCombinationReconciler,
    TopDownReconciler,
    _parse_data,
)
from uff.tstypes import TimeIndexedOutput, TimeIndexedOutputWithInterval

ALL_RECONCILERS = (
    BottomUpReconciler,
    ErmReconciler,
    MiddleOutReconciler,
    MinTraceReconciler,
    OptimalCombinationReconciler,
    TopDownReconciler,
)


def realistic_example(strictly_hierarchical: bool = False, mean_0: bool = False):
    accounts = [
        {
            "id": i,
            "country": np.random.choice(["US", "CA"]),
            "vertical": np.random.choice(["Tech", "Retail"]),
        }
        for i in range(40)
    ]

    df = pd.DataFrame(
        [
            {
                "ds": pd.Timestamp("2023-01-01") + pd.Timedelta(days=days),
                "revenue": np.random.normal(0 if mean_0 else 4),
                "cost": np.random.normal(0 if mean_0 else 2),
                "country": acct["country"],
                "vertical": acct["vertical"],
                "account": acct["id"],
            }
            for days in range(200)
            for acct in accounts
        ]
    )

    bottom = uff.TimeIndexedData.from_pandas(
        df,
        value_col=["revenue", "cost"],
        time_col="ds",
        group_by=["country", "vertical", "account"],
    )

    top = bottom.aggregate(0)
    geo = bottom.aggregate((0, 1))
    vert = bottom.aggregate((0, 2))

    if strictly_hierarchical:
        return uff.hstack((top, geo, bottom))

    return uff.hstack((top, geo, vert, bottom))


def minimal_example():
    bottom = uff.TimeIndexedData(
        [1, 2, 3, 4, 5],
        np.arange(20).reshape(5, 4),
        column_names=[
            ("top", "A", 1),
            ("top", "A", 2),
            ("top", "B", 1),
            ("top", "B", 2),
        ],
    )
    middle = bottom.aggregate((0, 1))
    top = bottom.aggregate(0)
    return uff.hstack((top, middle, bottom))


def all_method_combinations(
    in_sample: Optional[bool] = None,
    exclude: Optional[Tuple[Type]] = None,
    supports_intervals: Optional[bool] = None,
    supports_nonnegative: Optional[bool] = None,
) -> List[BaseReconciler]:
    exclude = exclude or []
    res = []
    for cls in ALL_RECONCILERS:
        if cls in exclude:
            continue
        if cls == BottomUpReconciler:
            res.append(BottomUpReconciler())
        elif cls == MiddleOutReconciler:
            for method in cls.methods:
                res.append(cls(middle_level=2, method=method))
        elif cls in (MinTraceReconciler, OptimalCombinationReconciler):
            for method in cls.methods:
                for nonnegative in (True, False):
                    res.append(cls(method=method, nonnegative=nonnegative))
        else:
            for method in cls.methods:
                res.append(cls(method))

    if in_sample is not None:
        insample_reconcilers = [obj for obj in res if obj.use_insample]
        outofsample_reconcilers = [obj for obj in res if not obj.use_insample]
        res = insample_reconcilers if in_sample else outofsample_reconcilers

    if supports_intervals is not None:
        intervals = [obj for obj in res if obj.supports_intervals]
        no_intervals = [obj for obj in res if not obj.supports_intervals]
        res = intervals if supports_intervals else no_intervals

    if supports_nonnegative is not None:
        nonnegative = [
            obj
            for obj in res
            if isinstance(obj, (MinTraceReconciler, OptimalCombinationReconciler))
        ]
        others = [
            obj
            for obj in res
            if not isinstance(obj, (MinTraceReconciler, OptimalCombinationReconciler))
        ]
        res = nonnegative if supports_nonnegative else others

    return res


def test_parse_data_basic():
    data = minimal_example()
    res = _parse_data(data)

    S = pd.DataFrame(
        [
            [1, 1, 1, 1],  # top
            [1, 1, 0, 0],  # A
            [0, 0, 1, 1],  # B
            [1, 0, 0, 0],  # A1
            [0, 1, 0, 0],  # A2
            [0, 0, 1, 0],  # B1
            [0, 0, 0, 1],  # B2
        ],
        columns=["3", "4", "5", "6"],
        index=["0", "1", "2", "3", "4", "5", "6"],
        dtype=np.float64,
    )
    assert_frame_equal(S, res.S_df)

    tags = {"1": ["0"], "2": ["1", "2"], "3": ["3", "4", "5", "6"]}
    assert res.tags == tags


@pytest.mark.parametrize("reconciler", all_method_combinations(in_sample=True))
def test_e2e_in_sample(reconciler):
    strict = isinstance(reconciler, (TopDownReconciler, MiddleOutReconciler))
    data = realistic_example(strictly_hierarchical=strict)
    no_overlap = uff.temporal_split(data, 0.5)
    partial_overlap = (data.slice(0, 130), data.slice(20))
    full_overlap = (data.slice(0, 130), data)
    for in_sample, fcst in (no_overlap, partial_overlap, full_overlap):
        if isinstance(reconciler, MinTraceReconciler) and in_sample.strictly_before(fcst):
            # MinTraceReconciler requires fcst vs. observed residuals
            continue

        fcst += np.random.normal(loc=1.0, scale=0.01, size=fcst.shape)
        for arg in (fcst, TimeIndexedOutput(fcst)):
            out = reconciler.reconcile(arg, in_sample_data=in_sample).out
            assert out.same_shape(fcst)


@pytest.mark.parametrize("reconciler", all_method_combinations(in_sample=False))
def test_e2e_no_insample(reconciler):
    strict = isinstance(reconciler, (TopDownReconciler, MiddleOutReconciler))
    data = realistic_example(strictly_hierarchical=strict)
    for arg in (data, TimeIndexedOutput(data)):
        out = reconciler.reconcile(arg).out
        assert out.same_shape(data)


@pytest.mark.parametrize("reconciler", all_method_combinations(supports_intervals=True))
@pytest.mark.parametrize("method", ["normality", "permbu"])
@pytest.mark.parametrize("num_samples", [None, 200])
def test_e2e_with_interval(reconciler, method, num_samples):
    strict = method == "permbu" or isinstance(reconciler, (TopDownReconciler, MiddleOutReconciler))
    data = realistic_example(strictly_hierarchical=strict)
    partial_overlap = (data.slice(0, 130), data.slice(20))
    full_overlap = (data.slice(0, 130), data)
    for in_sample, fcst in [partial_overlap, full_overlap]:
        fcst += np.random.normal(loc=1.0, scale=0.01, size=fcst.shape)
        arg = TimeIndexedOutputWithInterval(fcst, fcst + 2, fcst - 2, interval_width=0.9)

        if reconciler.nonnegative and method == "permbu":
            with pytest.raises(ValueError):
                reconciler.reconcile(
                    arg,
                    in_sample_data=in_sample,
                    intervals_method=method,
                    num_samples=num_samples,
                )
        else:
            res = reconciler.reconcile(
                arg,
                in_sample_data=in_sample,
                intervals_method=method,
                num_samples=num_samples,
            )
            assert isinstance(res, TimeIndexedOutputWithInterval)
            assert np.isclose(res.interval_width, arg.interval_width)
            assert np.all((res.upper >= res.out).values)
            assert np.all((res.lower <= res.out).values)
            assert res.out.same_shape(fcst)


@pytest.mark.parametrize("reconciler", all_method_combinations(supports_intervals=True))
@pytest.mark.parametrize("num_samples", [None, 200])
def test_e2e_with_bootstrap_interval(reconciler, num_samples):
    strict = isinstance(reconciler, (TopDownReconciler, MiddleOutReconciler))
    data = realistic_example(strictly_hierarchical=strict)

    in_sample_data = data.slice(0, 130)
    in_sample_fcst = in_sample_data + np.random.normal(loc=0, scale=5, size=in_sample_data.shape)

    out_of_sample_fcst = data.slice(120)
    arg = TimeIndexedOutputWithInterval(
        out_of_sample_fcst,
        out_of_sample_fcst + 2,
        out_of_sample_fcst - 2,
        interval_width=0.9,
    )

    if reconciler.nonnegative:
        with pytest.raises(ValueError):
            reconciler.reconcile(
                arg,
                in_sample_data=in_sample_data,
                in_sample_forecasts=in_sample_fcst,
                intervals_method="bootstrap",
                num_samples=num_samples,
            )
    else:
        res = reconciler.reconcile(
            arg,
            in_sample_data=in_sample_data,
            in_sample_forecasts=in_sample_fcst,
            intervals_method="bootstrap",
            num_samples=num_samples,
        )
        assert isinstance(res, TimeIndexedOutputWithInterval)
        assert np.isclose(res.interval_width, arg.interval_width)
        assert np.all((res.upper >= res.out).values)
        assert np.all((res.lower <= res.out).values)
        assert res.out.same_shape(out_of_sample_fcst)


def test_determinism():
    data_gen = []
    results = []
    for _ in range(4):
        with uff.deterministic_rng(42):
            data = realistic_example(strictly_hierarchical=True)  # Some randomness
            in_sample, fcst = data.slice(0, 130), data.slice(100)
            res = MinTraceReconciler("ols").reconcile(
                TimeIndexedOutputWithInterval(fcst, fcst + 1, fcst - 1, 0.9),
                in_sample_data=in_sample,
                intervals_method="permbu",
            )
            data_gen.append(data)
            results.append(res)

    assert all(data_gen[i] == data_gen[0] for i in range(len(data_gen)))
    assert all(results[i].out == results[0].out for i in range(len(results)))


@pytest.mark.parametrize("reconciler", all_method_combinations(supports_nonnegative=True))
def test_nonnegative(reconciler):
    if reconciler.nonnegative:
        data = realistic_example(strictly_hierarchical=True, mean_0=True)
        in_sample = data.slice(0, 130)

        # Add noise
        data += np.random.normal(0, 0.5, data.shape)
        # Add negative trend
        data -= 0.1 * np.arange(len(data)).reshape(len(data), 1)

        # With intervals
        intervals = TimeIndexedOutputWithInterval(data, data + 0.2, data - 0.2, interval_width=0.9)

        for arg in (data, intervals):
            res = reconciler.reconcile(arg, in_sample_data=in_sample)
            assert np.all(res.out.values >= 0)
