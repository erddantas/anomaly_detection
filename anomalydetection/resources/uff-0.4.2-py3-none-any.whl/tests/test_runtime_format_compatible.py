#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import os
from pathlib import Path
from typing import List

PREAMBLE = """#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#
"""


def get_all_runtime_fmt_files() -> List[str]:
    root_path = os.path.abspath(os.path.join(Path(__file__).parent.parent))
    subdirectories = ("tests", "uff")
    all_files = []
    for subdirectory in subdirectories:
        abs_path = os.path.join(root_path, subdirectory)
        for root, _, files in os.walk(abs_path):
            for file in files:
                if file.endswith(".py"):
                    all_files.append(os.path.join(root, file))
    return all_files


def test_runtime_format_compatible():
    failed = []
    for fname in get_all_runtime_fmt_files():
        with open(fname, "r") as f:
            for line in f:
                if len(line.rstrip("\n")) > 100:
                    failed.append(fname)
                    print(line)
                    break

    assert len(failed) == 0, f"Following files have lines longer than 100 characters: {failed}"


def test_required_files_have_preamble():
    failed = []
    for fname in get_all_runtime_fmt_files():
        with open(fname, "r") as f:
            if not f.read().startswith(PREAMBLE):
                failed.append(fname)

    assert len(failed) == 0, f"Following files do not have the required preamble: {failed}"
