#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import json
from datetime import timedelta
from tempfile import NamedTemporaryFile

import numpy as np
import pandas as pd
import pytest
from pandas.tseries.offsets import CustomBusinessDay, DateOffset

import uff
from uff import All, time_range
from uff import tstypes as tst
from uff.consts import EPOCH_TIME_NO_TZ, ONE_DAY, ONE_SECOND
from uff.tstypes import _NonePlaceholder


def test_placeholders():
    assert _NonePlaceholder != All
    assert type(_NonePlaceholder) == type(All)
    assert hash(_NonePlaceholder) != hash(All)
    assert _NonePlaceholder == _NonePlaceholder
    assert _NonePlaceholder != None
    assert All == All
    for ph in (_NonePlaceholder, All):
        assert ph < None
        assert ph < 1
        assert ph < "hello"
        assert ph < pd.Timestamp("2024-01-01")
        assert ph < pd.Timestamp("2024-04-01").to_pydatetime()
        assert ph < pd.Timestamp("2024-04-01").date()


def test_group_dimensions():
    data = tst.TimeIndexedData([1, 2, 3], [1, 2, 3])
    assert data.n_group_dimensions() == 1

    data = tst.TimeIndexedData(
        [1, 2, 3], np.arange(9).reshape(3, 3), column_names=[(1, 2), (2, 3), (4, 5)]
    )
    assert data.n_group_dimensions() == 2


def test_getitem():
    # A pandas like API that returns a different output type depending on the input.
    data = tst.TimeIndexedData([1, 2, 3], [[1, 2], [3, 4], [5, 6]], column_names=["y1", "y2"])

    np.testing.assert_allclose(data["y1"], np.array([1.0, 3.0, 5.0]))
    assert data[["y1"]] == tst.TimeIndexedData([1, 2, 3], [[1], [3], [5]], column_names=["y1"])


def test_contains_aggregates():
    data = tst.TimeIndexedData([1, 2, 3], [1, 2, 3])
    assert not data.contains_agggregates()

    data = tst.TimeIndexedData([1, 2, 3], [1, 2, 3], column_names=[("revenue", uff.All)])
    assert data.contains_agggregates()


def test_unaggregated_only():
    data = tst.TimeIndexedData(
        [1, 2, 3],
        np.arange(12).reshape(3, 4),
        column_names=[
            ("cost", "US", 1),
            ("cost", "US", 2),
            ("cost", "US", uff.All),
            ("cost", uff.All, uff.All),
        ],
    )
    assert data.unaggregated_columns_only() == data.select([("cost", "US", 1), ("cost", "US", 2)])


def test_get_aggregated_columns():
    data = tst.TimeIndexedData(
        [1, 2, 3],
        np.arange(12).reshape(3, 4),
        column_names=[
            ("cost", "US", 1),
            ("cost", "US", 2),
            ("cost", "US", uff.All),
            ("cost", uff.All, uff.All),
        ],
    )
    assert sorted(data.get_aggregated_columns(("cost", uff.All, uff.All))) == [
        ("cost", "US", 1),
        ("cost", "US", 2),
    ]


def test_sort_columns():
    d1 = pd.Timestamp("2024-01-01").date()
    d2 = pd.Timestamp("2024-01-02").date()
    data = tst.TimeIndexedData(
        [1, 2, 3],
        np.arange(12).reshape(3, 4),
        column_names=[
            ("cost", "US", d1),
            ("cost", "US", d2),
            ("cost", "US", uff.All),
            ("cost", uff.All, uff.All),
        ],
    )
    res = data.sort_columns()
    assert res == data.select(
        [
            ("cost", uff.All, uff.All),
            ("cost", "US", uff.All),
            ("cost", "US", d1),
            ("cost", "US", d2),
        ]
    )


def test_aggregate():
    data = tst.TimeIndexedData(
        [1, 2, 3],
        np.arange(6).reshape(3, 2),
        column_names=[
            ("cost", "US", 1),
            ("cost", "US", 2),
        ],
    )
    assert data.aggregate(0) == tst.TimeIndexedData(
        [1, 2, 3], [[1], [5], [9]], column_names=[("cost", uff.All, uff.All)]
    )

    assert data.aggregate(0, np.mean) == tst.TimeIndexedData(
        [1, 2, 3], [[0.5], [2.5], [4.5]], column_names=[("cost", uff.All, uff.All)]
    )


def test_time_index_missing():
    ti = tst.TimeIndex(
        [pd.Timestamp(f"2023-01-{d}") for d in (5, 6, 9, 10)],
        granularity="B",
    )
    assert ti.missing_time_stamps() == []

    ti = tst.TimeIndex(
        [pd.Timestamp(f"2023-01-{d}") for d in (5, 6, 10)],
        granularity="B",
    )
    assert ti.missing_time_stamps() == [pd.Timestamp("2023-01-09")]

    ti = tst.TimeIndex(
        [pd.Timestamp(f"2023-01-{d}") for d in (5, 6, 9, 10)],
        granularity=pd.Timedelta(days=1),
    )
    assert ti.missing_time_stamps() == [pd.Timestamp(f"2023-1-{d}") for d in (7, 8)]


def test_time_index_granularity_determination():
    # ONE_SECOND is the arbitrary default
    assert tst.TimeIndex([]).granularity == ONE_SECOND

    # Timestamp fields are used if there is only a single entry
    # Since this value falls on the day boundary (EPOCH_TIME_NO_TZ) we select one day
    assert tst.TimeIndex([0]).granularity == DateOffset(days=1)
    # Since this value has some .second values, we select ONE_SECOND
    assert tst.TimeIndex([1]).granularity == ONE_SECOND

    # GCD is used to determine the granularity of a series
    assert tst.TimeIndex([60, 120, 180, 300]).granularity == 60 * ONE_SECOND


def test_time_index_bad_input():
    with pytest.raises(ValueError):
        # 2022-01-01 is not a month end
        tst.TimeIndex([0], granularity="M", unixtime_t0=pd.Timestamp("2022-01-01"))

    with pytest.raises(ValueError):
        # Must be strictly increasing after converting to integers
        tst.TimeIndex([0, 0.5, 1, 1.5])

    with pytest.raises(ValueError):
        # Must be strictly increasing according to granularity
        tst.TimeIndex(["2022-01-01", "2022-01-02"], granularity="2D")


def test_time_index_numeric_values():
    ti = tst.TimeIndex([0, 1, 2])
    assert ti.int_values == [0, 1, 2]
    assert ti.future(n_steps=3).int_values == [3, 4, 5]

    ti = tst.TimeIndex([120, 180, 300])
    assert ti.int_values == [120, 180, 300]
    assert ti.future(n_steps=2, n_steps_past=2).int_values == [180, 300, 360, 420]


def test_time_index_timestamp_values():
    # Basic case
    ti = tst.TimeIndex(
        [pd.Timestamp(f"2023-01-{d}") for d in range(2, 7)],
        granularity=ONE_DAY,
    )
    exp_out = [pd.Timestamp(f"2023-01-{d}") for d in (4, 5, 6, 7, 8)]
    assert ti.future(n_steps=2, n_steps_past=3).timestamp_values == exp_out

    # Business days
    ti = tst.TimeIndex(
        [pd.Timestamp(f"2023-01-{d}") for d in (3, 4, 5)],
        granularity="B",
    )
    exp_out = [pd.Timestamp(f"2023-01-{d}") for d in (6, 9, 10)]
    assert ti.future(n_steps=3).timestamp_values == exp_out


def test_time_index_unix_time():
    ts_in = [pd.Timestamp(f"2023-01-{d}") for d in (1, 2, 3, 4)]

    # Default units
    t0 = EPOCH_TIME_NO_TZ
    unit = ONE_SECOND
    unixtimes = tst.TimeIndex(
        ts_in,
        unixtime_t0=t0,
        unixtime_unit=unit,
    ).int_values
    assert unixtimes == [(t - t0) // unit for t in ts_in]

    # Weird units
    t0 = pd.Timestamp("2023-01-01")
    unit = ONE_DAY
    unixtimes = tst.TimeIndex(
        ts_in,
        unixtime_t0=t0,
        unixtime_unit=unit,
    ).int_values
    assert unixtimes == [0, 1, 2, 3]


def test_time_indexed_data_pandas_load():
    df = pd.DataFrame({"time": [1, 2, 3, 4, 5], "x1": [1, 0, 1, 0, 1], "x2": [4, 5, 6, 7, 8]})

    data = tst.TimeIndexedData.from_pandas(df, value_col=["x1", "x2"], time_col="time")

    assert np.array_equal(data.int_time_index(), np.array([1, 2, 3, 4, 5]))
    assert data.column_names == ["x1", "x2"]
    assert np.array_equal(data.values, df[["x1", "x2"]].to_numpy(dtype=np.float64))


def test_load_pandas_sparse_dates_in_groupbys():
    t1 = pd.Timestamp("2024-04-01").date()

    df = pd.DataFrame(
        {
            "time": [1, 2, 3, 1, 2],
            "x1": [1, 0, 1, 0, 1],
            "x2": [4, 5, 6, 7, 8],
            "d1": [t1, t1, t1, None, None],
        }
    )

    data = tst.TimeIndexedData.from_pandas(
        df, value_col=["x1", "x2"], time_col="time", group_by=["d1"]
    )
    data = data.sort_columns()

    assert np.array_equal(data.int_time_index(), np.array([1, 2, 3]))
    assert data.column_tuples == [("x1", None), ("x1", t1), ("x2", None), ("x2", t1)]
    assert np.array_equal(
        data.values,
        [
            [0.0, 1.0, 7.0, 4.0],
            [1.0, 0.0, 8.0, 5.0],
            [np.nan, 1.0, np.nan, 6.0],
        ],
        equal_nan=True,
    )


def test_pandas_load_duplicate_timestamps():
    df = pd.DataFrame({"time": [1, 1, 3, 4, 5], "x1": [1, 0, 1, 0, 1], "x2": [4, 5, 6, 7, 8]})
    with pytest.raises(ValueError):
        _ = tst.TimeIndexedData.from_pandas(df, value_col=["x1", "x2"], time_col="time")

    # Duplicates in group-by are OK
    df = pd.DataFrame(
        {"time": [1, 2, 3, 1, 2], "y": [1, 0, 1, 0, 1], "group": ["a", "a", "a", "b", "b"]}
    )
    _ = tst.TimeIndexedData.from_pandas(df, value_col="y", time_col="time", group_by=["group"])

    # Per-group values must be unique
    df = pd.DataFrame(
        {"time": [1, 1, 3, 1, 2], "y": [1, 0, 1, 0, 1], "group": ["a", "a", "a", "b", "b"]}
    )
    with pytest.raises(ValueError):
        _ = tst.TimeIndexedData.from_pandas(df, value_col="y", time_col="time", group_by=["group"])


def test_pandas_load_none_group():
    df = pd.DataFrame({"v": [1, 2, 3, 4, 5], "group": ["a", "a", None, None, None]})
    data = tst.TimeIndexedData.from_pandas(df, value_col="v", group_by=["group"])
    assert set(data.column_names) == {("v", "a"), ("v", None)}

    df = pd.DataFrame({"v": [1, 2, 3], "g1": [None, None, None], "g2": [np.nan, np.nan, np.nan]})
    data = tst.TimeIndexedData.from_pandas(df, value_col="v", group_by=["g1", "g2"])
    assert data.column_tuples == [("v", None, np.nan)]


def test_long_format_out():
    data = tst.TimeIndexedData(range(5), np.random.rand(5, 3))

    multivariate_hierarchy = [
        ("revenue", "NA", "US"),
        ("revenue", "NA", "MX"),
        ("cost", "NA", "US"),
    ]
    data = data.set_column_names(multivariate_hierarchy)
    df = data.to_long_format_pandas(
        time_col="time", metric_level=0, dimension_columns=["region", "country"]
    )
    assert set(df.columns) == {"time", "region", "country", "revenue", "cost"}
    assert set(df.region) == {"NA"}
    assert set(df.country) == {"US", "MX"}

    univariate_hierarchy = [
        ("revenue", "NA", "US"),
        ("revenue", "NA", "MX"),
        ("revenue", "EU", "UK"),
    ]
    data = data.set_column_names(univariate_hierarchy)
    df = data.to_long_format_pandas(
        time_col="time", metric_level=0, dimension_columns=["region", "country"]
    )
    assert set(df.columns) == {"time", "region", "country", "revenue"}
    assert set(df.region) == {"NA", "EU"}
    assert set(df.country) == {"US", "MX", "UK"}

    df = data.to_long_format_pandas(time_col="time", metric_level=0)
    assert set(df.columns) == {"time", "dim_0", "dim_1", "revenue"}
    assert set(df.dim_0) == {"NA", "EU"}
    assert set(df.dim_1) == {"US", "MX", "UK"}

    df = data.to_long_format_pandas(time_col=None, metric_level=0)
    assert set(df.columns) == {"dim_0", "dim_1", "revenue"}
    assert set(df.dim_0) == {"NA", "EU"}
    assert set(df.dim_1) == {"US", "MX", "UK"}

    flat = ["revenue", "cost", "users"]
    data = data.set_column_names(flat)
    df = data.to_pandas(time_col="time")
    long_df = data.to_long_format_pandas(time_col="time")
    pd.testing.assert_frame_equal(df, long_df)
    assert set(df.columns) == {"time", "revenue", "cost", "users"}


def test_time_indexed_data_pandas_out():
    df = pd.DataFrame({"time": [1, 2, 3, 4, 5], "x1": [1, 0, 1, 0, 1], "x2": [4, 5, 6, 7, 8]})

    data = tst.TimeIndexedData.from_pandas(df, value_col=["x1", "x2"], time_col="time")
    df_out = data.to_pandas(time_col="time")
    assert set(df.columns) == set(df_out.columns)
    for c in df.columns:
        assert np.array_equal(df[c].to_numpy(), df_out[c].to_numpy())


def test_time_indexed_data_pandas_load_index():
    df = pd.DataFrame(
        data={"x1": [1, 0, 1, 0, 1], "x2": [4, 5, 6, 7, 8]},
        index=[3, 5, 6, 8, 9],
    )

    data = tst.TimeIndexedData.from_pandas(df, value_col=["x1", "x2"])

    assert np.array_equal(data.int_time_index(), np.array([3, 5, 6, 8, 9]))


def test_time_indexed_data_pandas_load_datetime():
    t_col = [pd.Timestamp(year=2022, month=1, day=2) + (n * ONE_SECOND) for n in (1, 2, 3, 4)]
    unix_times = [(t - EPOCH_TIME_NO_TZ) // ONE_SECOND for t in t_col]
    df = pd.DataFrame(data={"x1": [1, 0, 1, 0], "t": t_col})
    data = tst.TimeIndexedData.from_pandas(
        df,
        value_col=["x1"],
        time_col="t",
        granularity=ONE_SECOND,
        unixtime_t0=EPOCH_TIME_NO_TZ,
        unixtime_unit=ONE_SECOND,
    )

    assert np.array_equal(data.int_time_index(), np.array(unix_times))


def test_time_indexed_data_slice():
    t = tst.TimeIndexedData(time_array=np.arange(5), values=2 * np.arange(5))

    # Intervals are half open
    t2 = t.slice(2, 4)
    assert np.array_equal(t2.int_time_index(), [2, 3])
    assert np.array_equal(t2.values, [4, 6])

    # If no end is specified, the slice goes to the end of the array
    t3 = t.slice(2)
    assert np.array_equal(t3.int_time_index(), [2, 3, 4])
    assert np.array_equal(t3.values, [4, 6, 8])

    # Negative indices work
    t4 = t.slice(-2)
    assert np.array_equal(t4.int_time_index(), [3, 4])
    assert np.array_equal(t4.values, [6, 8])


def test_time_index_slice():
    t = tst.TimeIndex([1, 2, 3, 4, 5])

    assert t.slice(2) == tst.TimeIndex([3, 4, 5])
    assert t.slice(1, 4) == tst.TimeIndex([2, 3, 4])
    assert t.slice(-2) == tst.TimeIndex([4, 5])
    assert len(t.slice(15)) == 0


def test_time_index_data_eq():
    t1 = tst.TimeIndexedData([1, 2, 3], [4, 5, 6])
    t2 = tst.TimeIndexedData([1, 2, 3], [4, 5, 6])

    assert t1 == t2

    t3 = tst.TimeIndexedData([1, 2, 3], [4, 5, 6], unixtime_unit=t1.unixtime_unit * 2)
    assert t3 != t1

    t4 = t1.slice(0, len(t1))
    assert t4 == t1

    t5 = tst.TimeIndexedData([1, 2, 3], np.arange(6).reshape(3, 2))
    t6 = tst.TimeIndexedData([1, 2, 3], np.arange(6).reshape(3, 2))
    t7 = tst.TimeIndexedData(
        [1, 2, 3], np.arange(6).reshape(3, 2), column_names=["random", "stuff"]
    )
    assert t5 == t6
    assert t5 != t7


def test_time_index_data_get_column():
    values = np.arange(24).reshape(8, 3)
    t = tst.TimeIndexedData(time_array=np.arange(8), values=values, column_names=["a", "b", "c"])
    assert np.array_equal(t["b"], values[:, 1])


def test_time_index_data_simple_arithmetic():
    tseries = [
        tst.TimeIndexedData([0, 1, 2], [10, 10, 10]),
        tst.TimeIndexedData(np.arange(5), np.arange(15).reshape(5, 3)),
        tst.TimeIndexedData(np.arange(6), np.arange(36).reshape(6, 3, 2)),
        tst.TimeIndexedData(np.arange(6), np.arange(36).reshape(6, 3, 2) - 12),
        tst.TimeIndexedData(np.arange(5), -np.arange(15).reshape(5, 3)),
    ]

    ops = [
        lambda x: x + 2,
        lambda x: 2 + x,
        lambda x: x - 2,
        lambda x: 2 - x,
        lambda x: 2 * x,
        lambda x: x * 2,
        lambda x: x / 2,
        lambda x: x // 2,
        lambda x: x**2,
        lambda x: 2**x,
        lambda x: -x,
        lambda x: +x,
        lambda x: abs(x),
        lambda x: x >= 1,
        lambda x: x <= 0,
        lambda x: x > 4,
        lambda x: x < 2,
        lambda x: 3 < x,
        lambda x: 2 <= x,
    ]
    for data in tseries:
        for op in ops:
            exp = tst.TimeIndexedData(
                data.pd_timestamp_index(),
                op(data.values),
                column_names=data.column_names,
                granularity=data.granularity,
                unixtime_t0=data.unixtime_t0,
                unixtime_unit=data.unixtime_unit,
            )
            assert op(data) == exp

    # Test path where another object is also TimeIndexedData
    a = tst.TimeIndexedData([0], [1])
    b = tst.TimeIndexedData([0], [4])
    assert a - b == tst.TimeIndexedData([0], [-3])

    # Test __rdiv__ and __rfloordiv__
    x = tst.TimeIndexedData([0], [4])
    assert 2 / x == tst.TimeIndexedData([0], [0.5])
    assert 13 // x == tst.TimeIndexedData([0], [3])


def test_make_dense():
    t = tst.TimeIndexedData([pd.Timestamp(f"2022-1-{d}") for d in (1, 2, 3, 5, 6)], [2, 2, 2, 2, 2])
    dense_t_exp = tst.TimeIndexedData(
        [pd.Timestamp(f"2022-1-{d}") for d in range(1, 7)], [2, 2, 2, 0, 2, 2]
    )
    assert t.make_dense(0) == dense_t_exp
    t.make_dense(0, in_place=True)
    assert t == dense_t_exp


def test_fill_values():
    values = np.arange(9, dtype=np.float64).reshape(3, 3)
    values[1, :] = np.nan
    t = tst.TimeIndexedData([0, 1, 2], values)
    exp = tst.TimeIndexedData([0, 1, 2], [[0, 1, 2], [0, 0, 0], [6, 7, 8]])
    assert t.fill_values(0) == exp
    t.fill_values(0, in_place=True)
    assert t == exp


def test_missing_time_stamps():
    kwargs = {
        "granularity": "D",
        "unixtime_t0": pd.Timestamp("2022-01-01"),
        "unixtime_unit": pd.Timedelta(days=1),
    }

    cases = [
        ([0, 1, 2, 4], [pd.Timestamp("2022-01-04")]),
        ([0, 1, 2], []),
    ]
    for t_values, exp in cases:
        index = tst.TimeIndex(t_values, **kwargs)
        data = tst.TimeIndexedData(t_values, [1] * len(t_values), **kwargs)
        assert index.missing_time_stamps() == exp
        assert data.missing_time_stamps() == exp


def test_time_index_same_scale():
    a = tst.TimeIndex([0, 1, 2])
    b = tst.TimeIndex([3])
    assert a.same_scale(b)

    # Integer scales must also be the same

    a = tst.TimeIndex(["2022-01-01", "2022-01-02"], unixtime_t0=pd.Timestamp("2022-01-01"))
    b = tst.TimeIndex(["2022-01-01", "2022-01-02"], unixtime_t0=pd.Timestamp("1970-01-01"))
    assert not a.same_scale(b)

    # Values must be consistent even if granularity matches

    a = tst.TimeIndex(["2022-01-01 12:00:00", "2022-01-02 12:00:00"], granularity="D")
    b = tst.TimeIndex(["2022-01-01", "2022-01-02"], granularity="D")
    assert not a.same_scale(b)

    # Date ranges are projected to check if one object is in the future of the other

    a = tst.TimeIndex(["2023-01-19", "2023-01-20"], granularity="B")  # Business days
    b = tst.TimeIndex(["2023-01-03", "2023-01-04"], granularity="B")
    assert a.same_scale(b)


def test_time_slice():
    data = tst.TimeIndexedData([f"2022-1-{d}" for d in range(1, 8)], [1, 1, 1, 1, 1, 1, 1])
    kwargs = {
        "granularity": data.granularity,
        "unixtime_t0": data.unixtime_t0,
        "unixtime_unit": data.unixtime_unit,
    }

    res = data.time_slice(start=pd.Timestamp("2022-01-02"), end=pd.Timestamp("2022-01-03"))
    assert res == tst.TimeIndexedData(["2022-01-02"], [1], **kwargs)

    res = data.time_slice(start=pd.Timestamp("2022-01-02"), end=pd.Timestamp("2022-01-02"))
    assert res == tst.TimeIndexedData([], [], **kwargs)

    res = data.time_slice(start=pd.Timestamp("2022-01-06"))
    assert res == tst.TimeIndexedData(["2022-1-6", "2022-1-7"], [1, 1], **kwargs)

    # Out of bounds start value
    res = data.time_slice(start=pd.Timestamp("2023-01-06"))
    assert res == tst.TimeIndexedData([], [], **kwargs)

    # Out of bounds end value
    res = data.time_slice(start=pd.Timestamp("2022-01-06"), end=pd.Timestamp("2100-01-01"))
    assert res == tst.TimeIndexedData(["2022-1-6", "2022-1-7"], [1, 1], **kwargs)


def test_strictly_before():
    test_cases = [
        # Cannot tell for empty arrays
        (tst.TimeIndex([]), tst.TimeIndex([1]), False),
        (tst.TimeIndex([1]), tst.TimeIndex([]), False),
        # Matches don't count
        (tst.TimeIndex([1]), tst.TimeIndex([1]), False),
        # Expected
        (tst.TimeIndex([1, 2]), tst.TimeIndex([3, 4]), True),
    ]

    for a, b, res in test_cases:
        assert a.strictly_before(b) == res
        ta = tst.TimeIndexedData(a.timestamp_values, [1] * len(a))
        tb = tst.TimeIndexedData(b.timestamp_values, [1] * len(b))
        assert ta.strictly_before(tb) == res


def test_starts_before():
    test_cases = [
        # Cannot tell for empty arrays
        (tst.TimeIndex([]), tst.TimeIndex([1]), False),
        (tst.TimeIndex([1]), tst.TimeIndex([]), False),
        # Matches don't count
        (tst.TimeIndex([1]), tst.TimeIndex([1]), False),
        # Expected
        (tst.TimeIndex([1, 2, 3]), tst.TimeIndex([2, 3, 4]), True),
    ]

    for a, b, res in test_cases:
        assert a.starts_before(b) == res
        ta = tst.TimeIndexedData(a.timestamp_values, [1] * len(a))
        tb = tst.TimeIndexedData(b.timestamp_values, [1] * len(b))
        assert ta.starts_before(tb) == res


def test_data_from_time_index():
    index = tst.TimeIndex([0, 1, 2])
    values = np.arange(9).reshape(3, 3)
    data = tst.TimeIndexedData.from_time_index(index, values)
    assert data.time_index == index
    assert np.array_equal(data.values, values)

    with pytest.raises(ValueError):
        bad_shape_values = [1, 2]  # Wrong length
        tst.TimeIndexedData.from_time_index(index, bad_shape_values)


def test_isin():
    index = tst.TimeIndex(range(5))

    # Unixtime lookup
    assert np.array_equal(index.isin({1, 4}), [False, True, False, False, True])
    assert np.array_equal(index.isin({6}), [False, False, False, False, False])

    # TimeIndex lookup
    assert np.array_equal(index.isin(index), [True, True, True, True, True])
    assert np.array_equal(index.isin(index.slice(-3)), [False, False, True, True, True])

    # Timestamp lookup
    j1, j2 = pd.Timestamp("2022-01-01"), pd.Timestamp("2022-01-02")
    index = tst.TimeIndex([j1, j2])
    assert np.array_equal(index.isin([j1]), [True, False])

    # TimeIndexedData
    index = tst.TimeIndex([j1, j2])
    data = tst.TimeIndexedData([j1], [2])
    assert np.array_equal(index.isin(data), [True, False])


def test_mask():
    data = tst.TimeIndexedData(range(4), 2 * np.arange(4), granularity="s")
    masks = [
        [False, False, False, False],
        [False, True, False, True],
        [True, True, True, True],
    ]
    exps = [
        tst.TimeIndexedData([], [], granularity="s"),
        tst.TimeIndexedData([1, 3], [2, 6], granularity="s"),
        data,
    ]
    for mask, exp in zip(masks, exps):
        assert data.mask(mask) == exp

    with pytest.raises(IndexError):
        data.mask(np.zeros(9, dtype=bool))

    with pytest.raises(ValueError):
        data.mask(np.zeros(8, dtype=bool).reshape(4, 2))


def test_dropna():
    t = [1, 2, 3, 4]
    v = [1, 2, np.nan, 4]
    data = tst.TimeIndexedData(t, v, granularity="s")
    assert data.dropna() == tst.TimeIndexedData([1, 2, 4], [1, 2, 4], granularity="s")

    # The whole row gets dropped if there are any NaNs in the higher dimensions
    v = np.array(
        [
            [[1, 2, 3], [4, 5, 6]],
            [[1, 2, np.nan], [4, 5, 6]],
            [[1, 2, 3], [4, 5, 6]],
            [[1, 2, 3], [4, np.nan, 6]],
        ]
    )
    data = tst.TimeIndexedData(t, v, granularity="s")
    assert data.dropna() == tst.TimeIndexedData(
        [1, 3],
        [[[1, 2, 3], [4, 5, 6]], [[1, 2, 3], [4, 5, 6]]],
        granularity="s",
    )


def test_leaf_node():
    data = tst.TimeIndexedData(
        np.arange(5),
        np.arange(10).reshape(5, 2),
        column_names=[("a", "b", "c"), ("a", "b", "d")],
    )
    agg = data.aggregate(0)

    assert data.is_leaf_node(("a", "b", "c"))
    assert not agg.is_leaf_node(("a", tst.All, tst.All))


def test_resample_no_op():
    data = tst.TimeIndexedData(
        ["2022-01-01", "2022-01-03", "2022-01-04"], [1, 3, 5], granularity="D"
    )
    res = data.resample("D")
    assert res == data


def test_resample_fixed():
    data = tst.TimeIndexedData(
        [1, 2, 3, 60, 61, 62], [2, 4, 6, 10, 11, 12], granularity=pd.Timedelta(seconds=1)
    )
    res1 = data.resample("min")
    res2 = data.resample(pd.Timedelta(minutes=1))

    for res in (res1, res2):
        assert len(res) == 2
        np.testing.assert_array_equal(res.values, [12, 33])
        assert res.int_time_index() == [0, 60]

    res3 = data.resample("min", reducer=np.mean)
    np.testing.assert_array_equal(res3.values, [4, 11])


def test_resample_variable():
    data = tst.TimeIndexedData(
        ["2022-01-02 01:00", "2022-01-03 01:00", "2022-01-04 01:00", "2022-02-02 01:00"],
        [[1, 1], [4, 4], [6, 6], [-1, 1]],
        granularity="D",
    )
    res = data.resample("W")
    exp = tst.TimeIndexedData(["2022-01-02", "2022-01-30"], [[11, 11], [-1, 1]], granularity="W")
    assert res == exp


def test_resample_floor():
    data = tst.TimeIndexedData(
        [f"2022-01-01 00:0{x}:45" for x in range(1, 10)],
        np.arange(9),
    )
    res = data.resample("min")
    np.testing.assert_array_equal(data.values, res.values)
    assert res.time_index == tst.TimeIndex(
        [f"2022-01-01 00:0{x}" for x in range(1, 10)],
        granularity="min",
    )


def test_time_index_sql_string():
    tst.TimeIndex([pd.Timestamp("2023-01-01"), pd.Timestamp("2023-02-01")], granularity="Month")
    tst.TimeIndex([pd.Timestamp("2023-01-15"), pd.Timestamp("2023-02-15")], granularity="Month")
    tst.TimeIndex([pd.Timestamp("2023-01-31"), pd.Timestamp("2023-02-28")], granularity="Month")
    tst.TimeIndex([pd.Timestamp("2023-01-15"), pd.Timestamp("2024-01-15")], granularity="Year")
    tst.TimeIndex([pd.Timestamp("2023-01-01"), pd.Timestamp("2023-04-01")], granularity="Quarter")
    tst.TimeIndex([pd.Timestamp("2023-02-01"), pd.Timestamp("2023-05-01")], granularity="Quarter")
    tst.TimeIndex([pd.Timestamp("2023-02-01"), pd.Timestamp("2023-02-02")], granularity="Day")


def test_time_range_sql_string():
    assert tst._time_range(pd.Timestamp("2023-01-01"), periods=2, freq="Month") == [
        pd.Timestamp("2023-01-01"),
        pd.Timestamp("2023-02-01"),
    ]
    assert tst._time_range(pd.Timestamp("2023-01-01"), periods=2, freq="Quarter") == [
        pd.Timestamp("2023-01-01"),
        pd.Timestamp("2023-04-01"),
    ]
    assert tst._time_range(pd.Timestamp("2023-01-01"), periods=2, freq="Year") == [
        pd.Timestamp("2023-01-01"),
        pd.Timestamp("2024-01-01"),
    ]
    assert tst._time_range(pd.Timestamp("2023-01-31"), periods=2, freq="Month") == [
        pd.Timestamp("2023-01-31"),
        pd.Timestamp("2023-02-28"),
    ]


@pytest.mark.parametrize("freq", list(tst._SPECIAL_FREQUENCIES))
@pytest.mark.parametrize(
    "prefix,suffix", [("", ""), ("1 ", ""), ("5 ", ""), ("5 ", "s"), ("10 ", ""), ("10 ", "s")]
)
def test_special_granularity_variations(freq, prefix, suffix):
    user_input = f"{prefix}{freq}{suffix}"
    assert tst._get_custom_granularity(user_input) is not None
    assert tst._get_custom_granularity(user_input.upper()) is not None  # Should be case insensitive


@pytest.mark.parametrize("t", [1, "2022-01-01", pd.Timestamp("2022-01-01")])
def test_zero_dim_inits(t):
    tst.TimeIndexedData(t, 1) == tst.TimeIndexedData([t], [1])
    tst.TimeIndex(t) == tst.TimeIndex([t])

    kw = dict(granularity="D", unixtime_unit=pd.Timedelta(days=1))
    tst.TimeIndexedData(t, 1, **kw) == tst.TimeIndexedData([t], [1], **kw)


@pytest.mark.parametrize(
    "granularity",
    [
        DateOffset(2),
        DateOffset(2, normalize=True),
        DateOffset(hours=2),
        CustomBusinessDay(),
        "B",
        "D",
        pd.Timedelta(days=1),
        pd.Timedelta(hours=24),
        timedelta(days=1),
        timedelta(hours=24),
    ],
)
@pytest.mark.parametrize("shape", [(5,), (5, 3), (5, 3, 4)])
def test_json_serialize_deserialize(granularity, shape):
    t0 = pd.Timestamp("2023-05-08")
    data = tst.TimeIndexedData(
        time_range(t0, freq=granularity, periods=shape[0]),
        np.random.rand(*shape),
        granularity=granularity,
    )

    assert data == tst.TimeIndexedData.from_json(data.to_json())
    assert data == tst.TimeIndexedData.from_json(json.dumps(data.to_json()))

    with NamedTemporaryFile() as f:
        with open(f.name, "w") as w:
            json.dump(data.to_json(), w)

        with open(f.name, "r") as r:
            deserialized = tst.TimeIndexedData.from_json(json.load(r))
            assert data == deserialized


def test_query_flat_columns():
    data = tst.TimeIndexedData(
        time_range("2023-01-01", periods=5, freq="D"),
        np.random.rand(5, 3),
        column_names=["a", "b", "c"],
    )

    assert data.query_columns("col == 'a'") == data[["a"]]
    assert data.query_columns("`col[0]` == 'a'") == data[["a"]]


def test_query_hierarchical_columns():
    data = tst.TimeIndexedData(
        time_range("2023-01-01", periods=5, freq="D"),
        np.random.rand(5, 6),
        column_names=[
            ("US", "Tech"),
            ("US", "Retail"),
            ("EU", "Tech"),
            ("EU", "Retail"),
            ("US", uff.All),
            (uff.All, "Retail"),
        ],
    )

    us_cols = [("US", "Tech"), ("US", "Retail"), ("US", uff.All)]
    retail_cols = [("US", "Retail"), ("EU", "Retail"), (uff.All, "Retail")]
    agg_cols = [("US", All), (All, "Retail")]

    assert data.query_columns("`col[0]` == 'US'") == data[us_cols]
    assert data.query_columns("`col[1]` == 'Retail'") == data[retail_cols]
    assert data.query_columns("`col[1]` == @All | `col[0]` == @All") == data[agg_cols]


def test_empty_column_object():
    # Empty data frames can have 0 or 1 column
    tst.TimeIndexedData([], [], column_names=["a"])
    tst.TimeIndexedData([], [], column_names=[])

    # Nonempty data frames must have at least one column
    with pytest.raises(ValueError):
        tst.TimeIndexedData([1], [1], column_names=[])

    # Empty high dimensional data must have the appropriate number of columns
    tst.TimeIndexedData([], np.zeros((0, 4)), column_names=["a", "b", "c", "d"])
    with pytest.raises(ValueError):
        tst.TimeIndexedData([], np.zeros((0, 4)), column_names=["bad"])


def test_drop_constant():
    data = tst.TimeIndexedData([1, 2, 3], [4, 4, 4])
    data.drop_constant_columns() == tst.TimeIndexedData(
        [1, 2, 3], np.empty((3, 0)), column_names=[]
    )

    data = tst.TimeIndexedData(
        [1, 2, 3], [[1, 2], [2, 2], [3, 1]], column_names=["const", "not const"]
    )
    data.drop_constant_columns() == tst.TimeIndexedData(
        [1, 2, 3], [[2], [2], [1]], column_names=["not const"]
    )

    # Column 1 is [[4, 4], [4, 4], [4, 4]]
    # Column 2 is [[2, 1], [2, 1], [2, 3]]
    high_dim_vals = [
        [[4, 4], [2, 1]],
        [[4, 4], [2, 1]],
        [[4, 4], [2, 3]],
    ]
    data = tst.TimeIndexedData([1, 2, 3], high_dim_vals, column_names=["const", "not const"])
    data.drop_constant_columns() == tst.TimeIndexedData(
        [1, 2, 3],
        [[[2, 1]], [[2, 1]], [[2, 3]]],
        column_names=["not const"],
    )


def test_merge_basic():
    d1 = tst.TimeIndexedData([1, 2, 3], np.random.rand(3, 2), column_names=["a", "b"])
    d1_copy = d1.copy()
    d2 = tst.TimeIndexedData([1, 2, 3], np.random.rand(3, 2), column_names=["c", "d"])
    d2_copy = d2.copy()
    res = d1.merge(d2)
    assert res == tst.TimeIndexedData(
        [1, 2, 3], np.hstack([d1.values, d2.values]), column_names=["a", "b", "c", "d"]
    )
    assert d1 == d1_copy
    assert d2 == d2_copy


def test_merge_duplicate():
    d1 = tst.TimeIndexedData([1, 2, 3], np.random.rand(3, 2), column_names=["a", "b"])
    d1_copy = d1.copy()
    d2 = tst.TimeIndexedData([1, 2, 3], np.random.rand(3, 2), column_names=["a", "d"])
    d2_copy = d2.copy()
    exp = tst.TimeIndexedData(
        [1, 2, 3], np.hstack([d1.values, d2.values[:, [1]]]), column_names=["a", "b", "d"]
    )
    res = d1.merge(d2)
    assert res == exp
    assert d1 == d1_copy
    assert d2 == d2_copy

    with pytest.raises(ValueError):
        d1.merge(d2, raise_on_duplicates=True)


def test_merge_high_dim():
    d1 = tst.TimeIndexedData([1, 2, 3], np.random.rand(3, 2, 3), column_names=["a", "b"])
    d1_copy = d1.copy()
    d2 = tst.TimeIndexedData([1, 2, 3], np.random.rand(3, 2, 3), column_names=["a", "d"])
    d2_copy = d2.copy()
    exp = tst.TimeIndexedData(
        [1, 2, 3], np.hstack([d1.values, d2.values[:, [1], :]]), column_names=["a", "b", "d"]
    )
    res = d1.merge(d2)

    assert res == exp
    assert res.shape == (3, 3, 3)
    assert d1 == d1_copy
    assert d2 == d2_copy

    with pytest.raises(ValueError):
        d1.merge(d2, raise_on_duplicates=True)


def test_merge_bad_data():
    d1 = tst.TimeIndexedData([1, 2, 3], np.random.rand(3, 2), column_names=["a", "b"])
    d2 = tst.TimeIndexedData([1, 2, 3], np.random.rand(3, 2), column_names=[("a", 1), ("d", 1)])

    with pytest.raises(ValueError):
        d1.merge(d2)

    with pytest.raises(TypeError):
        d1.merge("some other type")


def test_merge_high_dim_mismatch():
    d1 = tst.TimeIndexedData([1, 2, 3], np.random.rand(3, 2, 2), column_names=["a", "b"])
    d2 = tst.TimeIndexedData([1, 2, 3], np.random.rand(3, 2, 3), column_names=["c", "d"])
    with pytest.raises(ValueError):
        d1.merge(d2)


def test_empty_merge():
    d1 = tst.TimeIndexedData([], [], column_names=[])
    d2 = tst.TimeIndexedData([], [], column_names=[])
    exp = tst.TimeIndexedData([], [], column_names=[])
    res = d1.merge(d2, raise_on_duplicates=True)
    assert res == exp


def test_empty_column_merge():
    d1 = tst.TimeIndexedData([1, 2, 3], np.zeros((3, 0)), column_names=[])
    d2 = tst.TimeIndexedData([1, 2, 3], np.zeros((3, 0)), column_names=[])

    exp = tst.TimeIndexedData([1, 2, 3], np.zeros((3, 0)), column_names=[])
    res = d1.merge(d2, raise_on_duplicates=True)
    assert res == exp

    d3 = tst.TimeIndexedData([1, 2, 3], [1, 2, 3], column_names=["a"])
    exp = tst.TimeIndexedData([1, 2, 3], [1, 2, 3], column_names=["a"])
    res1 = d3.merge(d1, raise_on_duplicates=True)
    res2 = d1.merge(d3, raise_on_duplicates=True)
    assert res1 == exp
    assert res2 == exp


def test_copy_with_new_values():
    d1 = tst.TimeIndexedData([1, 2, 3], np.random.rand(3), column_names=["a"])
    d2 = d1.copy_with_new_values([4, 5, 6])
    assert d2 == tst.TimeIndexedData([1, 2, 3], [4, 5, 6], column_names=["a"])
