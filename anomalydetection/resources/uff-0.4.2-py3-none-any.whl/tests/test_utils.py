#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import random

import numpy as np
import pandas as pd
import pytest
from pandas.tseries.offsets import DateOffset

from uff.forecasters.arima import ArimaForecaster
from uff.tstypes import TimeIndex, TimeIndexedData
from uff.utils import (
    _correct_shape,
    auto_impute,
    concatenate,
    deterministic_rng,
    fill_values,
    global_rng,
    hstack,
    infer_granularity,
    interpolate,
    load_multi_from_pandas,
    make_dense,
    make_deterministic,
    sliding_window,
    temporal_split,
    time_based_regressors,
    time_range,
    to_utc,
)


def test_concatenate_basic():
    t1 = TimeIndexedData([0, 1, 2], [0, 2, 4])
    t2 = TimeIndexedData([3, 4, 5], [6, 8, 10])
    t3 = TimeIndexedData(np.arange(6), 2 * np.arange(6))
    assert concatenate((t1, t2)) == t3

    with pytest.raises(ValueError):
        concatenate(
            (TimeIndexedData([1, 2, 3], [1, 1, 1]), TimeIndexedData([3, 4, 5], [2, 2, 2])),
            raise_on_duplicates=True,
        )

    with pytest.raises(ValueError):
        concatenate(
            (TimeIndexedData([1, 3, 5], [1, 1, 1]), TimeIndexedData([2, 4, 6], [2, 2, 2])),
            raise_on_out_of_order=True,
        )


def test_concatenate_high_dim():
    time_array = np.arange(6)
    values = np.arange(72).reshape(6, 3, 4)
    t_big = TimeIndexedData(time_array, values)

    t1 = TimeIndexedData(time_array[:3], values[:3, ...])
    t2 = TimeIndexedData(time_array[3:], values[3:, ...])
    assert concatenate((t1, t2)) == t_big


def test_make_dense():
    # Scalar values
    t = TimeIndexedData([pd.Timestamp(f"2022-1-{d}") for d in (1, 2, 3, 5, 6)], [2, 2, 2, 2, 2])
    dense_t_exp = TimeIndexedData(
        [pd.Timestamp(f"2022-1-{d}") for d in range(1, 7)], [2, 2, 2, 0, 2, 2]
    )
    assert make_dense(t, 0) == dense_t_exp

    # Array values
    fill_value = [10, 100]
    data = TimeIndexedData(
        [pd.Timestamp(f"2022-1-{d}") for d in (1, 2, 3, 5, 6)],
        np.arange(10).reshape(5, 2),
    )
    exp = TimeIndexedData(
        [pd.Timestamp(f"2022-1-{d}") for d in range(1, 7)],
        [[0, 1], [2, 3], [4, 5], fill_value, [6, 7], [8, 9]],
    )
    assert make_dense(data, fill_value) == exp

    # Broadcast
    fill_value = -1
    data = TimeIndexedData(
        [pd.Timestamp(f"2022-1-{d}") for d in (1, 2, 3, 5, 6)],
        np.arange(10).reshape(5, 2),
    )
    exp = TimeIndexedData(
        [pd.Timestamp(f"2022-1-{d}") for d in range(1, 7)],
        [[0, 1], [2, 3], [4, 5], [-1, -1], [6, 7], [8, 9]],
    )
    assert make_dense(data, fill_value) == exp

    # No op
    data = TimeIndexedData(
        [pd.Timestamp(f"2022-1-{d}") for d in range(1, 7)], np.arange(12).reshape(6, 2)
    )
    assert make_dense(data, -2) == data
    empty = TimeIndexedData([], [])
    assert make_dense(empty, 1000) == empty


def test_fill_values():
    values = np.arange(9, dtype=np.float64).reshape(3, 3)
    values[1, :] = np.nan
    t = TimeIndexedData([0, 1, 2], values)
    exp = TimeIndexedData([0, 1, 2], [[0, 1, 2], [0, 0, 0], [6, 7, 8]])
    assert fill_values(t, 0) == exp


def test_temporal_split():
    t = TimeIndexedData(np.arange(10), np.arange(10))
    past, future = temporal_split(t, 0.5)
    assert past == TimeIndexedData(np.arange(5), np.arange(5))
    assert future == TimeIndexedData(np.arange(5, 10), np.arange(5, 10))

    values = np.arange(40).reshape(10, 2, 2)
    t = TimeIndexedData(np.arange(10), values)
    past, future = temporal_split(t, 0.7)
    assert past == TimeIndexedData(np.arange(7), values[:7])
    assert future == TimeIndexedData(np.arange(7, 10), values[7:])

    with pytest.raises(ValueError):
        temporal_split(t, 39)


def test_interpolate():
    obs = TimeIndexedData([0, 2, 4, 6], [1, 2, 3, 4])
    t = TimeIndex([-1, 1, 2, 5, 7])

    exp = TimeIndexedData(t.int_values, [0, 1.5, 2, 3.5, 0])
    assert interpolate(t, obs, interp="linear", left=0, right=0) == exp

    exp = TimeIndexedData(t.int_values, [1, 1.5, 2, 3.5, 4])
    assert interpolate(t, obs, interp="linear") == exp

    exp = TimeIndexedData(t.int_values, [1, 1, 2, 3, 4])
    assert interpolate(t, obs, interp="left") == exp

    exp = TimeIndexedData(t.int_values, [1, 2, 2, 4, 4])
    assert interpolate(t, obs, interp="right") == exp

    exp = TimeIndexedData(t.int_values, [np.nan, np.nan, 2, np.nan, np.nan])
    res = interpolate(t, obs, interp="nan")
    assert res.time_index == exp.time_index
    assert np.array_equal(res.values, exp.values, equal_nan=True)

    obs = TimeIndexedData([0, 2, 4, 6], np.arange(8).reshape(4, 2))
    exp = TimeIndexedData(t.int_values, [[0, 1], [1, 2], [2, 3], [5, 6], [6, 7]])
    assert interpolate(t, obs, interp="linear") == exp

    obs = TimeIndexedData([0, 2, 4, 6], np.arange(8).reshape(4, 2))
    exp = TimeIndexedData(
        t.int_values,
        [[np.nan, np.nan], [np.nan, np.nan], [2, 3], [np.nan, np.nan], [np.nan, np.nan]],
    )
    res = interpolate(t, obs, interp="nan")
    assert res.time_index == exp.time_index
    assert np.array_equal(res.values, exp.values, equal_nan=True)

    uneq_obs = TimeIndexedData([0, 2, 5], [1, 3, 6])
    t = TimeIndex([1, 3, 4])
    exp = TimeIndexedData(t.int_values, [2, 4, 5])
    assert interpolate(t, uneq_obs, interp="linear") == exp

    with pytest.raises(ValueError):
        interpolate(t, TimeIndexedData([], []))  # Cannot interpolate empty

    with pytest.raises(ValueError):
        interpolate(t, uneq_obs, interp="random string")  # Unrecognized option


def test_correct_shape():
    assert np.array_equal(_correct_shape(1, (2, 4, 2)), np.ones((2, 4, 2), dtype=np.float64))

    value = [[1, 2], [3, 4]]
    exp_shape = (2, 2, 4)
    output = _correct_shape(value, exp_shape)
    assert output.shape == exp_shape
    for i in range(4):
        assert np.array_equal(np.array(value, dtype=np.float64), output[:, :, i])

    # Not broadcastable
    value = [[1, 2, 3], [4, 5, 6]]
    exp_shape = (2, 4, 6)
    with pytest.raises(ValueError):
        _correct_shape(value, exp_shape)


def test_load_multi_from_pandas():
    df = pd.DataFrame(
        {
            "a": [1, 2, 3, 4, 5],
            "b": [2, 4, 6, 8, 10],
            "c": [3, 4, 5, 6, 7],
            "d": [1, 5, 3, 7, 9],
            "t": [4, 5, 6, 7, 8],
        }
    )

    objs = load_multi_from_pandas(df, [["a"], ["b", "c"], ["c", "d"]])
    exp = (
        TimeIndexedData.from_pandas(df, ["a"]),
        TimeIndexedData.from_pandas(df, ["b", "c"]),
        TimeIndexedData.from_pandas(df, ["c", "d"]),
    )
    assert objs == exp

    objs = load_multi_from_pandas(df, [["a"], ["b", "c"], ["c", "d"]], time_col="t")
    exp = (
        TimeIndexedData.from_pandas(df, ["a"], time_col="t"),
        TimeIndexedData.from_pandas(df, ["b", "c"], time_col="t"),
        TimeIndexedData.from_pandas(df, ["c", "d"], time_col="t"),
    )
    assert objs == exp


def test_sliding_window_1d():
    data = TimeIndexedData(np.arange(5), np.arange(5))
    sliding = sliding_window(data, window_size=3)
    exp = np.array([[np.nan, np.nan, 0], [np.nan, 0, 1], [0, 1, 2], [1, 2, 3], [2, 3, 4]]).reshape(
        5, 1, 3
    )
    np.testing.assert_array_equal(sliding.values, exp)

    sliding = sliding_window(data, window_size=4, mask=[True, True, False, True])
    exp = [
        [np.nan, np.nan, 0],
        [np.nan, np.nan, 1],
        [np.nan, 0, 2],
        [0, 1, 3],
        [1, 2, 4],
    ]
    np.testing.assert_array_equal(sliding.values, np.array(exp).reshape(5, 1, 3))


def test_sliding_window_2d():
    data = TimeIndexedData(np.arange(3), np.arange(6).reshape(3, 2))
    sliding = sliding_window(data, window_size=3)
    exp = [
        [
            [np.nan, np.nan, 0],
            [np.nan, np.nan, 1],
        ],
        [
            [np.nan, 0, 2],
            [np.nan, 1, 3],
        ],
        [
            [0, 2, 4],
            [1, 3, 5],
        ],
    ]
    np.testing.assert_array_equal(sliding.values, exp)

    # Equivalent to LAG(2)
    sliding = sliding_window(data, window_size=3, mask=[True, False, False])
    exp = [
        [
            [np.nan],
            [np.nan],
        ],
        [
            [np.nan],
            [np.nan],
        ],
        [
            [0],
            [1],
        ],
    ]
    np.testing.assert_array_equal(sliding.values, exp)

    # Also equivalent to LAG(2)
    sliding = sliding_window(data, window_size=3, mask=[0])
    np.testing.assert_array_equal(sliding.values, exp)


def test_hstack_basic():
    v1, v2 = np.arange(6).reshape(3, 2), np.arange(9).reshape(3, 3) * 4
    d1 = TimeIndexedData(np.arange(3), v1, ["a", "b"])
    d2 = TimeIndexedData(np.arange(3), v2, ["c", "d", "e"])
    res = hstack((d1, d2))

    np.testing.assert_array_equal(res.values, np.hstack((v1, v2)).astype(float))
    assert res.column_names == ["a", "b", "c", "d", "e"]


def test_hstack_empty():
    empty = TimeIndexedData([], [], column_names=[])
    res = hstack((empty, empty), column_prefixes=["a", "b"])
    assert res == empty.reshape((0, 0))  # hstack output is always 2D

    empty = TimeIndexedData([1, 2, 3], np.empty((3, 0)), column_names=[])
    res = hstack((empty, empty), column_prefixes=["a", "b"])
    assert res == empty


def test_hstack_empty_are_dropped():
    empty = TimeIndexedData([1, 2, 3], np.empty((3, 0)), column_names=[])
    d1 = TimeIndexedData([1, 2, 3], [1, 2, 3], column_names=["a"])
    d2 = TimeIndexedData([1, 2, 3], [4, 5, 6], column_names=["b"])
    res = hstack((empty, d1, empty, d2, empty), column_prefixes=["e1", "d1", "e2", "d2", "e3"])
    assert res == TimeIndexedData(
        [1, 2, 3], [[1, 4], [2, 5], [3, 6]], column_names=[("d1", "a"), ("d2", "b")]
    )


def test_hstack_empty_time_index():
    empty = TimeIndexedData([], [], column_names=[])
    d1 = TimeIndexedData([], np.empty((0, 2)), column_names=["a", "b"])
    d2 = TimeIndexedData([], np.empty((0, 2)), column_names=["c", "d"])
    res1 = hstack((empty, d1, empty, d2, empty), column_prefixes=["e1", "d1", "e2", "d2", "e3"])
    res2 = hstack((empty, d1, empty, d2, empty))
    assert res1 == TimeIndexedData(
        [], np.empty((0, 4)), column_names=[("d1", "a"), ("d1", "b"), ("d2", "c"), ("d2", "d")]
    )
    assert res2 == TimeIndexedData([], np.empty((0, 4)), column_names=["a", "b", "c", "d"])


def test_hstack_prefix():
    v1, v2 = np.arange(6).reshape(3, 2), np.arange(9).reshape(3, 3) * 4
    d1 = TimeIndexedData(np.arange(3), v1, ["a", "b"])
    d2 = TimeIndexedData(np.arange(3), v2, ["a", "b", "c"])

    # Duplicate columns
    with pytest.raises(ValueError):
        hstack((d1, d2))

    # Add prefix
    res = hstack((d1, d2), column_prefixes=["d1", "d2"])

    np.testing.assert_array_equal(res.values, np.hstack((v1, v2)).astype(float))
    assert res.column_tuples == [("d1", "a"), ("d1", "b"), ("d2", "a"), ("d2", "b"), ("d2", "c")]


def test_seeded_stdlib_state_restored():
    # User sets a random seed in another context
    random.seed(15)
    s1 = random.randint(0, 10000000)

    random.seed(15)
    # We start a context with a new default random seed
    with deterministic_rng(99):
        # Evolve the rng state
        random.randint(0, 10000000)
        random.randint(0, 10000000)

    # Afterwards the random number continues from its previous state
    assert random.randint(0, 10000000) == s1


def test_global_rng_value():
    # Outside of context manager
    global_rng_original = global_rng()

    # Can be accessed but not overwritten
    with deterministic_rng(99):
        new_rng = global_rng()
        new_rng is not global_rng_original

    # Goes back to None afterward
    assert global_rng() is global_rng_original

    # Can be nested
    with deterministic_rng(99):
        nested_rng = global_rng()
        with deterministic_rng(42):
            nested_nested_rng = global_rng()
            assert nested_nested_rng is not nested_rng
        assert global_rng() is nested_rng
    assert global_rng() is global_rng_original


def test_seeded_np_random_state_restored():
    # User sets a random seed in another context
    np.random.seed(90)
    s1 = np.random.randint(0, 10000000)

    np.random.seed(90)
    # Context with a new default random seed
    with deterministic_rng(25):
        np.random.randint(0, 10000000)
        np.random.randint(0, 10000000)

    # Afterwards, the random number generator continues from its previous state
    assert np.random.randint(0, 10000000) == s1


def assert_deterministic(callable, n_samples: int = 2):
    res = [callable() for _ in range(n_samples)]
    for r in res[1:]:
        assert np.allclose(res[0], r)


def test_seeded_np_default_rng():
    @make_deterministic(50)
    def deterministic_poisson():
        return np.random.default_rng().poisson()

    assert_deterministic(deterministic_poisson, n_samples=20)


def test_seeded_model_training():
    @make_deterministic(30)
    def train_model():
        data = TimeIndexedData(range(10), np.random.random(10), unixtime_unit=pd.Timedelta(days=1))
        return ArimaForecaster().fit(data).forecast(data.future_time_index(5)).out.values

    assert_deterministic(train_model)


def test_np_reseeding_is_deterministic():
    @make_deterministic(42)
    def catch_np_random_reseed_none():
        n1 = np.random.rand()
        np.random.seed(None)
        n2 = np.random.rand()
        return [n1, n2]

    assert_deterministic(catch_np_random_reseed_none, n_samples=5)


def test_random_reseeding_is_deterministic():
    @make_deterministic(42)
    def catch_random_reseed_none():
        r1 = random.random()
        random.seed(None)
        r2 = random.random()
        return [r1, r2]

    assert_deterministic(catch_random_reseed_none, n_samples=5)


def test_new_random_classes_are_determinstic():
    @make_deterministic(42)
    def new_random_instance():
        return random.Random(None).random()

    assert_deterministic(new_random_instance, n_samples=5)


def test_stdlib_random_global_state_is_patched():
    @make_deterministic(42)
    def global_state_reseed():
        global_state = random._inst
        global_state.seed(None)
        return global_state.random()

    assert_deterministic(global_state_reseed, n_samples=5)


def test_random_reseed_unique_but_deterministic():
    @make_deterministic(99)
    def reseed_twice():
        random.seed(None)
        r1 = random.randint(0, 1_000_000_000)
        random.seed(None)
        r2 = random.randint(0, 1_000_000_000)
        assert r1 != r2
        return [r1, r2]

    assert_deterministic(reseed_twice)


def test_np_reseed_unique_but_deterministic():
    @make_deterministic(99)
    def reseed_twice():
        np.random.seed(None)
        r1 = np.random.randint(0, 1_000_000_000)
        np.random.seed(None)
        r2 = np.random.randint(0, 1_000_000_000)
        assert r1 != r2
        return [r1, r2]

    assert_deterministic(reseed_twice)


def test_to_utc():
    a = "2023-01-01 03:00:00"
    assert to_utc(a) == pd.Timestamp(f"{a}+0000")

    b = pd.Timestamp("2023-01-01 02:00:00", tz="US/Pacific")
    assert to_utc(b) == pd.Timestamp("2023-01-01 10:00:00+0000")


@pytest.mark.parametrize(
    "granularity",
    [m * DateOffset(months=1) for m in (1, 2, 3, 4, 6, 12, 24, 48)]
    + [d * DateOffset(days=1) for d in (1, 2, 28)]
    + [pd.Timedelta(seconds=1)],
)
@pytest.mark.parametrize(
    "start_time",
    [
        pd.Timestamp(s)
        for s in (
            "2023-01-01",
            "2023-01-15",
            "2023-01-07 05:38",
            "2024-02-01",
        )
    ],
)
@pytest.mark.parametrize("missing_data", [True, False])
def test_infer_granularity_regular_day(granularity, start_time, missing_data):
    values = time_range(start_time, periods=10, freq=granularity)
    if missing_data:
        values = [values[i] for i in (0, 1, 3, 4, 7, 8, 9)]

    assert infer_granularity(values) == granularity


@pytest.mark.parametrize(
    "granularity", [m * pd.offsets.MonthEnd() for m in (1, 2, 3, 4, 6, 12, 24, 48)]
)
@pytest.mark.parametrize(
    "start_time",
    [
        pd.Timestamp(s)
        for s in (
            "2023-01-31",
            "2023-01-31 05:38",
            "2024-02-29",
            "2023-02-28",
        )
    ],
)
@pytest.mark.parametrize("missing_data", [True, False])
def test_infer_granularity_month_end(granularity, start_time, missing_data):
    values = time_range(start_time, periods=10, freq=granularity)
    if missing_data:
        values = [values[i] for i in (0, 1, 3, 4, 7, 8, 9)]

    assert infer_granularity(values) == granularity


def test_infer_granularity_nonstrict():
    # 2023-01-23 is not a Sunday
    values = [pd.Timestamp(f"2023-01-{x}") for x in (1, 8, 15, 23, 29)]
    assert infer_granularity(values) == DateOffset(days=1)
    assert infer_granularity(values, strict=False) == 7 * DateOffset(days=1)

    # One entry not on the hour
    values = [
        pd.Timestamp(f"2023-01-01 {t}") for t in ("00:00", "01:00", "02:01", "03:00", "04:00")
    ]
    assert infer_granularity(values) == pd.Timedelta(minutes=1)
    assert infer_granularity(values, strict=False) == pd.Timedelta(hours=1)

    # Ties will be broken based on the most recent observation
    # Deltas are 61, 59, 60 minutes respectively; each would get 1 vote.
    values = [pd.Timestamp(f"2023-01-01 {t}") for t in ("01:00", "02:01", "03:00", "04:00")]
    assert infer_granularity(values) == pd.Timedelta(minutes=1)
    assert infer_granularity(values, strict=False) == pd.Timedelta(hours=1)

    values = [pd.Timestamp(f"2023-01-01 {t}") for t in ("01:00", "02:00", "03:01", "04:00")]
    assert infer_granularity(values, strict=False) == pd.Timedelta(minutes=59)

    values = [pd.Timestamp(f"2023-01-01 {t}") for t in ("01:00", "02:00", "02:59", "04:00")]
    assert infer_granularity(values, strict=False) == pd.Timedelta(minutes=61)


def test_auto_impute():
    ts = [0, 1, 3, 4]
    data = TimeIndexedData(ts, [[1, np.nan], [2, np.nan], [np.nan, 2], [5, np.nan]])
    expected = TimeIndexedData([0, 1, 2, 3, 4], [[1, 0], [2, 0], [3, 0], [4, 2], [5, 0]])
    imputed = auto_impute(data)
    assert imputed.time_index == expected.time_index
    assert imputed.column_names == expected.column_names
    assert np.allclose(imputed.values, expected.values, atol=0.1)


def test_time_based_regressors():
    data = TimeIndexedData(["2023-01-01", "2023-02-01 23:59"], [1, 2])
    int_times = data.int_time_index()
    exp_values = [[int_times[0], 0, 6, 1], [int_times[1], 23, 2, 2]]

    regressors = time_based_regressors(data)
    regressors_custom = time_based_regressors(data, "custom_name")

    assert regressors.time_index == data.time_index
    assert regressors_custom.time_index == data.time_index
    assert regressors.column_names == ["t", "hour_of_day", "day_of_week", "month_of_year"]
    assert regressors_custom.column_names == [
        "custom_name",
        "hour_of_day",
        "day_of_week",
        "month_of_year",
    ]
    assert np.allclose(regressors.values, exp_values)
    assert np.allclose(regressors_custom.values, exp_values)


def test_time_based_regressors_one_hot():
    data = TimeIndexedData(["2023-01-01", "2023-02-01 23:59"], [1, 2])
    int_times = data.int_time_index()

    # t: 0
    # hr: 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24
    # day: 25 26 27 28 29 30 31
    # month: 32 33 34 35 36 37 38 39 40 41 42 43 44
    exp_values = np.zeros((2, 1 + 24 + 7 + 12), dtype=float)
    exp_values[0][0] = int_times[0]
    exp_values[0][1] = 1  # Midnight
    exp_values[0][31] = 1  # Sunday
    exp_values[0][32] = 1  # January
    exp_values[1][0] = int_times[1]
    exp_values[1][24] = 1  # 11 PM
    exp_values[1][27] = 1  # Wednesday
    exp_values[1][33] = 1  # February

    regressors = time_based_regressors(data, one_hot_encode=True)
    assert regressors.time_index == data.time_index
    assert regressors.column_names == (
        ["t"]
        + [f"hour_of_day_{i}" for i in range(24)]
        + [f"day_of_week_{i}" for i in range(7)]
        + [f"month_of_year_{i}" for i in range(1, 13)]
    )
    assert np.allclose(regressors.values, exp_values)


def test_time_based_regressors_intercept():
    data = TimeIndexedData(["2023-01-01", "2023-02-01 23:59"], [1, 2])
    int_times = data.int_time_index()
    exp_values = [[1, int_times[0], 0, 6, 1], [1, int_times[1], 23, 2, 2]]

    regressors = time_based_regressors(data, add_intercept=True, intercept_name="my_intercept")
    assert regressors.time_index == data.time_index
    assert regressors.column_names == [
        "my_intercept",
        "t",
        "hour_of_day",
        "day_of_week",
        "month_of_year",
    ]
    assert np.allclose(regressors.values, exp_values)
