#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import numpy as np

from uff import TimeIndexedData
from uff.transformers.math import (
    IdentityTransformer,
    LogTransformer,
    LowerBoundTransformer,
    ScaledLogitTransformer,
    TranslationTransformer,
    UpperBoundTransformer,
)

from ..utils import assert_forward_backward


def test_no_op():
    data = TimeIndexedData(range(3), range(3))
    assert_forward_backward(IdentityTransformer(), data, data)


def test_log():
    data = TimeIndexedData(range(3), [1, 2, 3])
    forward_exp = TimeIndexedData.from_time_index(
        data.time_index,
        np.log(data.values),
        column_names=data.column_tuples,
    )

    assert_forward_backward(LogTransformer(), data, forward_exp)


def test_translation():
    data = TimeIndexedData(range(3), [1, 2, 3])
    delta = 5
    assert_forward_backward(TranslationTransformer(delta), data, data + delta)


def test_scaled_logit():
    a, b = 0, 4
    data = TimeIndexedData(range(3), [1, 2, 3])
    forward_exp = TimeIndexedData.from_time_index(
        data.time_index,
        np.log((data.values - a) / (b - data.values)),
        column_names=data.column_tuples,
    )
    assert_forward_backward(ScaledLogitTransformer(a, b), data, forward_exp)


def test_lower_b():
    lower = 0
    data = TimeIndexedData(range(3), [1, 2, 3])
    forward_exp = TimeIndexedData.from_time_index(
        data.time_index,
        np.log(data.values - lower),
        column_names=data.column_tuples,
    )
    assert_forward_backward(LowerBoundTransformer(lower), data, forward_exp)


def test_upper_b():
    upper = 4
    data = TimeIndexedData(range(3), [1, 2, 3])
    forward_exp = TimeIndexedData.from_time_index(
        data.time_index,
        -np.log(upper - data.values),
        column_names=data.column_tuples,
    )
    assert_forward_backward(UpperBoundTransformer(upper), data, forward_exp)
