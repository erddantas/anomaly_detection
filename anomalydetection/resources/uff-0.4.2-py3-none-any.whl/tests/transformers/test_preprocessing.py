#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import numpy as np
import pytest
from sklearn.preprocessing import minmax_scale

import uff
from uff import TimeIndexedData
from uff.transformers.preprocessing import (
    AutoTrendTransformer,
    MaxAbsScaler,
    MinMaxScaler,
    PowerTransformer,
    RobustScaler,
    StandardScaler,
)

from ..utils import assert_forward_backward

sk_estimators = [MaxAbsScaler, MinMaxScaler, PowerTransformer, RobustScaler, StandardScaler]


@pytest.mark.parametrize("estimator_class", sk_estimators)
@pytest.mark.parametrize(
    "data",
    [TimeIndexedData(range(3), range(3)), TimeIndexedData(range(3), np.arange(6).reshape(3, 2))],
)
def test_forward_backward(estimator_class, data):
    assert_forward_backward(estimator_class(), data)


def test_auto_trend_no_op():
    # Need at least 4 observations to justify an exponential trend
    data = TimeIndexedData(range(3), np.random.randn(3, 2))
    assert_forward_backward(AutoTrendTransformer(), data, data)


def test_auto_trend_2d():
    x = np.arange(100)
    y_linear = 2 * x + 1
    y_exponential = np.exp(0.05 * x) - 10
    data = TimeIndexedData(
        x, np.array([y_linear, y_exponential]).T, column_names=["linear", "exponential"]
    )

    model = AutoTrendTransformer()
    model.fit(data)

    output = model.transform(data).out
    assert output.column_names == data.column_names
    assert output.shape == data.shape
    assert np.array_equal(model._pipeline_b_mask, [False, True])
    assert not np.allclose(output["linear"], data["linear"])
    assert not np.allclose(output["exponential"], data["exponential"])

    reversed = model.inverse_transform(output).out
    assert np.allclose(reversed.values, data.values)
    assert reversed.column_names == data.column_names
    assert reversed.shape == data.shape
    assert np.allclose(reversed["linear"], data["linear"])
    assert np.allclose(reversed["exponential"], data["exponential"])


@pytest.mark.parametrize("y", [2 * np.arange(10) + 1, np.exp(0.05 * np.arange(10))])
def test_auto_trend_1d(y):
    data = TimeIndexedData(np.arange(len(y)), y, column_names=["1d"])

    model = AutoTrendTransformer()
    model.fit(data)
    result = model.transform(data).out
    reversed = model.inverse_transform(result).out

    assert result.column_names == data.column_names
    assert result.shape == data.shape
    assert reversed.column_names == data.column_names
    assert reversed.shape == data.shape
    assert np.allclose(reversed["1d"], data["1d"])


@pytest.mark.parametrize("y", [2 * np.arange(100) + 1, np.exp(0.05 * np.arange(100))])
def test_auto_trend_out_of_sample(y):
    data = TimeIndexedData(np.arange(len(y)), y, column_names=["1d"])
    fit_data, transform_data = uff.temporal_split(data, 0.7)
    assert_forward_backward(AutoTrendTransformer(), transform_data, fit_data=fit_data)
