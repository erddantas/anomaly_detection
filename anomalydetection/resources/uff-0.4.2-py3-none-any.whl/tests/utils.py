#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from tempfile import NamedTemporaryFile
from typing import Optional, Type, Union

import numpy as np
import pandas as pd

from uff.base import (
    Estimator,
    Forecaster,
    ForecasterWithInterval,
    InitializationSpec,
    ReversibleTransformer,
)
from uff.meta import MetaEstimator
from uff.tstypes import TimeIndexedData, TimeIndexedOutputWithInterval


def _serialize_deserialize(est: Estimator) -> Estimator:
    f = NamedTemporaryFile("wb")
    est.save(f.name)
    est2 = est.load(f.name)
    f.close()
    assert type(est2) == type(est)
    return est2


def check_mixin(estimator: Estimator, mixin: Type) -> bool:
    if isinstance(estimator, MetaEstimator):
        return mixin in estimator.mixins()

    return isinstance(estimator, mixin)


def assert_all_close(a: TimeIndexedData, b: TimeIndexedData, **kwargs):
    assert a.shape == b.shape
    assert a.time_index == b.time_index
    assert a.column_tuples == b.column_tuples
    assert np.allclose(a.values, b.values, **kwargs)


def assert_forward_backward(
    model: ReversibleTransformer,
    data: TimeIndexedData,
    output: Optional[TimeIndexedData] = None,
    fit_data: Optional[TimeIndexedData] = None,
) -> None:
    model.fit(fit_data if fit_data is not None else data)
    forward_res = model.transform(data).out
    assert_all_close(data, model.inverse_transform(forward_res).out)
    if output is not None:
        assert_all_close(output, forward_res)


def assert_lifecycle_updates(estimator: Union[InitializationSpec, Estimator]) -> None:
    if isinstance(estimator, InitializationSpec):
        estimator = estimator.create_instance()

    assert isinstance(estimator.params, InitializationSpec), ".params must be set"
    assert not estimator.is_fit

    if check_mixin(estimator, ForecasterWithInterval):
        assert isinstance(estimator.prediction_interval_width, float)

    # Check serialize / deserialize pre-fit
    _serialize_deserialize(estimator)

    one_hour = pd.Timedelta(hours=1)
    data = TimeIndexedData(np.arange(100), np.random.poisson(10, size=100), unixtime_unit=one_hour)
    covariates = TimeIndexedData(
        np.arange(100), np.random.poisson(10, size=100), unixtime_unit=one_hour
    )
    future_covariates = TimeIndexedData(
        100 + np.arange(100), np.random.poisson(10, size=100), unixtime_unit=one_hour
    )

    # Check fit
    if estimator.requires_fit:
        estimator.fit(data, covariates)
        assert estimator.is_fit
        assert estimator.was_fit_with_covariates
        assert estimator.earliest_fit_timestamp == data.first_timestamp()
        assert estimator.latest_fit_timestamp == data.last_timestamp()
        assert estimator.fit_data_row_shape == data.shape[1:]
        assert estimator.fit_covariates_row_shape == covariates.shape[1:]
        assert estimator.fit_data_columns == data.column_tuples
        assert estimator.fit_covariates_columns == covariates.column_tuples

        if not estimator.requires_covariates:
            fresh = estimator.params.create_instance()
            fresh.fit(data)
            assert fresh.is_fit
            assert not fresh.was_fit_with_covariates
            assert fresh.earliest_fit_timestamp == data.first_timestamp()
            assert fresh.latest_fit_timestamp == data.last_timestamp()
            assert fresh.fit_data_row_shape == data.shape[1:]
            assert fresh.fit_covariates_row_shape == None
            assert fresh.fit_data_columns == data.column_tuples
            assert fresh.fit_covariates_columns == None

    # Assert model can be serialized / deserialized after fitting
    _serialize_deserialize(estimator)

    # Test forward pass
    if estimator.is_forecaster():
        result = estimator.forecast(future_covariates)

        if isinstance(result, TimeIndexedOutputWithInterval):
            if np.any(result.upper < result.out) or np.any(result.lower > result.out):
                assert False, f"Prediction intervals are not properly ordered: {result}"
    elif estimator.is_transformer():
        estimator.transform(data)
    elif estimator.is_feature_selector():
        estimator.transform_covariates(covariates)

    # Test backward pass
    if estimator.is_reversible_transformer():
        estimator.inverse_transform(data)


def assert_ray_serializable_or_flagged(
    model: Estimator,
    fit_data: Optional[TimeIndexedData] = None,
    fit_covariates: Optional[TimeIndexedData] = None,
) -> None:
    if model.ray_serializable:
        import ray

        fit_data = fit_data or TimeIndexedData(range(100), range(100))
        fit_covariates = fit_covariates or TimeIndexedData(range(100), range(100))

        @ray.remote
        def return_model(params):
            return params.create_instance()

        @ray.remote
        def return_fitted_model(params):
            est = params.create_instance()
            est.fit(fit_data, fit_covariates)
            return est

        if not ray.is_initialized():
            ray.init()

        ray.get(return_model.remote(model.params))
        ray.get(return_fitted_model.remote(model.params))
        ray.shutdown()


def assert_joblib_serializable_or_flagged(
    model: Estimator,
    fit_data: Optional[TimeIndexedData] = None,
    fit_covariates: Optional[TimeIndexedData] = None,
) -> None:
    if model.joblib_serializable:
        from joblib import Parallel, delayed

        fit_data = fit_data or TimeIndexedData(range(100), range(100))
        fit_covariates = fit_covariates or TimeIndexedData(range(100), range(100))

        def return_model(params):
            return params.create_instance()

        def return_fitted_model(params):
            est = params.create_instance()
            est.fit(fit_data, fit_covariates)
            return est

        parallel = Parallel(n_jobs=2)
        parallel(delayed(return_model)(model.params) for _ in range(1))
        parallel(delayed(return_fitted_model)(model.params) for _ in range(1))
