#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import inspect
from collections import OrderedDict
from pickle import UnpicklingError
from typing import Any, Optional, Type, Union

import dill

from . import logger

__all__ = ["dumps", "dump", "loads", "load"]

# dill pickle functions
_dumps = dill.dumps
_dump = dill.dump
_loads = dill.loads
_load = dill.load


def dump(obj: Any, file: Any, **kwargs) -> None:
    """Writes pickled `obj` to `file`

    If at least of one of the object states cannot be pickled, do the following:
    1. recursively pickle the object into an `OrderedDict`
    2. pickle `OrderedDict` and write to file

    Parameters
    ----------
    obj : Any
        The object to be pickled
    file : Any
        file handle to write the pickled object to

    Examples
    --------
    >>> obj = CustomClass()
    >>> with open("<file-name>", "wb") as f:
            dump(obj, f)
    """

    try:
        _dump(obj, file, **kwargs)
    except NotImplementedError:
        pickled_dict = OrderedDict()
        _dumps_recursive(obj, "root", pickled_dict)
        _dump(pickled_dict, file, **kwargs)


def dumps(obj: Any) -> bytes:
    """Returns pickled `obj` as bytes, works similarly as `dump()`

    If at least of one of the object states cannot be pickled, do the following:
    1. recursively pickle the object into an `OrderedDict`
    2. pickle `OrderedDict` and return bytes

    Parameters
    ----------
    obj : Any
        The object to be pickled

    Returns
    -------
    bytes
        The pickled object in bytes
    """
    try:
        return _dumps(obj)
    except NotImplementedError:
        pickled_dict = OrderedDict()
        _dumps_recursive(obj, "root", pickled_dict)
        return _dumps(pickled_dict)


def load(file: Any, recursive=True, **kwargs) -> Any:
    """Loads pickled object from file. If `recursive`, unpickles the `OrderedDict` recursively

    Parameters
    ----------
    file : Any
        file handle to read the pickled object from
    recursive : bool, optional
        whether to unpickle recursively, only applies when the unpickled file is an `OrderedDict`
        by default True

    Returns
    -------
    Any
        The unpickled object

    Examples
    --------
    >>> with open("<file-name>", "rb") as f:
            obj = load(w)
    """
    obj = _load(file, **kwargs)
    if recursive and isinstance(obj, OrderedDict):
        return _loads_recursive(obj)
    return obj


def loads(s: bytes, recursive=True, **kwargs) -> Any:
    """Loads pickled object from bytes

    Parameters
    ----------
    s : bytes
        The pickled object in bytes
    recursive : bool, optional
        whether to unpickle recursively, only applies when the unpickled btyes is an `OrderedDict`
        by default True

    Returns
    -------
    Any
        The unpickled object
    """
    s = _loads(s, **kwargs)
    if recursive and isinstance(s, OrderedDict):
        return _loads_recursive(s)
    return s


def _dumps_recursive(obj: Any, obj_name: str, context: OrderedDict) -> None:
    """Pickle an object recursively to write the states to `parent_dict`

    Modified from github:
    linkedin/greykite/blob/master/greykite/framework/templates/pickle_utils.py#L60

    Parameters
    ----------
    obj : Any
        The object to be pickled.
    obj_name : str
        Name for the pickled item, used as key in the dictionary
    context : OrderedDict
        Used in the recursive process to indicate where the nested pickled objects should be put.
        In the top-level call, user needs to feed the context explicitly

    Examples
    --------
    >>> obj = NestedObject(...)
    >>> s = OrderedDict()
    >>> _dumps_recursive(obj, "root", s)
    """
    try:
        context[obj_name] = _dumps(obj)
    except NotImplementedError:
        # Attempts to do recursive dumping depending on the object type.
        if isinstance(obj, dict):
            # For OrderedDict (there are a lot in `pasty.design_info.DesignInfo`),
            # recursively dumps the keys and values, because keys can be class instances
            # and unpicklable, too.
            # The keys and values have index number appended to the front,
            # so the order is kept.
            child = OrderedDict()
            context[obj_name] = (dict, child)
            for i, (key, value) in enumerate(obj.items()):
                name = f"{i}_{str(key)}"
                _dumps_recursive(key, f"{name}__key__", child)
                _dumps_recursive(value, f"{name}__value__", child)
        elif isinstance(obj, (list, tuple)):
            # For list and tuples,
            # recursively dumps the elements.
            # The names have index number appended to the front,
            # so the order is kept.
            child = OrderedDict()
            context[obj_name] = (type(obj), child)
            for i, value in enumerate(obj):
                _dumps_recursive(value, f"{i}_key", child)
        elif hasattr(obj, "__class__") and not isinstance(obj, type):
            # For class instance,
            # recursively dumps the attributes.
            child = OrderedDict()
            context[obj_name] = (obj.__class__, child)
            for key, value in obj.__dict__.items():
                _dumps_recursive(value, key, child)
        else:
            # Other unrecognized unpicklable types, not common.
            logger.raise_warning(f"Unrecognized type {type(obj)}")


def _loads_recursive(s: OrderedDict, obj_type: Optional[Type] = None) -> Any:
    """Load the object from an `OrderedDict` recursively

    Modified from github:
    linkedin/greykite/blob/master/greykite/framework/templates/pickle_utils.py#L60

    Parameters
    ----------
    s: OrderedDict
        a dict storing the states of the object
    obj_type: Optional[Type], optional
        The object type for the next-level files.
        One of "list", "tuple", "dict", or a class.

    Returns
    -------
    Any
        Unpickled object
    """

    def _loads_value(v: Union[tuple, bytes]) -> Any:
        if isinstance(v, tuple):
            obj_type, child = v
            return _loads_recursive(child, obj_type)
        elif isinstance(v, bytes):
            return _loads(v)
        else:
            raise ValueError(f"Unrecognized value: {type(v)}")

    # Starts loading objects
    if obj_type is None:
        if (k_len := len(s.keys())) != 1:
            raise ValueError(f"Top level should only contain a single key, instead: {k_len}")
        return _loads_value(list(s.values())[0])
    elif obj_type in (list, tuple):
        # Recursively loads elements.
        result = obj_type((_loads_value(v) for v in s.values()))
        return result
    elif obj_type == dict:
        # Object is a dictionary.
        result = OrderedDict()
        # Fetches keys and values recursively.
        key_names = [e for e in s.keys() if e.endswith("__key__")]
        value_names = set([e for e in s.keys() if e.endswith("__value__")])
        # Iterates through keys and finds the corresponding values.
        for key_name in key_names:
            key = _loads_value(s[key_name])
            if (value_name := key_name.replace("__key__", "__value__")) in value_names:
                value = _loads_value(s[value_name])
            else:
                raise ValueError(f"Key '{key_name}' is missing its value")
            result[key] = value
        return result
    else:
        try:
            if inspect.isclass(obj_type):
                init_params = list(inspect.signature(obj_type.__init__).parameters)  # init args
        except TypeError as e:
            raise ValueError(f"Object {obj_type} not recognized", e)
        except UnpicklingError as e:
            raise ValueError(f"Cannot unpickle object type: {obj_type}", e)
        # Object is a class instance.
        # Creates the class instance and sets the attributes.
        # Some class has required args during initialization,
        # these args are pulled from attributes.
        init_params = list(inspect.signature(obj_type.__init__).parameters)  # init args
        # Gets the attribute names and their values in a dictionary.
        values = {k: _loads_value(v) for k, v in s.items()}
        # Gets the init args from values.
        init_dict = {k: v for k, v in values.items() if k in init_params}
        # Some attributes has a "_" at the beginning.
        init_dict.update(
            {k[1:]: v for k, v in values.items() if (k[1:] in init_params and k[0] == "_")}
        )
        # ``design_info`` does not have column_names attribute,
        # which is required during init.
        # The column_names param is pulled from the column_name_indexes attribute.
        # This can be omitted once we allow dumping @property attributes.
        if "column_names" in init_params:
            init_dict["column_names"] = values["column_name_indexes"].keys()
        # Creates the instance.
        result = obj_type(**init_dict)
        # Sets the attributes.
        for k, v in values.items():
            setattr(result, k, v)
        return result
