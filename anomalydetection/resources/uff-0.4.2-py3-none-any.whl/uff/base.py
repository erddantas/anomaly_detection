#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

import pickle
from abc import ABC
from collections import namedtuple
from functools import wraps
from inspect import signature
from pathlib import Path
from typing import Any, Callable, Dict, Optional, Tuple, Type, Union

import pandas as pd

from .tstypes import (
    ColumnSet,
    TimeIndex,
    TimeIndexedData,
    TimeIndexedOutput,
    TimeIndexedOutputWithInterval,
)


class InitializationSpec:
    """A specification for creating an Estimator

    InitializationSpec is initialized with a type (cls), positional initialization arguments
    (excluding self) and keyword arguments. A TypeError will be thrown if these args cannot be
    bound to `cls`'s initialization signature. This abstraction is used to generate parameter
    search spaces for arbitrary estimators within UFF's model selection utilities.
    """

    def __init__(self, cls: Union[Type[Estimator], str], *args: Any, **kwargs: Any) -> None:
        if isinstance(cls, str):
            from .utils import get_estimator

            cls = get_estimator(cls)

        try:
            self.bound_args = signature(cls.__init__).bind(cls.__new__(cls), *args, **kwargs)
        except TypeError:
            raise TypeError(
                "The arguments provided are incompatible with the function signature "
                f"of {cls}.__init__"
            )

        self.cls = cls
        self.args = args
        self.kwargs = kwargs

    def __eq__(self, other):
        return type(self) is type(other) and self.to_dict() == other.to_dict()

    def create_instance(self) -> Estimator:
        return self.cls(*self.args, **self.kwargs)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "cls": self.cls,
            "args": self.args,
            "kwargs": self.kwargs,
        }

    @classmethod
    def from_dict(cls, json: Dict[str, Any]) -> InitializationSpec:
        if "cls" not in json:
            raise ValueError("Expected a dictionary with a 'cls' key.")

        unexpected_keys = set(json.keys()) - {"cls", "args", "kwargs"}
        if len(unexpected_keys) > 0:
            raise ValueError(f"Unexpected keys in dictionary: {', '.join(unexpected_keys)}")

        return cls(json["cls"], *json.get("args", []), **json.get("kwargs", {}))


def update_fit_attributes(callable):
    @wraps(callable)
    def new_fit(self: Estimator, data: TimeIndexedData, covariates=None, **kwargs):
        if self.requires_covariates and not isinstance(covariates, TimeIndexedData):
            raise ValueError("Covariates are required to fit the model but none were passed in.")
        res = callable(self, data, covariates=covariates, **kwargs)
        self.is_fit = True
        self.was_fit_with_covariates = isinstance(covariates, TimeIndexedData)
        self.earliest_fit_timestamp = data.first_timestamp_or_none()
        self.latest_fit_timestamp = data.last_timestamp_or_none()
        self.fit_data_row_shape = data.shape[1:]
        self.fit_data_columns = data.column_tuples
        if self.was_fit_with_covariates:
            self.fit_covariates_row_shape = covariates.shape[1:]
            self.fit_covariates_columns = covariates.column_tuples
        return res

    return new_fit


def check_state_and_input(callable):
    @wraps(callable)
    def new_predict(self: Estimator, data, **kwargs):
        if self.requires_fit and not self.is_fit:
            raise RuntimeError("Cannot call this function prior to fitting.")

        # To do: Refactor so Robust STL does not have multiple possible predict
        # interfaces. go/jira/DSTM-85
        if self._has_unambiguous_predict_method():
            if self.is_forecaster():
                if self.was_fit_with_covariates and not isinstance(data, TimeIndexedData):
                    # Forecasters that were fit with covariates must have covariates to forecast
                    raise ValueError("Covariates were expected but none were specified.")
                if isinstance(data, TimeIndexedData) and not self.was_fit_with_covariates:
                    # Forecasters without covariates only need the time index to forecast
                    data = data.time_index
            else:
                # All other Estimators require TimeIndexedData
                if not isinstance(data, TimeIndexedData):
                    raise ValueError(f"Expected TimeIndexedData but received {data}.")

        return callable(self, data, **kwargs)

    return new_predict


def set_init_attributes(
    original_function: Optional[Callable] = None,
    requires_fit: Optional[bool] = None,
    requires_covariates: Optional[bool] = None,
    set_params: bool = True,
    ray_serializable: Optional[bool] = None,
    joblib_serializable: Optional[bool] = None,
):
    def _decorate(function):
        @wraps(function)
        def wrapped_function(self: Estimator, *args, **kwargs):
            function(self, *args, **kwargs)
            if requires_fit is not None:
                self.requires_fit = requires_fit
            if requires_covariates is not None:
                self.requires_covariates = requires_covariates
            if set_params:
                self.params = InitializationSpec(type(self), *args, **kwargs)
            if ray_serializable is not None:
                self.ray_serializable = ray_serializable
            if joblib_serializable is not None:
                self.joblib_serializable = joblib_serializable

            if self.params is None:
                raise RuntimeError("params attribute must be set during initialization.")
            if self.is_forecaster_with_interval() and not self.is_forecaster():
                raise TypeError(
                    "Bad mixin state: a ForecasterWithInterval must also be a Forecaster."
                )
            if self.is_reversible_transformer() and not self.is_transformer():
                raise TypeError(
                    "Bad mixin state: a ReversibleTransformer must also be a Transformer."
                )
            if self.is_reversible_transformer() and self.is_feature_selector():
                raise TypeError(
                    "Bad mixin state: a FeatureSelector cannot also be a ReversibleTransformer "
                    "because the inputs to the transformation methods (data vs. covariates) are "
                    "not compatible."
                )

        return wrapped_function

    if original_function:
        return _decorate(original_function)

    return _decorate


ConvenienceWrappers = namedtuple(
    "ConvenienceWrappers",
    ["set_init_attributes", "update_fit_attributes", "check_state_and_input"],
)
decorators = ConvenienceWrappers(set_init_attributes, update_fit_attributes, check_state_and_input)


class Estimator:
    """Estimator base class

    The base class for all objects that calculate an estimate from observed data as part of their
    operation. This could be a simple mean/standard deviation calculation, or an optimization
    procedure to fit the parameters of a model.
    """

    # Private state variables which are masked by instance attributes updated throughout the
    # model's lifecycle by the property setters below.
    __is_fit: bool = False
    __was_fit_with_covariates: bool = False
    __requires_fit: bool = True
    __params: Optional[InitializationSpec] = None
    __requires_covariates: bool = False
    __ray_serializable: bool = True
    __joblib_serializable: bool = True

    # Private state variables for tracking `fit()` input metadata.
    __earliest_fit_timestamp: Optional[pd.Timestamp] = None
    __latest_fit_timestamp: Optional[pd.Timestamp] = None
    __fit_data_row_shape: Optional[Tuple[int, ...]] = None
    __fit_covariates_row_shape: Optional[Tuple[int, ...]] = None
    __fit_data_colums: Optional[ColumnSet] = None
    __fit_covariates_columns: Optional[ColumnSet] = None

    @property
    def params(self) -> InitializationSpec:
        if self.__params is None:
            raise RuntimeError("params attribute was not set during initialization.")
        return self.__params

    @params.setter
    def params(self, value: InitializationSpec) -> None:
        if self.is_fit:
            raise RuntimeError("params cannot be changed after an estimator is fit.")
        self.__params = value

    @property
    def is_fit(self) -> bool:
        return self.__is_fit

    @is_fit.setter
    def is_fit(self, value: bool) -> None:
        self.__is_fit = value

    @property
    def was_fit_with_covariates(self) -> bool:
        return self.__was_fit_with_covariates

    @was_fit_with_covariates.setter
    def was_fit_with_covariates(self, value: bool) -> None:
        self.__was_fit_with_covariates = value

    @property
    def requires_fit(self) -> bool:
        return self.__requires_fit

    @requires_fit.setter
    def requires_fit(self, value: bool) -> None:
        self.__requires_fit = value

    @property
    def requires_covariates(self) -> bool:
        return self.__requires_covariates

    @requires_covariates.setter
    def requires_covariates(self, value: bool) -> None:
        self.__requires_covariates = value

    @property
    def ray_serializable(self) -> bool:
        return self.__ray_serializable

    @ray_serializable.setter
    def ray_serializable(self, value: bool) -> None:
        self.__ray_serializable = value

    @property
    def joblib_serializable(self) -> bool:
        return self.__joblib_serializable

    @joblib_serializable.setter
    def joblib_serializable(self, value: bool) -> None:
        self.__joblib_serializable = value

    @property
    def earliest_fit_timestamp(self) -> Optional[pd.Timestamp]:
        return self.__earliest_fit_timestamp

    @earliest_fit_timestamp.setter
    def earliest_fit_timestamp(self, value: pd.Timestamp) -> None:
        self.__earliest_fit_timestamp = value

    @property
    def latest_fit_timestamp(self) -> Optional[pd.Timestamp]:
        return self.__latest_fit_timestamp

    @latest_fit_timestamp.setter
    def latest_fit_timestamp(self, value: pd.Timestamp) -> None:
        self.__latest_fit_timestamp = value

    @property
    def fit_data_row_shape(self) -> Optional[Tuple[int, ...]]:
        return self.__fit_data_row_shape

    @fit_data_row_shape.setter
    def fit_data_row_shape(self, value: Tuple[int, ...]) -> None:
        self.__fit_data_row_shape = value

    @property
    def fit_covariates_row_shape(self) -> Optional[Tuple[int, ...]]:
        return self.__fit_covariates_row_shape

    @fit_covariates_row_shape.setter
    def fit_covariates_row_shape(self, value: Tuple[int, ...]) -> None:
        self.__fit_covariates_row_shape = value

    @property
    def fit_data_columns(self) -> Optional[ColumnSet]:
        return self.__fit_data_colums

    @fit_data_columns.setter
    def fit_data_columns(self, value: ColumnSet) -> None:
        self.__fit_data_colums = value

    @property
    def fit_covariates_columns(self) -> Optional[ColumnSet]:
        return self.__fit_covariates_columns

    @fit_covariates_columns.setter
    def fit_covariates_columns(self, value: ColumnSet) -> None:
        self.__fit_covariates_columns = value

    def is_incremental(self) -> bool:
        return False

    def _has_unambiguous_predict_method(self) -> bool:
        c1 = self.is_forecaster() or self.is_forecaster_with_interval()
        c2 = self.is_transformer() or self.is_reversible_transformer()
        c3 = self.is_feature_selector()
        return sum([c1, c2, c3]) == 1

    def is_forecaster(self) -> bool:
        return False

    def is_forecaster_with_interval(self) -> bool:
        return False

    def is_transformer(self) -> bool:
        return False

    def is_reversible_transformer(self) -> bool:
        return False

    def is_feature_selector(self) -> bool:
        return False

    @update_fit_attributes
    def fit(
        self, data: TimeIndexedData, covariates: Optional[TimeIndexedData] = None, **kwargs
    ) -> Estimator:
        return self

    def save(self, path: str) -> None:
        """Persist this estimator at the location specified by `path`

        Parameters
        ----------
        path: str
            A path to the serialized Estimator's output destination.
        """
        from .io import cloudpickle_dump

        with Path(path).open("wb") as f:
            cloudpickle_dump(self, f, protocol=pickle.DEFAULT_PROTOCOL)

    @classmethod
    def load(cls, path: str) -> Estimator:
        """Load a previously saved Estimator instance from `path`

        Parameters
        ----------
        path: str
            A path to the serialized Estimator
        """
        from .io import cloudpickle_load

        with Path(path).open("rb") as f:
            return cloudpickle_load(f)

    @classmethod
    def search_space(cls, *args: Any, **kwargs: Any) -> InitializationSpec:
        """Generate a dictionary of search parameters for the given class.

        This method uses the `inspect` module to match the function signature of `cls.__init__`
        and selectively override values with searchable parameter space values. The type hints
        for this method are intentionally very permissive to allow users flexibility in searching
        the space of the initialization fields.

        Parameters
        ----------
        **kwargs: Dict[str, Any]
            All entries should match an expected name from cls.__init__ and either match the
            expected type (in the case of a literal value) or contain an acceptable parameter
            specification (e.g. an hpt.Apply or an ax.Parameter object). It is the users
            responsibility to make sure that the parameter specifications will be valid inputs
            to __init__ after they are resolved by hyperopt or Ax.

        Returns
        -------
        InitializationSpec
            An initialization specification with the provided arguments bound to the class's
            initialization signature
        """
        return InitializationSpec(cls, *args, **kwargs)


class Incremental(ABC):
    """Base class for all estimators with the ability to learn "online"

    Estimators with the Incremental mixin can perform a partial fit, or a parameter update based
    on a small number of samples. This method can be called multiple times throughout the
    Estimator instance's lifecycle.
    """

    def is_incremental(self) -> bool:
        return True

    def partial_fit(
        self, data: TimeIndexedData, covariates: Optional[TimeIndexedData] = None, **kwargs
    ) -> Estimator: ...


class Transformer(Estimator):
    """Base class providing the .transform() method

    Transformers use the `transform()` method to accept TimeIndexedData and output
    TimeIndexedOutput.

    The `out` attribute of the transform() result is expected to preserve the same shapes
    (same index and column values) as the `data` object passed into .transform().  Additional
    outputs can be specified as separate attributes.
    """

    def is_transformer(self) -> bool:
        return True

    def transform(self, data: TimeIndexedData, **kwargs) -> TimeIndexedOutput: ...


class ReversibleTransformer(Transformer):
    """A Transformer subclass which also implements the `inverse_transform` method.

    Besides the additional method, ReversibleTransformers share all the same properties as
    Transformers.
    """

    def is_reversible_transformer(self) -> bool:
        return True

    def inverse_transform(self, data: TimeIndexedData, **kwargs) -> TimeIndexedOutput: ...


class FeatureSelector(Estimator):
    """A class implementing a feature selector interface.

    FeatureSelectors accept covariates to `transform_covariates()` and should return a result that
    has the same TimeIndex of the input, but a different column set. The most common use case for
    feature selection is to remove columns from the input data, but this interface can also be
    used to add new columns or encode existing columns in a different way.
    """

    def is_feature_selector(self) -> bool:
        return True

    def transform_covariates(self, data: TimeIndexedData, **kwargs) -> TimeIndexedOutput: ...


class Forecaster(Estimator):
    """Base class providing the .forecast() method

    Forecasters predict values of a given TimeIndexedData object. This mixin should almost always
    be used in conjunction with an Estimator. When used inside an Estimator, `forecast()` should
    predict the past/future values of the same TimeIndexedData that was used during
    `.fit()` / `.update()`

    The `out` attribute of .forecast() is expected to preserve the same shapes (same index and
    column values) as the `data` object passed into .transform().  Typically, these will be point
    estimates from the model. Additional outputs can be specified as separate attributes.
    """

    def is_forecaster(self) -> bool:
        return True

    def forecast(
        self,
        data: Union[TimeIndex, TimeIndexedData],
        **kwargs,
    ) -> TimeIndexedOutput: ...


class ForecasterWithInterval(Forecaster):
    """A Forecaster object with an adjustable prediction interval width.

    All subclasses of this type must accept `prediction_interval_width` as an initialization
    parameter
    """

    __Forecaster_prediction_interval_width: Optional[float] = None

    def is_forecaster_with_interval(self) -> bool:
        return True

    @property
    def prediction_interval_width(self) -> float:
        if self.__Forecaster_prediction_interval_width is None:
            raise RuntimeError(
                "ForecasterWithInterval has not properly set `prediction_interval_width` attribute."
            )
        return self.__Forecaster_prediction_interval_width

    @prediction_interval_width.setter
    def prediction_interval_width(self, value: float) -> None:
        if self.is_fit:
            raise RuntimeError(
                "prediction_interval_width cannot be changed after an estimator is fit."
            )
        self.__Forecaster_prediction_interval_width = value

    def forecast(
        self,
        data: Union[TimeIndex, TimeIndexedData],
        **kwargs,
    ) -> TimeIndexedOutputWithInterval: ...
