#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from datetime import timezone

import pandas as pd

"""
We are making the choice to use pandas Timestamp and Timedelta objects as the first-class time types
in UFF. In addition to providing easier casting between date, datetime, np.datetime64, etc. the
pandas types are used by PySpark. The highest level abstractions will accept other datetime types
as input, but internally UFF will use pandas types and integers to represent time stamps.
"""
EPOCH_TIME_UTC = pd.Timestamp(year=1970, month=1, day=1, tzinfo=timezone.utc)
EPOCH_TIME_NO_TZ = pd.Timestamp(year=1970, month=1, day=1)

ZERO_DELTA = pd.Timedelta(nanoseconds=0)
ONE_NANOSECOND = pd.Timedelta(nanoseconds=1)
ONE_MILLISECOND = pd.Timedelta(milliseconds=1)
ONE_SECOND = pd.Timedelta(seconds=1)
ONE_MINUTE = pd.Timedelta(minutes=1)
ONE_HOUR = pd.Timedelta(hours=1)
ONE_DAY = pd.Timedelta(days=1)

# A very small positive number
EPSILON = 1e-10
