#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from abc import abstractmethod
from contextlib import contextmanager
from dataclasses import dataclass
from functools import partial
from typing import (
    Any,
    Awaitable,
    Generator,
    Iterable,
    List,
    Optional,
    Protocol,
    Tuple,
    TypeVar,
    Union,
)


class RayContext(Protocol):
    @abstractmethod
    def __enter__(self): ...

    @abstractmethod
    def __exit__(self): ...


class Parallel(Protocol):
    @abstractmethod
    def __call__(self, *args: Any) -> Iterable: ...


T = TypeVar("T")


@dataclass(frozen=True)
class _DistributeContext:
    ray_context: Optional[RayContext] = None
    joblib_parallel: Optional[Parallel] = None

    def __post_init__(self) -> None:
        if self.ray_context is not None and self.joblib_parallel is not None:
            raise ValueError("Cannot specify both a Ray and Joblib context.")
        if self.joblib_parallel is not None:
            return_as = getattr(self.joblib_parallel, "return_as", None)
            if return_as not in ("list", "generator", None):
                raise ValueError(
                    f"UFF parallelization does not support joblib return_as {return_as}"
                )

    @property
    def backend(self) -> Optional[str]:
        if self.ray_context is not None:
            return "ray"
        if self.joblib_parallel is not None:
            return "joblib"
        return None


__context: _DistributeContext = _DistributeContext()


def current_backend() -> Optional[str]:
    return __context.backend


def current_context() -> _DistributeContext:
    return __context


def _is_joblib(context: Union[RayContext, Parallel]) -> bool:
    try:
        from joblib import Parallel

        return isinstance(context, Parallel)
    except Exception:
        return False


def _is_ray(context: Union[RayContext, Parallel]):
    try:
        from ray._private.worker import RayContext

        return isinstance(context, RayContext)
    except Exception:
        return False


def _default_context() -> _DistributeContext:
    from joblib import Parallel

    return _DistributeContext(joblib_parallel=Parallel(n_jobs=-1))


@contextmanager
def distribute(context: Optional[Union[RayContext, Parallel]] = None) -> None:
    """Sets the global parallelization backend to a Ray or Joblib context.

    Many UFF estimators are designed to reference this global state for smart dependency-aware
    parallelization.

    A few examples are

    * uff.meta.ColumnEnsembleEstimator will parallelize the training of individual columns
    * uff.evaluate.backtester.BackTester will parellelize the training and evaluation of individual
      time slices
    * uff.evaluate.tune.RandomSearchTuner and GridSearchTuner will parallelize the training of
      individual parameterizations (the internal BackTester will also be parallelized).

    Users are still encouraged to leverage the parallel computation on their own. In fact a
    uff.distributed.distribute() context manager can be leveraged inside of a `ray.remote` task or
    inside of an joblib.Parallel iterable. Composing this logic together gives users control over
    higher-level parallelization in the application logic, while not having to worry about
    low-level parallelization occurring deep inside built-in UFF classes.

    Parameters
    ----------
    context: Optional[Union[RayContext, Parallel]], default None
        A Ray context manager returned by ray.init(), or a joblib.Parallel instance. If not
        specified, joblib.Parallel will be used with `n_jobs=-1, backend="loky"`

    Yields
    ------
    None
    """
    global __context
    old_context = __context

    if context is None:
        __context = _default_context()
    elif _is_joblib(context):
        __context = _DistributeContext(joblib_parallel=context)
    elif _is_ray(context):
        __context = _DistributeContext(ray_context=context)
    else:
        raise ValueError(f"Unable to determine the appropriate backend for {context}")

    try:
        yield
    finally:
        # Reset global context
        __context = old_context


def conditional_distributed_evaluate(
    task_grid: List[Union[partial, List]],
    wait_for_all: bool = True,
    distribution_checks: Optional[Union[bool, Iterable[bool]]] = None,
) -> List[Any]:
    """Parallelize the evaluation of partials() if current_backend() is not None

    Parameters
    ----------
    task_grid: List[Union[partial, List]]
        A (possibly nested) list of functools.partial objects.
    wait_for_all: bool, default True
        If True, execution will be blocked with until results are ready. This argument is
        ignored when backend = "joblib" because joblib.Parallel is purely synchronous.
    distribution_checks: Optional[Union[bool, Iterable[bool]]], default None
        If provided, these are additional conditions that will be evaluated at runtime to turn
        the parallelization off. Tasks will only be distributed if all(execution_flags) == True

    Returns
    -------
    List[Any]
        A collection of results matching the shape of `task_grid`
    """
    if isinstance(distribution_checks, bool):
        distribution_checks = [distribution_checks]
    if distribution_checks is None or all(distribution_checks):
        backend = current_backend()
        if backend == "ray":
            return _run_parallel_ray(task_grid, wait_for_all=wait_for_all)
        elif backend == "joblib":
            return _run_parallel_joblib(task_grid)

    return _apply_shape(
        task_grid,
        [f() for _, f in _inorder_traversal(task_grid)],
    )


def conditional_reference(obj: T) -> Union[T, Awaitable]:
    """Return a Ray Awaitable referencing `obj` if current_backend() == "ray"

    Parameters
    ----------
    obj: T
        An object of any type to which a reference may be created

    Returns
    -------
    Union[T, Awaitable]
        Either the original object, or the output of ray.put(obj)
    """
    if current_backend() != "ray":
        return obj

    from ray import put

    return put(obj)


def _run_parallel_ray(
    task_grid: List[Union[partial, List]],
    wait_for_all: bool = True,
) -> List[Any]:
    """Distribute execution of a nested list of partials using Ray.

    Parameters
    ----------
    task_grid: List[Union[partial, List]]
        A (possibly nested) list of functools.partial objects. Internally the `partial` object is
        used to find the module function and bound arguments so that the function can be safely
        distributed by ray.remote.
    wait_for_all: bool, default True
        If True, execution will be blocked with ray.get() until results are ready.

    Returns
    -------
    List[Any]
        A collection of results matching the shape of `task_grid`
    """
    from ray import get, remote

    partials = [p for _, p in _inorder_traversal(task_grid)]
    handles = [remote(p.func) for p in partials]
    refs = [handle.remote(*p.args, **p.keywords) for handle, p in zip(handles, partials)]
    results = [get(ref) for ref in refs] if wait_for_all else refs
    return _apply_shape(task_grid, results)


def _run_parallel_joblib(
    task_grid: List[Union[partial, List]],
) -> List[Any]:
    """Distribute execution of a nested list of partials using Ray.

    Parameters
    ----------
    task_grid: List[Union[partial, List]]
        A (possibly nested) list of functools.partial objects.

    Returns
    -------
    List[Any]
        A collection of results matching the shape of `task_grid`
    """
    from joblib import delayed

    parallel = current_context().joblib_parallel

    partials = [p for _, p in _inorder_traversal(task_grid)]
    results = parallel(delayed(p.func)(*p.args, **p.keywords) for p in partials)
    return _apply_shape(task_grid, list(results))


def _inorder_traversal(
    arr: List[Any],
    coords: Optional[Tuple[int, ...]] = None,
) -> Generator[Tuple[Tuple[int, ...], Any], None, None]:
    """Traverse a list of nested lists in order

    Parameters
    ----------
    arr: List[Any]
        A nested list of lists
    parent: Optional[Tuple[int, ...]], default None
        Used to keep track of parent information in recursive calls.

    Yields
    ------
    Tuple[Tuple[int, ...], Any]
        Coordinates and values e.g. ((0, 0, 1), x)
    """
    if coords is None:
        coords = tuple()

    if isinstance(arr, list):
        for i, arr_entry in enumerate(arr):
            new_coords = coords + (i,)
            for x in _inorder_traversal(arr_entry, new_coords):
                yield x
    else:
        yield (coords, arr)


def _apply_shape(container: List[Any], values: List[Any]) -> List[Any]:
    """Copy the shape of `container` using the values in `values`

    Parameters
    ----------
    container: List[Any]
        A nested list of lists
    values: List[Any]
        A flat list of values which should have the same number of entries as `container`

    Returns
    -------
    List[Any]
        The values of `values` reshaped to match the shape of `container`
    """
    if isinstance(values, list):
        values = iter(values)
    if isinstance(container, list):
        return [_apply_shape(x, values) for x in container]
    else:
        return next(values)
