#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

from dataclasses import dataclass
from functools import partial
from typing import (
    Any,
    Awaitable,
    Callable,
    Dict,
    Iterable,
    List,
    Optional,
    Tuple,
    Union,
)

import numpy as np
import pandas as pd

from .. import utils
from ..base import InitializationSpec, TimeIndexedData, TimeIndexedOutput
from ..distributed import conditional_distributed_evaluate, conditional_reference
from ..evaluation.metrics import get_metric


@dataclass
class BacktestResult:
    spec: InitializationSpec
    seed: int
    fit_data: TimeIndexedData
    fit_covariates: Optional[TimeIndexedData]
    eval_data: TimeIndexedData
    eval_covariates: Optional[TimeIndexedData]
    result: TimeIndexedOutput

    def estimator(self, fitted: bool = False):
        """Recover the estimator from the backtest result

        Parameters
        ----------
        fitted: bool, default False
            If True, the model will be deterministically refitted before returning.

        Returns
        -------
        Estimator
        """
        with utils.deterministic_rng(self.seed):
            estimator = self.spec.create_instance()
            if fitted:
                estimator.fit(self.fit_data, self.fit_covariates)
        return estimator


@dataclass
class _TimeSlicePair:
    fit: Tuple[pd.Timestamp, pd.Timestamp]
    evaluate: Tuple[pd.Timestamp, pd.Timestamp]

    def entire_range(self) -> Tuple[pd.Timestamp, pd.Timestamp]:
        return (
            min(self.fit[0], self.evaluate[0]),
            max(self.fit[1], self.evaluate[1]),
        )


class BackTester:
    """A utility for back-testing Transformers and Forecasters

    Backtester fits and evaluates a model on different slices of the input data & covariates.
    """

    def __init__(
        self,
        data: TimeIndexedData,
        covariates: Optional[TimeIndexedData] = None,
        step_size: int = 1,
        min_fit_window_size: int = 0,
        evaluation_window_size: Optional[int] = None,
        fit_window_type: str = "expanding",
        step_mode: str = "time",
        right_align: bool = False,
    ) -> None:
        """Initialize a BackTester

        Parameters
        ----------
        data: TimeIndexedData
            The data that will be used for fitting and transforming/forecasting
        covariates: Optional[TimeIndexedData], default None
            Optional covariates that can be used for fitting and transforming/forecasting. If
            provided, BackTester assumes that the model's predict step accepts covariates as input.
        step_size: int
            The amount of time between backtest periods will be `step_size x data.granularity`
        min_fit_window_size: int, default 0
            If specified, then evaluation will exclude all slices where the fit window duration is
            less than `min_fit_window_size x data.granularity`.
        evaluation_window_size: Optional[int], default None
            An optional evaluation window horizon. If not provided, then it will be the same as
            `step_size`. Set this to a negative value to perform in-sample predictions (e.g. for
            outlier detection).
        fit_window_type: str, default "expanding"
            Either "expanding" or "rolling". If "expanding" then the fit window will start from the
            beginning of `data` and grow with each successive back-test. If "rolling" then the
            start of the fit window will increase by `step_size` on each iteration (note with
            "rolling" the fit window will always be `min_fit_window_size`).
        step_mode: str, default "time"
            Either "time" or "samples". When "time" then each step will cover a constant unit of
            time, otherwise each step will cover a constant number of samples.
        right_align: bool, default False
            Whether to right-align the evaluation windows. If False (default) then the evaluation
            windows will be computed from left to right, starting at index 0 and proceeding forward
            by `step_size`. As a result, some trailing entries in `data` may never be evaluated. If
            True, then the first window will be computed such that the end of the evaluation window
            is flush with the end of `data`, and subsequent windows will be generated in reverse
            starting from that point.

        Raises
        ------
        ValueError
            If any of the following are true: data and covariates have different time indices;
            step size <= 0; min_fit_window_size is negative; fit_window_type is 'rolling' and
            min_fit_window_size is <1; fit_window_type is not 'expanding' or 'rolling';
            evaluation_window_size is 0; step_mode is not 'time' or 'samples'; a specified
            in-sample evaluation window is larger than a specified rolling fit window
        """
        if evaluation_window_size is None:
            evaluation_window_size = step_size
        if covariates is not None:
            if covariates.time_index != data.time_index:
                raise ValueError("Data and covariates must have matching time indices")
        if step_size <= 0:
            raise ValueError("Step size must be positive")
        if min_fit_window_size < 0:
            raise ValueError("Initial fit window size cannot be negative")
        if fit_window_type == "rolling" and min_fit_window_size < 1:
            raise ValueError(
                "Minimum fit window size must be positive if batch_window_type is 'rolling'"
            )
        if fit_window_type not in ("expanding", "rolling"):
            raise ValueError(f"Unexpected batch window type: '{fit_window_type}'")
        if step_mode not in ("time", "samples"):
            raise ValueError(f"Unexpected step mode: '{step_mode}'")
        if evaluation_window_size == 0:
            raise ValueError("Evaluation window size cannot be 0")
        if (
            evaluation_window_size < 0
            and fit_window_type == "rolling"
            and abs(evaluation_window_size) > min_fit_window_size
        ):
            raise ValueError("In-sample evaluation window is larger than the rolling fit window")

        self._data = data
        self._cov = covariates
        self._domain = (
            data.time_index if step_mode == "samples" else utils.make_dense(data).time_index
        )

        self._step_size = step_size
        self._min_fit_window_size = min_fit_window_size
        self._evaluation_window_size = evaluation_window_size
        self._fit_window_type = fit_window_type
        self._rolling_window = fit_window_type == "rolling"
        self._right_align = right_align

        self._t_values = self._domain.timestamp_values
        self._t_upper_excl = self._domain.future(1).timestamp_values[0]
        self._slices = self._get_time_slice_pairs()

    @staticmethod
    def score_results(
        results: Iterable[BacktestResult],
        scorer: Union[str, Callable[[BacktestResult], float]],
    ) -> List[float]:
        """Score the estimator results

        Parameters
        ----------
        results: Iterable[BacktestResult]
            The set of results to score
        scorer: Union[str, Callable[[BacktestResult], float]]
            A callable that accepts a BacktestResult and returns a scalar score value, or a string
            referencing a UFF/sklearn metric
            (https://scikit-learn.org/stable/modules/model_evaluation.html). If a string is
            provided, the scorer will be evaluated as `scorer(x.eval_data, x.result.out)`. This is
            a reasonable default for forecasters where the goal is to estimate the values of the
            input data.

        Returns
        -------
        List[float]
            One scalar score per model evaluation.
        """
        if isinstance(scorer, str):
            score_func = get_metric(scorer)

            def scorer(res: BacktestResult) -> float:
                return score_func(res.eval_data, res.result.out)

        return [scorer(res) for res in results]

    def plot_slices(self, ax) -> None:
        """Visualize the backtest fit/evaluate windows

        Parameters
        ----------
        ax: matplotlib.axes.Axes
            An axis object to update in-place with the backtester slice plot
        """
        slices = self._slices[::-1]
        y = list(range(len(slices)))

        labels = ("Fit", "Evaluate")
        data = ([s.fit for s in slices], [s.evaluate for s in slices])

        for label, intervals in zip(labels, data):
            t1 = np.array([i[0] for i in intervals])
            t2 = np.array([i[1] for i in intervals])
            kwargs = {"height": 0.9} if label == "Fit" else {}
            ax.barh(y, width=t2 - t1, left=t1, label=label, **kwargs)

        ax.set_yticks(y)
        ax.set_yticklabels(y[::-1])
        ax.legend(loc="upper right")

    def evaluate(
        self,
        estimator: InitializationSpec,
        max_evaluations: Optional[int] = None,
        most_recent_first: bool = True,
        in_sample: bool = False,
        fit_kwargs: Optional[Dict[str, Any]] = None,
        predict_kwargs: Optional[Dict[str, Any]] = None,
    ) -> List[BacktestResult]:
        """Fit and evaluate an estimator

        Both BatchEstimators and OnlineEstimators are evaluated in "batch mode" (from scratch each
        time) such that the individual evaluations can be parallelized.

        Parameters
        ----------
        estimator: InitializationSpec
            Initialization arguments of the estimator which should be evaluated.
        max_evaluations: Optional[int], default None
            An optional limit on the number of evaluations to compute
        most_recent_first: bool, default True
            Whether or not to evaluate the most recent evaluation windows first.
        in_sample: bool, default False
            If True, models will be evaluated based on their in-sample predictions. This means that
            `evaluation` slices will be included in `fit` and then `forecast()` or `transform()`
            (depending on the estimator) will be called on the previously-fit samples.
        fit_kwargs:  Optional[Dict[str, Any]], default None
            If provided, these will be passed to estimator.fit()
        predict_kwargs: Optional[Dict[str, Any]], default None
            If provided, these will be passed to estimator.transform() or estimator.forecast()

        Returns
        -------
        List[BacktestResult]
            The set of backtest results
        """
        tasks = self.generate_tasks(
            estimator,
            max_evaluations=max_evaluations,
            most_recent_first=most_recent_first,
            in_sample=in_sample,
            fit_kwargs=fit_kwargs,
            predict_kwargs=predict_kwargs,
        )
        return self.process_task_results(conditional_distributed_evaluate(tasks))

    @staticmethod
    def process_task_results(
        results: List[Union[Exception, BacktestResult]]
    ) -> List[BacktestResult]:
        """Process the results of BackTester.generate_tasks

        Parameters
        ----------
        results: List[Union[Exception, BacktestResult]]
            A list of results from the evalauation of `generate_tasks()` callables.

        Returns
        -------
        List[BacktestResult]
            Raises any caught exceptions. If none are found, returns the list of BacktestResult
            objects.
        """
        for r in results:
            if isinstance(r, Exception):
                raise r
        return results

    def generate_tasks(
        self,
        estimator: InitializationSpec,
        max_evaluations: Optional[int] = None,
        most_recent_first: bool = True,
        in_sample: bool = False,
        fit_kwargs: Optional[Dict[str, Any]] = None,
        predict_kwargs: Optional[Dict[str, Any]] = None,
        data_ref: Optional[Awaitable] = None,
        cov_ref: Optional[Awaitable] = None,
    ) -> List[partial]:
        """Generate a list of tasks per the argument specifications.

        The resulting tasks can be evaluated sequentially or parallelized.

        Parameters
        ----------
        estimator: InitializationSpec
            Initialization arguments of the estimator which should be evaluated.
        max_evaluations: Optional[int], default None
            An optional limit on the number of evaluations to compute
        most_recent_first: bool, default True
            Whether or not to evaluate the most recent evaluation windows first.
        in_sample: bool, default False
            If True, models will be evaluated based on their in-sample predictions. This means that
            `evaluation` slices will be included in `fit` and then `forecast()` or `transform()`
            (depending on the estimator) will be called on the previously-fit samples.
        fit_kwargs:  Optional[Dict[str, Any]], default None
            If provided, these will be passed to estimator.fit()
        predict_kwargs: Optional[Dict[str, Any]], default None
            If provided, these will be passed to estimator.transform() or estimator.forecast()
        data_ref: Optional[Awaitable]
            If `data` was previously added to a distributed object store via uff.distributed object
            store, a reference to the stored object can be passed here to override the local
            variable. This should almost never be used outside of other uff classes.
        cov_ref: Optional[Awaitable]
            If `covariates` was previously added to a distributed object store via uff.distributed
            object store, a reference to the stored object can be passed here to override the local
            variable. This should almost never be used outside of other uff classes.

        Returns
        -------
        List[partial]
            A list of tasks
        """
        pairs = list(reversed(self._slices)) if most_recent_first else self._slices
        max_i = len(pairs)
        if max_evaluations is not None:
            max_i = min(max_i, max_evaluations)

        data = conditional_reference(self._data) if data_ref is None else data_ref
        covariates = conditional_reference(self._cov) if cov_ref is None else cov_ref
        return [
            partial(
                _evaluate_one,
                utils.random_seed(),
                data,
                covariates,
                estimator,
                pairs[i],
                in_sample,
                fit_kwargs,
                predict_kwargs,
            )
            for i in range(max_i)
        ]

    def _get_time_slice_pairs(self) -> List[_TimeSlicePair]:
        """Generate paired fit/evaluate time slices.

        Returns
        -------
        List[_TimeSlicePair]
            A list of paired fit/evaluate time slices, based on the specification.

        Raises
        ------
        ValueError
            If any of the following are true: step size <= 0; min_fit_window_size is negative;
            fit_window_type is 'rolling' and min_fit_window_size is <1; fit_window_type is not
            'expanding' or 'rolling'; evaluation_window_size is 0
        """
        max_window_end = len(self._domain)

        if self._right_align:
            last_train_end = max_window_end - max(self._evaluation_window_size, 0)
            train_ends = reversed(range(last_train_end, -1, -self._step_size))
        else:
            train_ends = range(0, max_window_end, self._step_size)

        train_windows, eval_windows = [], []
        for train_end in train_ends:
            train_start = (train_end - self._min_fit_window_size) if self._rolling_window else 0
            eval_start, eval_end = sorted((train_end, train_end + self._evaluation_window_size))

            if (
                train_end - train_start >= self._min_fit_window_size
                and 0 <= train_start < max_window_end
                and 0 <= eval_start < max_window_end
                and 1 <= eval_end <= max_window_end
            ):
                train_windows.append(self._time_slice(train_start, train_end))
                eval_windows.append(self._time_slice(eval_start, eval_end))

        return [_TimeSlicePair(fit, evaluate) for fit, evaluate in zip(train_windows, eval_windows)]

    def _time_slice(self, i1: int, i2: int) -> Tuple[pd.Timestamp, pd.Timestamp]:
        """Translate integer slices to time slices so that they can be applied on any TimeIndex

        Parameters
        ----------
        i1: int
            The start (inclusive) of the slice
        i2: int
            The end (exclusive) of the slice

        Returns
        -------
        Tuple[pd.Timestamp, pd.Timestamp]
            The start (inclusive) and end (exclusive) of the time slice.
        """
        t1 = self._t_values[max(i1, 0)] if i1 < len(self._t_values) else self._t_upper_excl
        t2 = self._t_values[max(i2, 0)] if i2 < len(self._t_values) else self._t_upper_excl
        return (t1, t2)


def _evaluate_one(
    seed: int,
    data: TimeIndexedData,
    covariates: Optional[TimeIndexedData],
    spec: InitializationSpec,
    pair: _TimeSlicePair,
    in_sample: bool,
    fit_kwargs: Optional[Dict[str, Any]] = None,
    predict_kwargs: Optional[Dict[str, Any]] = None,
) -> Union[BacktestResult, Exception]:
    """Fit and evaluate an estimator on the _TimeSlicePair

    Parameters
    ----------
    seed: int
        Will be used with uff.deterministic_rng
    data: TimeIndexedData
        Data to evaluate
    covariates: Optional[TimeIndexedData]
        Optional covariates to evaluate
    spec: InitializationSpec
        Initialization arguments of the estimator which should be evaluated.
    pair: _TimeSlicePair
        A fit/evaluate pair of time slices. These will be generated based on the user specification
    in_sample: bool
        If True, models will be evaluated based on their in-sample predictions. This means that
        `evaluation` slices will be included in `fit` and then `forecast()` or `transform()`
        (depending on the estimator) will be called on the previously-fit samples.
    fit_kwargs:  Optional[Dict[str, Any]], default None
        If provided, these will be passed to estimator.fit()
    predict_kwargs: Optional[Dict[str, Any]], default None
        If provided, these will be passed to estimator.trasform() or estimator.forecast()

    Returns
    -------
    Union[BacktestResult, Exception]
        The backtest result, or any caught exception.
    """
    try:
        fit_kwargs = fit_kwargs or {}
        predict_kwargs = predict_kwargs or {}

        fit_slice = pair.entire_range() if in_sample else pair.fit
        fit_data = _coalesce_data(data, fit_slice)
        fit_cov = _coalesce_data(covariates, fit_slice)

        eval_data = _coalesce_data(data, pair.evaluate)
        eval_cov = _coalesce_data(covariates, pair.evaluate)
        pred_input = eval_cov or eval_data

        estimator = spec.create_instance()

        with utils.deterministic_rng(seed):
            estimator.fit(fit_data, fit_cov, **fit_kwargs)

            if callable(getattr(estimator, "forecast", None)):
                result = estimator.forecast(pred_input, **predict_kwargs)
            else:
                result = estimator.transform(pred_input, **predict_kwargs)

        return BacktestResult(
            spec=spec,
            seed=seed,
            fit_data=fit_data,
            fit_covariates=fit_cov,
            eval_data=eval_data,
            eval_covariates=eval_cov,
            result=result,
        )
    except Exception as e:
        return e


def _coalesce_data(
    data: Optional[TimeIndexedData],
    time_slice: Optional[Tuple[pd.Timestamp, pd.Timestamp]],
) -> Optional[TimeIndexedData]:
    """Return TimeIndexedData if data and time_slice are both non-null

    Parameters
    ----------
    data: Optional[TimeIndexedData]
        A time series, or None
    time_slice: Optional[Tuple[pd.Timestamp, pd.Timestamp]]
        A [start, end) time window, or None

    Returns
    -------
    Optional[TimeIndexedData]
        A slice of the original TimeIndexedData instance, if applicable. Else None.
    """
    if data is None or time_slice is None:
        return None

    return data.time_slice(*time_slice, copy_data=False)
