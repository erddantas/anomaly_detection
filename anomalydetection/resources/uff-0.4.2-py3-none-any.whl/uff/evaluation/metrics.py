#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import functools
from typing import Callable

import numpy as np
import numpy.typing as npt
from sklearn import metrics

_METRIC_REGISTRY = {
    "mae": metrics.mean_absolute_error,
    "mse": metrics.mean_squared_error,
    "mean_squared_error": metrics.mean_squared_error,
}


def uff_metric(func):
    @functools.wraps(func)
    def wrap(*args: "npt.ArrayLike", **kwargs):
        args = [np.array(a) for a in args]
        return func(*args, **kwargs)

    _METRIC_REGISTRY[func.__name__] = wrap
    return wrap


@uff_metric
def smape(actual: "npt.NDArray", prediction: "npt.NDArray") -> float:
    """
    Symmetric mean absolute percentage error (SMAPE or sMAPE). The sMAPE is the average across all
    forecasts made for a given horizon. This metric fluctuates between 0% and 200%.

    Numerator: absolute difference between actual and prediction
    Denominator: sum of absolute value of actual and prediction

    Parameters
    ----------
    actual: npt.NDArray
        Time series of actual / observed / expected values
    prediction: npt.NDArray
        Time series of predicted values

    Returns
    -------
    float
        The value of the ratio described above
    """
    return 2 * np.mean(
        np.ma.masked_invalid(np.abs(actual - prediction) / (np.abs(actual) + np.abs(prediction)))
    )


@uff_metric
def mape(actual: "npt.NDArray", prediction: "npt.NDArray") -> float:
    """
    Mean absolute percentage error (MAPE).
    MAPE is calculated by taking the average (mean) of the absolute difference between actuals and
    predicted values divided by the actuals.

    Numerator: absolute difference between actual and prediction
    Denominator: actual

    Parameters
    ----------
    actual: npt.NDArray
        Time series of actual / observed / expected values
    prediction: npt.NDArray
        Time series of predicted values

    Returns
    -------
    float
        The value of the ratio described above
    """
    return np.mean(np.ma.masked_invalid(np.abs((actual - prediction) / actual)))


@uff_metric
def wmape(actual: "npt.NDArray", prediction: "npt.NDArray") -> float:
    """
    Weighted mean absolute percentage error.
    Similar to MAPE with weights.
    Weights is caculated by the ratio of absolute value of actual vs sum of absolute value of
    actual.

    Numerator: Weighted absolute difference between actual and prediction
    Denominator: actual

    Parameters
    ----------
    actual: npt.NDArray
        Time series of actual / observed / expected values
    prediction: npt.NDArray
        Time series of predicted values

    Returns
    -------
    float
        The value of the ratio described above
    """
    weights = np.abs(actual) / np.sum(np.abs(actual))
    return np.sum(np.ma.masked_invalid(weights * np.abs((actual - prediction) / actual)))


@uff_metric
def wsmape(actual: "npt.NDArray", prediction: "npt.NDArray") -> float:
    """
    Weighted symmetric mean absolute percentage error.
    Similar to SMAPE with weights.
    Weights is caculated by the ratio of absolute value of actual vs sum of absolute value of
    actual.

    Numerator: Weighted absolute difference between actual and prediction
    Denominator: sum of absolute value of actual and prediction

    Parameters
    ----------
    actual: npt.NDArray
        Time series of actual / observed / expected values
    prediction: npt.NDArray
        Time series of predicted values

    Returns
    -------
    float
        The value of the ratio described above
    """
    weights = np.abs(actual) / np.sum(np.abs(actual))
    return 2 * np.sum(
        np.ma.masked_invalid(
            weights * np.abs(actual - prediction) / (np.abs(actual) + np.abs(prediction))
        )
    )


@uff_metric
def mdrae(actual: "npt.NDArray", prediction: "npt.NDArray", benchmark: "npt.NDArray") -> float:
    """
    Median Relateive Absolute Error.
    The MdRAE calculates the median of the difference between the absolute error of our forecast to
    the absolute error of a benchmark model.

    Numerator: absolute error of forecast
    Denominator:  absolute error of benchmark

    Parameters
    ----------
    actual: npt.NDArray
        Time series of actual / observed / expected values
    prediction: npt.NDArray
        Time series of predicted values
    benchmark: npt.NDArray
        Time series of benchmark values

    Returns
    -------
    float
        The value of the ratio described above
    """
    return np.nanmedian(np.abs(actual - prediction) / np.abs(actual - benchmark))


@uff_metric
def gmrae(actual: "npt.NDArray", prediction: "npt.NDArray", benchmark: "npt.NDArray") -> float:
    """
    Geometric Mean Relative Absolute Error.
    The GMRAE calculates the geometric mean of the difference between the absolute error of our
    forecast to the absolute error of a benchmark model.

    Numerator: absolute error of forecast
    Denominator:  absolute error of benchmark

    Parameters
    ----------
    actual: npt.NDArray
        Time series of actual / observed / expected values
    prediction: npt.NDArray
        Time series of predicted values
    benchmark: npt.NDArray
        Time series of benchmark values

    Returns
    -------
    float
        The value of the ratio described above
    """
    abs_scaled_errors = np.abs(actual - prediction) / np.abs(actual - benchmark)
    return np.exp(np.mean(np.ma.masked_invalid(np.log(abs_scaled_errors))))


@uff_metric
def mase(
    actual: "npt.NDArray", prediction: "npt.NDArray", training: "npt.NDArray", *, step: int = 1
) -> float:
    """
    Mean Absolute Scaled Error.
    The MASE is calculated by taking the MAE and dividing it by the MAE of an in-sample (based on
    the training data) naive benchmark.

    Numerator: MAE of actual and prediction
    Denominator: in-sample MAE of training data

    Parameters
    ----------
    actual: npt.NDArray
        Time series of actual / observed / expected values
    prediction: npt.NDArray
        Time series of predicted values
    training: npt.NDArray
        Time series of training values
    step: int
        shifting window size to create naive benchmark

    Returns
    -------
    float
        The value of the ratio described above
    """

    # Naive in-sample Forecast (shift by step size)
    naive_actual = training[:-step]
    naive_prediction = training[step:]

    # Calculate MAE (in sample)
    mae_in_sample = np.mean(np.ma.masked_invalid(np.abs(naive_actual - naive_prediction)))
    mae = np.mean(np.ma.masked_invalid(np.abs(actual - prediction)))
    return mae / mae_in_sample


def get_metric(name: str) -> Callable[..., float]:
    if name in _METRIC_REGISTRY:
        return _METRIC_REGISTRY[name]
    try:
        return metrics.get_scorer(name)._score_func
    except ValueError:
        raise ValueError("Invalid name. Choose a UFF metric or a sklearn scorer name")
