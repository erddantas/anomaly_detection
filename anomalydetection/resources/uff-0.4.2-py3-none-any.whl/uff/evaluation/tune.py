#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

import itertools
import uuid
from abc import ABC
from dataclasses import dataclass
from functools import partial
from typing import (
    Any,
    Callable,
    Dict,
    Hashable,
    List,
    Optional,
    Set,
    Tuple,
    Type,
    Union,
)

import numpy as np
import numpy.typing as npt
from scipy.stats import rv_continuous, rv_discrete

from ..base import Estimator, InitializationSpec
from ..distributed import conditional_distributed_evaluate, conditional_reference
from ..tstypes import TimeIndexedData
from ..utils import temporal_split
from .backtest import BackTester, BacktestResult


def default_tuning_backester(
    data: TimeIndexedData,
    covariates: Optional[TimeIndexedData],
    default_test_ratio: float = 0.2,
) -> BackTester:
    train, test = temporal_split(data, 1 - default_test_ratio)
    kwargs = dict(
        step_size=max(test.shape[0], 1),
        step_mode="samples",
        min_fit_window_size=train.shape[0],
        right_align=True,
    )
    return BackTester(data, covariates, **kwargs)


class Parameter(ABC):
    pass


class Choice(Parameter):
    def __init__(self, *args: Any) -> None:
        self.args = args

    def __repr__(self) -> str:
        return f"Choice{self.args}"

    def sample(self) -> Any:
        return np.random.choice(self.args)


class Distribution(Parameter):
    def __init__(self, dist: Union[rv_discrete, rv_continuous]) -> None:
        self.dist = dist

    def sample(self) -> Any:
        return self.dist.rvs()


class Ref:
    def __init__(self, key: Hashable) -> None:
        self.key = key


def recursive_search(obj: Any, sub_class: Union[Type, Tuple[Type, ...]]) -> Set:
    """Recursively the members of `obj` and returns the set of objects found matching sub_class

    Parameters
    ----------
    obj: Any
        The object to explore
    sub_class: Union[Type, Tuple[Type, ...]]
        The object type(s) to return

    Returns
    -------
    Set
        A set of objects that are all instances of `sub_class`. InitializationSpecs, Choice
        objects, dictionaries, tuples, lists and sets are all recursively explored; any other
        objects or iterables are not explored (e.g. np.array, pd.DataFrame)
    """
    res = {obj} if isinstance(obj, sub_class) else set()

    if isinstance(obj, InitializationSpec):
        res |= recursive_search(obj.to_dict(), sub_class)
    elif isinstance(obj, dict):
        for kv in obj.items():
            res |= recursive_search(kv, sub_class)
    elif isinstance(obj, Choice):
        for arg in obj.args:
            res |= recursive_search(arg, sub_class)
    elif isinstance(obj, (list, set, tuple)):
        for v in obj:
            res |= recursive_search(v, sub_class)

    return res


@dataclass
class TunerOutput:
    best: Estimator
    trials: List[Dict]


class Tuner:
    def __init__(
        self,
        data: Optional[TimeIndexedData] = None,
        covariates: Optional[TimeIndexedData] = None,
        **kwargs: Any,
    ) -> None:
        """Initialize a Tuner

        Parameters
        ----------
        data : Optional[TimeIndexedData], optional
            The data that will be used for fitting and transforming/forecasting, by default None
        covariates : Optional[TimeIndexedData], optional
            Optional covariates that can be used for fitting and transforming/forecasting, by
            default None
        kwargs: Any
            Passed directly to :class:`BackTester <uff.evaluation.backtest.BackTester>`
        """
        self.data = data
        self.covariates = covariates
        if len(kwargs) == 0:
            self.backtester = default_tuning_backester(data, covariates)
        else:
            self.backtester = BackTester(data, covariates, **kwargs)

    def run(
        self,
        loss: Union[str, Callable[[BacktestResult], float]],
        models: List[InitializationSpec],
        parameters: Dict[Hashable, Parameter],
        reduce: Callable[["npt.NDArray"], float] = np.mean,
        **kwargs: Any,
    ) -> TunerOutput:
        """Evaluate a set of models according to loss function

        Parameters
        ----------
        loss: Union[str, Callable[[BacktestResult], float]]
            A loss function that will be called on a single backtest result.
            See BackTester.score_results
        models: List[InitializationSpec]
            A list of model search spaces. Should contain only literal values or instances of `Ref`
        parameters: Dict[Hashable, Parameter]
            A set of values for searchable parameters.
        reduce: Callable[["npt.NDArray"], float]
            A function that will be called to combine a list of losses generated by the
            backtester to a single float, by default `np.mean`
        **kwargs: Any
            Passed directly to BackTester.generate_tasks()

        Returns
        -------
        TunerOutput
            The best model and the full set of trials
        """
        specs = self.generate_specs(models, parameters)
        tasks = self.generate_tasks(
            loss,
            specs,
            reduce=reduce,
            **kwargs,
        )
        trials = conditional_distributed_evaluate(tasks)
        return self.process_task_results(trials)

    def generate_specs(
        self,
        models: List[InitializationSpec],
        parameters: Dict[Hashable, Parameter],
        **kwargs: Any,
    ) -> List[InitializationSpec]:
        raise NotImplementedError()

    def generate_tasks(
        self,
        loss: Union[str, Callable[[BacktestResult], float]],
        specs: List[InitializationSpec],
        reduce: Callable[["npt.NDArray"], float] = np.mean,
        **kwargs: Any,
    ) -> List[partial]:
        """Generate a list of tasks to generate model evaluation results

        Parameters
        ----------
        loss: Union[str, Callable[[BacktestResult], float]]
            A loss function that will be called on a single backtest result.
            See BackTester.score_results()
        specs: List[InitializationSpec]
            A list of resolved initialization specs. This should contain no Parameter or Ref
            instances.
        reduce: Callable[["npt.NDArray"], float]
            A function that will be called to combine a list of losses generated by the backtester
            to a single float, by default `np.mean`
        **kwargs: Any
            Passed directly to BackTester.generate_tasks()

        Returns
        -------
        List[partial]
            A set of tasks that can be used to generate results.
        """
        kwargs["data_ref"] = conditional_reference(self.data)
        kwargs["cov_ref"] = conditional_reference(self.covariates)

        task_grid = [self.backtester.generate_tasks(spec, **kwargs) for spec in specs]
        all_backtester_futures = conditional_distributed_evaluate(
            task_grid,
            wait_for_all=False,
        )
        return [
            partial(
                self._evaluate_one,
                loss,
                spec,
                reduce,
                *backtest_evals,
            )
            for spec, backtest_evals in zip(specs, all_backtester_futures)
        ]

    @staticmethod
    def process_task_results(trials: List[Dict]) -> TunerOutput:
        """Process the results of Tuner.generate_tasks

        Parameters
        ----------
        trials: List[Dict]
            The results of Tuner.generate_tasks()

        Returns
        -------
        TunerOutput
            The (unfitted) best estimator and list of trial results
        """
        trials = sorted(trials, key=lambda x: x["loss"])
        return TunerOutput(
            trials[0]["spec"].create_instance(),
            trials,
        )

    @staticmethod
    def _evaluate_one(
        loss: Union[str, Callable[[BacktestResult], float]],
        spec: InitializationSpec,
        reduce: Callable[["npt.NDArray"], float],
        *backtest_results: BacktestResult,
    ) -> Union[List[BacktestResult], Exception]:
        results = []
        for res in backtest_results:
            if isinstance(res, Exception):
                return {
                    "loss": np.inf,
                    "success": False,
                    "spec": spec,
                    "error_message": f"{type(res).__name__}: {res}",
                }
            results.append(res)

        return {
            "loss": reduce(BackTester.score_results(results, loss)),
            "success": True,
            "spec": spec,
        }

    @staticmethod
    def _validate_no_parameters(obj: Any):
        if len(recursive_search(obj, Parameter)) > 0:
            raise ValueError("Expecting should only contain references (Ref), not Parameters")


class RandomSearchTuner(Tuner):
    """Model selection with random parameter search"""

    def generate_specs(
        self,
        models: List[InitializationSpec],
        parameters: Dict[Hashable, Parameter],
        n_trials: int = 100,
    ) -> List[InitializationSpec]:
        self._validate_no_parameters(models)
        top_id = None
        while top_id in parameters:
            top_id = str(uuid.uuid4())

        parameters[top_id] = Choice(*models)
        return [self._sample(Ref(top_id), parameters) for _ in range(n_trials)]

    def run(
        self,
        loss: Union[str, Callable[[BacktestResult], float]],
        models: List[InitializationSpec],
        parameters: Dict[Hashable, Parameter],
        reduce: Callable[["npt.NDArray"], float] = np.mean,
        n_trials: int = 100,
        **kwargs: Any,
    ) -> TunerOutput:
        """Evaluate a set of models according to loss function

        Parameters
        ----------
        loss: Union[str, Callable[[BacktestResult], float]]
            A loss function that will be called on a single backtest result.
            See BackTester.score_results()
        models: List[InitializationSpec]
            A list of model search spaces. Should contain only literal values or instances of `Ref`
        parameters: Dict[Hashable, Parameter]
            A set of values for searchable parameters.
        reduce: Callable[["npt.NDArray"], float]
            A function that will be called to combine a list of losses generated by the backtester
            to a single float, by default `np.mean`
        n_trials: int, default 100
            The number of random model parameterizations that will be sampled.
        **kwargs: Any
            Passed directly to BackTester.generate_tasks()

        Returns
        -------
        TunerOutput
            The best model and the full set of trials
        """
        specs = self.generate_specs(models, parameters, n_trials=n_trials)
        tasks = self.generate_tasks(
            loss,
            specs,
            reduce=reduce,
            **kwargs,
        )
        trials = conditional_distributed_evaluate(tasks)
        return self.process_task_results(trials)

    @classmethod
    def _sample(cls, arg, parameters: Dict[Hashable, Parameter]):
        if isinstance(arg, Ref):
            return cls._sample(parameters[arg.key].sample(), parameters)
        elif isinstance(arg, Parameter):
            return cls._sample(arg.sample(), parameters)
        elif isinstance(arg, InitializationSpec):
            return InitializationSpec.from_dict(cls._sample(arg.to_dict(), parameters))
        elif isinstance(arg, dict):
            return {cls._sample(k, parameters): cls._sample(v, parameters) for k, v in arg.items()}
        elif isinstance(arg, (list, tuple, set)):
            res = [cls._sample(v, parameters) for v in arg]
            return type(arg)(res)

        return arg


class GridSearchTuner(Tuner):
    """Model selection with grid search"""

    def generate_specs(
        self,
        models: List[InitializationSpec],
        parameters: Dict[Hashable, Parameter],
    ) -> List[InitializationSpec]:
        self._validate_no_parameters(models)

        all_params = recursive_search(parameters, Parameter)
        top_level = set(parameters.values())
        if any(not isinstance(p, Choice) for p in all_params):
            raise ValueError("Distribution parameters found. Cannot perform exhaustive search.")
        if any(p not in top_level for p in all_params):
            raise ValueError("Grid search parameters cannot be nested")

        specs = []
        for model in models:
            refs = list(recursive_search(model, Ref))
            param_keys = [r.key for r in refs]
            space = list(itertools.product(*[parameters[k].args for k in param_keys]))
            for point in space:
                assignments = dict(zip(param_keys, point))
                specs.append(self._resolve(model, assignments))
        return specs

    @classmethod
    def _resolve(cls, obj: Any, assignments: Dict[Hashable, Any]) -> Any:
        if isinstance(obj, Ref):
            return assignments[obj.key]
        elif isinstance(obj, InitializationSpec):
            return InitializationSpec.from_dict(cls._resolve(obj.to_dict(), assignments))
        elif isinstance(obj, dict):
            return {
                cls._resolve(k, assignments): cls._resolve(v, assignments) for k, v in obj.items()
            }
        elif isinstance(obj, (list, tuple, set)):
            res = [cls._resolve(v, assignments) for v in obj]
            return type(obj)(res)

        return obj
