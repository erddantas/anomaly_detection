#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

from typing import Any, List, Optional

from ..base import FeatureSelector, decorators
from ..tstypes import ColumnSet, TimeIndexedData, TimeIndexedOutput


class ColumnsAsStringsSelector(FeatureSelector):
    """A FeatureSelector that reduces hierarchy levels in column names.

    This is useful for forecasting procedures (e.g. ProphetForecaster and FormulaForecaster)
    which require a flat index of strings as covariate column names.
    """

    @decorators.set_init_attributes(requires_fit=False)
    def __init__(self, separator: str = " ") -> None:
        """Initialize a ColumnsAsStringsSelector."""
        self.separator = separator

    @decorators.check_state_and_input
    def transform_covariates(self, data: TimeIndexedData) -> TimeIndexedOutput:
        """Create a new TimeIndexedData with column names as strings.

        Parameters
        ----------
        data: TimeIndexedData
            The covariates to be filtered.

        Returns
        -------
        TimeIndexedOutput
            A result object with the transformed covariates in the .out attribute.
        """
        return TimeIndexedOutput(
            data.set_column_index_to_strings(separator=self.separator, in_place=False)
        )
