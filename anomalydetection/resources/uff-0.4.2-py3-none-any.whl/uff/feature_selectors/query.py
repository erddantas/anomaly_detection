#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

from typing import Any, List, Optional

from ..base import FeatureSelector, decorators
from ..tstypes import ColumnSet, TimeIndexedData, TimeIndexedOutput


class QuerySelector(FeatureSelector):
    """A FeatureSelector that uses a query string to subselect covariate columns.

    During `fit()`, the query string is used to select columns from the covariates. The selected
    columns are then used to filter the covariates during `transform_covariates()`.
    """

    @decorators.set_init_attributes(requires_covariates=True)
    def __init__(self, query_str: str) -> None:
        """Initialize a QuerySelector.

        See the documentatino of TimeIndexedData.query_columns for more information.

        Parameters
        ----------
        query_str: str
            A query string that will be used to select columns from the covariates.
        """
        self._query_str = query_str
        self._selected_columns: Optional[ColumnSet] = None

    @decorators.update_fit_attributes
    def fit(
        self, data: TimeIndexedData, covariates: TimeIndexedData, **kwargs: Any
    ) -> QuerySelector:
        """Select columns from the covariates using the query string.

        Parameters
        ----------
        data: TimeIndexedData
            The observations. Not used, but required by the base class.
        covariates: TimeIndexedData
            The covariates to be filtered. Note that the type is refined from
            Optional[TimeIndexedData] to TimeIndexedData since `requires_covariates` is set to
            True in the decorator.
        kwargs: Any
            Additional keyword arguments. Not used.

        Returns
        -------
        QuerySelector
            A reference to `self` for method chaining.
        """
        self._selected_columns = covariates.get_matching_columns(query=self._query_str)
        return self

    @decorators.check_state_and_input
    def transform_covariates(self, data: TimeIndexedData) -> TimeIndexedOutput:
        """Filter the covariates using the previously selected columns.

        Parameters
        ----------
        data: TimeIndexedData
            The covariates to be filtered.

        Returns
        -------
        TimeIndexedOutput
            A result object with the filtered covariates in the .out attribute.
        """
        return TimeIndexedOutput(data.select(self._selected_columns))
