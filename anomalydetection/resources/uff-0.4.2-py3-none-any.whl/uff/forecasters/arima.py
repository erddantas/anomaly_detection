#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Tuple, Union

import numpy as np
import pandas as pd
from scipy.stats import norm
from statsmodels.tsa.arima.model import ARIMA, ARIMAResultsWrapper

from .. import logger, utils
from ..base import ForecasterWithInterval, decorators
from ..tstypes import TimeIndex, TimeIndexedData, TimeIndexedOutputWithInterval


@dataclass
class ArimaOutput(TimeIndexedOutputWithInterval):
    """Output for ARIMA models

    Attributes
    ----------
    out: TimeIndexedData
        Forecasted point estimates
    upper: TimeIndexedData
        The upper bound of the forecast prediction interval
    lower: TimeIndexedData
        The lower bound of the forecast prediction interval
    interval_width: float
        The width of the prediction interval
    std_dev: TimeIndexedData
        Standard deviation of the point estimates
    aic: float
        Akaike information criterion
    aicc: float
        Akaike information criterion with correction for finite sample sizes
    bic: float
        Bayes information criterion
    hqic: float
        Hannan-Quinn information criterion
    llf: float
        The value of the log-likelihood function evaluated at the fitted parameters
    mae: float
        Mean absolute error over the fit data
    mse: float
        Mean squared error over the fit data
    sse: float
        Sum of squared errors over the fit data
    """

    out: TimeIndexedData
    upper: TimeIndexedData
    lower: TimeIndexedData
    interval_width: float
    std_dev: TimeIndexedData
    aic: float
    aicc: float
    bic: float
    hqic: float
    llf: float
    mae: float
    mse: float
    sse: float


class ArimaForecaster(ForecasterWithInterval):
    """Autoregressive Integrated Moving Average (ARIMA) model, and extensions

    This model is the basic interface for ARIMA-type models, including those with exogenous
    regressors and those with seasonal components. The most general form of the model is
    SARIMAX(p, d, q)x(P, D, Q, s), which incorporates both seasonal and non-seasonal factors
    in a multiplicative model.

    Attributes
    ----------
    fit_results: Optional[ARIMAResultsWrapper]
        If fitted, this attribute will contain the statsmodels results wrapper.
    """

    @decorators.set_init_attributes(ray_serializable=False)
    def __init__(
        self,
        ar_order: Union[int, List[int]] = 1,
        integration_order: int = 0,
        ma_order: Union[int, List[int]] = 0,
        seasonal_ar_order: Union[int, List[int]] = 0,
        seasonal_integration_order: int = 0,
        seasonal_ma_order: Union[int, List[int]] = 0,
        periodicity: int = 0,
        trend: Optional[List[int]] = None,
        enforce_stationarity: bool = True,
        enforce_invertibility: bool = True,
        prediction_interval_width: float = 0.95,
    ) -> None:
        """Instantiate a new ARIMA model

        Parameters
        ----------
        ar_order: Union[int, List[int]], default 1
            The autoregressive order of the model. May be an integer, in which case all
            autoregressive lags up to and including it will be included. For example, if
            `ar_order = 3`, then the model will include lags 1, 2, and 3. Alternatively, may be a
            list of integers specifying exactly which lag orders are included. For example, if
            `ar_order = [1, 3]`, then the model will include lags 1 and 3 but will exclude lag 2.
        integration_order: int, default 0
            The order of integration of the model.
        ma_order: Union[int, List[int]], default 0
            The moving average order of the model. May be an integer or list of integers.
            See the documentation for `ar_order` for details.
        seasonal_ar_order: Union[int, List[int]], default 0
            The seasonal autoregressive order of the model. May be an integer or list of integers.
            See the documentation for `ar_order` for examples. Note that if `periodicity = 4` and
            `seasonal_ar_order = 2`, then this implies that the overall model will include lags 4
            and 8.
        seasonal_integration_order: int, default 0
            The order of seasonal integration of the model.
        seasonal_ma_order: Union[int, List[int]], default 0
            The moving average order of the model. May be an integer or list of integers.
            See the documentation for `ar_order` and `seasonal_ar_order` for additional details.
        periodicity: int, default 0
            The number of periods in a season.
        trend: Optional[List[int]], default None
            An iterable defining a numpy.poly1d polynomial (lowest order first).
        enforce_stationarity: bool, default True
            Whether or not to require the autoregressive parameters to correspond to a
            stationarity process.
        enforce_invertibility: bool, default True
            Whether or not to require the moving average parameters to correspond to an
            invertible process.
        prediction_interval_width: float, default 0.95
            The width of the output prediction interval [0, 1]
        """
        self.init_kwargs = {
            "order": (ar_order, integration_order, ma_order),
            "seasonal_order": (
                seasonal_ar_order,
                seasonal_integration_order,
                seasonal_ma_order,
                periodicity,
            ),
            "trend": trend,
            "enforce_stationarity": enforce_stationarity,
            "enforce_invertibility": enforce_invertibility,
        }

        self.fit_results: Optional[ARIMAResultsWrapper] = None
        self.fit_data: Optional[TimeIndexedData] = None
        self.fit_covariates: Optional[TimeIndexedData] = None
        self.prediction_interval_width = prediction_interval_width

    @decorators.update_fit_attributes
    def fit(
        self,
        data: TimeIndexedData,
        covariates: Optional[TimeIndexedData] = None,
        **kwargs,
    ) -> ArimaForecaster:
        """Fit the ARIMA model parameters

        Note that ARIMA requires dense data. Both inputs will be made dense with np.nan populating
        missing time stamps. ARIMA can handle NaN values in `data` but will throw an error if any
        are found in `covariates`.

        Parameters
        ----------
        data: TimeIndexedData
            The endogenous variables; will be used to popualte autoregressive and lagged features.
        covariates: Optional[TimeIndexedData] = None
            If provided, these will be treated as OLS regressors for predicting the endogenous
            variables.
        kwargs: Dict[str, Any]
            Will be passed directly to statsmodels.tsa.arima.model.ARIMA.fit

        Returns
        -------
        ArimaForecaster
            self, for method chaining
        """
        data = utils.make_dense(data)

        if covariates is not None:
            dense = utils.make_dense(covariates)
            if dense != covariates:
                raise ValueError("ARIMA models require dense covariates")
            if data.time_index != dense.time_index:
                raise ValueError("Data and covariate time indices must be the same")
            covariates = dense

        endog = data.values
        exog = None if covariates is None else covariates.values
        model = ARIMA(endog, exog, **self.init_kwargs)

        self.fit_results = model.fit(**kwargs)
        self.fit_data = data
        self.fit_covariates = covariates
        return self

    @decorators.check_state_and_input
    def forecast(
        self,
        data: Union[TimeIndex, TimeIndexedData],
        **kwargs,
    ) -> ArimaOutput:
        """Forecast the fit time series into the future

        Parameters
        ----------
        data: Union[TimeIndex, TimeIndexedData]
            The domain of the forecast time series, with covariates if applicable.

        Returns
        -------
        ArimaOutput
            The output of the forecast. If the time scale of `data` does not match that of the fit
            data, NaNs will populate at the invalid timestamps. This will happen, for example, if
            the model was fit on data with business day granularity and one of the target
            timestamps is not a business day.

        Raises
        ------
        ValueError
            If any entry in `data` occurs before the start of the fit data.
        """
        if data.starts_before(self.fit_data):
            raise ValueError("ARIMA model cannot forecast into the past of the fit data")

        index = data if isinstance(data, TimeIndex) else data.time_index
        cov = data if isinstance(data, TimeIndexedData) else None

        mean, std_dev = self._dense_forecast(
            index.timestamp_values[0],
            index.timestamp_values[-1],
            cov,
        )

        dist = norm(mean, std_dev)
        lower_bound = dist.ppf(0.5 - (self.prediction_interval_width / 2))
        upper_bound = dist.ppf(0.5 + (self.prediction_interval_width / 2))
        lower, upper = [
            TimeIndexedData.from_time_index(mean.time_index, bound, column_names=mean.column_names)
            for bound in (lower_bound, upper_bound)
        ]

        return ArimaOutput(
            out=utils.interpolate(index, mean, interp="nan"),
            upper=utils.interpolate(index, upper, interp="nan"),
            lower=utils.interpolate(index, lower, interp="nan"),
            interval_width=self.prediction_interval_width,
            std_dev=utils.interpolate(index, std_dev, interp="nan"),
            aic=self.fit_results.aic,
            aicc=self.fit_results.aicc,
            bic=self.fit_results.bic,
            hqic=self.fit_results.hqic,
            llf=self.fit_results.llf,
            mae=self.fit_results.mae,
            mse=self.fit_results.mse,
            sse=self.fit_results.sse,
        )

    def _dense_forecast(
        self,
        min_t: pd.Timestamp,
        max_t: pd.Timestamp,
        sparse_cov: Optional[TimeIndexedData],
    ) -> Tuple[TimeIndexedData, TimeIndexedData]:
        haystack = self.fit_data.pd_timestamp_index()
        if max_t > haystack[-1]:
            future = pd.date_range(
                haystack[-1],
                max_t,
                freq=self.fit_data.granularity,
            )
            haystack += list(future)[1:]

        i_start = np.searchsorted(haystack, min_t)
        i_end = np.searchsorted(haystack, max_t)

        n_steps = max(i_end - len(self.fit_data) + 1, 0)
        n_steps_past = max(len(self.fit_data) - i_start, 0)

        exog = None
        if self.fit_covariates is not None and sparse_cov is not None:
            if sparse_cov.column_names != self.fit_covariates.column_names:
                raise ValueError("Covariate column names do not match those from the fitted data")
            if not self.fit_data.strictly_before(sparse_cov):
                logger.raise_warning(
                    "ARIMA model does not support overwriting already-fitted exogenous "
                    "regressors. Overlapping values will be ignored."
                )
            dense_future = self.fit_data.future_time_index(n_steps)
            exog = utils.interpolate(dense_future, sparse_cov).values

        pred = self.fit_results.get_prediction(
            i_start,
            i_end,
            exog=exog,
            dynamic=i_start if n_steps_past > 0 else False,
        )

        n_skipped = max(i_start - len(self.fit_data), 0)
        index = self.fit_data.future_time_index(n_steps, n_steps_past).slice(n_skipped)
        cols = self.fit_data.column_names
        return (
            TimeIndexedData.from_time_index(index, pred.predicted_mean, cols),
            TimeIndexedData.from_time_index(index, pred.se_mean, cols),
        )
