#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Protocol, Tuple, Type, Union

import numpy as np
import pandas as pd
from scipy.stats import norm

from .. import utils
from ..base import ForecasterWithInterval, decorators
from ..tstypes import (
    ColumnPath,
    TimeIndex,
    TimeIndexedData,
    TimeIndexedOutputWithInterval,
)


class _SmPrediction(Protocol):
    predicted_mean: np.ndarray
    se_mean: np.ndarray


class _SmRegressionResults(Protocol):
    def get_prediction(self, exog, **kwargs) -> _SmPrediction: ...


@dataclass
class FormulaForecasterOutput(TimeIndexedOutputWithInterval):
    out: TimeIndexedData
    upper: TimeIndexedData
    lower: TimeIndexedData
    interval_width: float
    std_dev: TimeIndexedData


class FormulaForecaster(ForecasterWithInterval):
    """A forecaster that uses a formula to fit a linear regression model to the data.

    The forecaster is specified using R-style formulas. Internally, UFF references statsmodels'
    OLS abstraction and uses the [patsy package](https://patsy.readthedocs.io/en/latest/) to
    convert formulas and data to the matrices that are used in model fitting.

    When specifying formulas, the default regressors from `uff.utils.time_based_regressors` will
    automatically be available to use. If custom covariates are provided, those will take
    precedence over the default regressors when there is a name conflict.
    """

    @decorators.set_init_attributes(ray_serializable=False)
    def __init__(
        self,
        formula: str,
        time_regressor: str = "t",
        prediction_interval_width: float = 0.95,
    ) -> None:
        """Initializes the FormulaForecaster.

        Parameters
        ----------
        formula
            A string specifying the formula to use for the regression. The formula should be in
            the form of "target ~ regressor1 + regressor2 + ...". The target and regressors
            should be column names in the data or one of the default regressors from
            `uff.utils.time_based_regressors`.
        time_regressor
            The name of the time regressor. This is the regressor that will be used as the
            time index in the formula. The default is "t".
        prediction_interval_width
            The width of the prediction interval. The default is 0.95, which corresponds to a
            95% prediction interval.
        """
        from statsmodels.formula.api import ols

        self._formula = formula
        self._target_name = formula.split("~")[0].strip()
        self._time_regressor = time_regressor
        if self._time_regressor == self._target_name:
            raise ValueError("Time regressor and target name must be different")

        if "Intercept" in (self._target_name, self._time_regressor):
            raise ValueError("User-provided values cannot be named 'Intercept'")

        self._ols_constructor = ols
        self._fit_cols: List[ColumnPath] = []
        self._high_dim_shape: Tuple[int] = ()
        self._models: Dict[ColumnPath, _SmRegressionResults] = {}
        self.prediction_interval_width = prediction_interval_width

    @decorators.update_fit_attributes
    def fit(
        self,
        data: TimeIndexedData,
        covariates: Optional[TimeIndexedData] = None,
        **kwargs,
    ) -> FormulaForecaster:
        self._high_dim_shape = data.shape[1:]
        covariates = self._get_covariates(covariates or data.time_index)

        cols = set(covariates.column_names)
        if not covariates.same_scale(data):
            raise ValueError("Data and covariates must have the same time scale")
        if self._target_name in cols:
            raise ValueError("Name conflict between covariates and target name")
        if "Intercept" in cols:
            raise ValueError("User-provided values cannot be named 'Intercept'")

        for col in data.column_tuples:
            self._fit_cols.append(col)
            design_matrix = self._get_univariate_design_matrix(data[[col]], covariates)
            self._models[col] = self._ols_constructor(self._formula, design_matrix).fit(**kwargs)

        return self

    @decorators.check_state_and_input
    def forecast(
        self,
        data: Union[TimeIndex, TimeIndexedData],
        **kwargs,
    ) -> FormulaForecasterOutput:
        index = data if isinstance(data, TimeIndex) else data.time_index
        cov = self._get_covariates(data if self.was_fit_with_covariates else index)
        exog = self._get_univariate_design_matrix(index, cov)

        means, se_means = self._raw_predictions(exog)
        dist = norm(means, se_means)
        lowers = dist.ppf(0.5 - (self.prediction_interval_width / 2))
        uppers = dist.ppf(0.5 + (self.prediction_interval_width / 2))

        return FormulaForecasterOutput(
            out=self._get_result(index, means),
            upper=self._get_result(index, uppers),
            lower=self._get_result(index, lowers),
            interval_width=self.prediction_interval_width,
            std_dev=self._get_result(index, se_means),
        )

    def _raw_predictions(self, exog: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        n = len(exog)

        # Initialize empty result containers
        mean_res = np.empty((n, len(self._fit_cols)), dtype=float)
        se_mean_res = np.empty((n, len(self._fit_cols)), dtype=float)

        # Get predictions for each column
        for j, col in enumerate(self._fit_cols):
            prediction = self._models[col].get_prediction(exog)
            if len(prediction.predicted_mean) != n:
                raise ValueError(
                    "Prediction length does not match input length. This can happen if the "
                    "formula specified generates invalid values in the design matrix. E.g. if a "
                    "negative value is raised to a fractional exponent, resulting in a complex "
                    "number."
                )
            mean_res[:, j] = prediction.predicted_mean
            se_mean_res[:, j] = prediction.se_mean

        return mean_res, se_mean_res

    def _get_result(self, index: TimeIndex, data: np.ndarray) -> TimeIndexedData:
        out_shape = (len(index),) + self._high_dim_shape
        return TimeIndexedData.from_time_index(index, data, column_names=self._fit_cols).reshape(
            out_shape
        )

    def _get_covariates(self, data: Union[TimeIndexedData, TimeIndex]) -> TimeIndexedData:
        defaults = utils.time_based_regressors(data, self._time_regressor)

        if isinstance(data, TimeIndexedData):
            user_cols = set(data.column_names)
            select_cols = [col for col in defaults.column_names if col not in user_cols]
            if len(select_cols) > 0:
                return utils.hstack([data, defaults[select_cols]])
            else:
                # The user-provided covariates completely override the default ones
                return data

        return defaults

    def _get_univariate_design_matrix(
        self,
        data: Union[TimeIndexedData, TimeIndex],
        covariates: TimeIndexedData,
    ) -> pd.DataFrame:
        df = covariates.to_pandas(
            time_col=None
        )  # Put time column in the index since we already have a time regressor
        if isinstance(data, TimeIndexedData):
            df[self._target_name] = data.values.flatten()
        return df
