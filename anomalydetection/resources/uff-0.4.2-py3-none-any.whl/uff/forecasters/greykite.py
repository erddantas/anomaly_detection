#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

import logging
import os
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd

try:
    from greykite.algo.forecast.silverkite.constants.silverkite_column import (
        SilverkiteColumn,
    )
    from greykite.framework.templates.autogen.forecast_config import (
        ComputationParam,
        EvaluationPeriodParam,
        ForecastConfig,
        MetadataParam,
        ModelComponentsParam,
    )
    from greykite.framework.templates.forecaster import Forecaster as GKForecaster

    greykite_installed = True
except ModuleNotFoundError:
    greykite_installed = False


from sklearn.pipeline import Pipeline

from .. import utils
from .._dill import dump, load
from ..base import ForecasterWithInterval, decorators
from ..tstypes import TimeIndex, TimeIndexedData, TimeIndexedOutputWithInterval

logger = logging.getLogger(__name__)


@dataclass
class GreykiteOutput(TimeIndexedOutputWithInterval):
    """Output for Greykite models

    Attributes
    ----------
    out: TimeIndexedData
        Forecasted point estimates
    upper: TimeIndexedData
        The upper bound of the forecast prediction interval
    lower: TimeIndexedData
        The lower bound of the forecast prediction interval
    interval_width: float
        The width of the prediction interval
    """

    out: TimeIndexedData
    upper: TimeIndexedData
    lower: TimeIndexedData
    interval_width: float


class GreykiteForecaster(ForecasterWithInterval):
    """Greykite Forecaster

    Attributes
    ----------
    model: Optional[Pipeline]
        If a GreykiteForecaster instance has been fitted, the attribute obj.model will contain the
        forecasting procedure as a scikit learn Pipeline
    """

    __version__ = "0.4.0"  # greykite version to use
    __doc_base_url = f"https://linkedin.github.io/greykite/docs/{__version__}/html/pages"
    __doc_sections = {
        "growth": "model_components/0200_growth.html",
        "seasonality": "model_components/0300_seasonality.html",
        "events": "model_components/0400_events.html",
        "changepoints": "model_components/0500_changepoints.html",
        "custom": "model_components/0600_custom.html",
        "regressors": "model_components/0700_regressors.html",
        "autoregression": "model_components/0800_autoregression.html",
        "uncertainty": "model_components/0900_uncertainty.html",
    }

    @decorators.set_init_attributes(ray_serializable=False, joblib_serializable=False)
    def __init__(
        self,
        # model template
        model_template: str = "SILVERKITE",
        # growth
        growth_term: str = "linear",
        # seasonality
        auto_seasonality: bool = False,
        yearly_seasonality: Union[str, bool, int] = "auto",
        quarterly_seasonality: Union[str, bool, int] = "auto",
        monthly_seasonality: Union[str, bool, int] = "auto",
        weekly_seasonality: Union[str, bool, int] = "auto",
        daily_seasonality: Union[str, bool, int] = "auto",
        # holidays & events
        holiday_lookup_countries: Optional[Union[List[str], str]] = "auto",
        holidays_to_model_separately: Optional[Union[List[str], str]] = "auto",
        holiday_pre_num_days: int = 2,
        holiday_post_num_days: int = 2,
        holiday_pre_post_num_dict: Optional[Dict[str, List[int, int]]] = None,
        daily_event_df_dict: Optional[Dict[str, pd.DataFrame]] = None,
        # changepoints
        changepoints: Optional[Dict[str, Dict[str, Any]]] = None,
        # custom paramters
        # # fit algorithm
        fit_algorithm_dict: Optional[Dict[str, Any]] = None,
        # # interactions
        feature_sets_enabled: Union[Dict[str, Optional[Union[str, bool, str]]], bool, str] = False,
        max_daily_seas_interaction_order: Optional[int] = 5,
        max_weekly_seas_interaction_order: Optional[int] = 2,
        # # specify model terms
        extra_pred_cols: Optional[List[str]] = None,
        drop_pred_cols: Optional[List[str]] = None,
        explicit_pred_cols: Optional[List[str]] = None,
        # # forecast limits
        min_admissible_value: Optional[float] = None,
        max_admissible_value: Optional[float] = None,
        # # normalization
        normalize_method: Optional[str] = None,
        # regressors
        regressor_cols: Optional[List[str]] = None,
        lagged_regressor_dict: Optional[Dict[str, Union[Dict[str, Any], str]]] = None,
        # auto-regression
        autoregression: Optional[Dict[str, Any]] = None,
        forecast_one_by_one: Optional[Union[bool, int, List[int]]] = None,
        # uncertainty intervals
        uncertainty_dict: Union[Dict[str, Any], str] = "auto",
        prediction_interval_width: float = 0.95,
    ) -> None:
        """Initialize greykite forecaster

        Parameters
        ----------
        model_template: str
            model template to use
        growth_term : str
            'linear', 'quadratic', 'sqrt'
        auto_seasonality : bool
            If set to True, will trigger automatic seasonality inferring.
            The seasonalies below are ignored unless the value is False to force turn the
            seasonality off
        yearly_seasonality : Union[str, bool, int]
            Determines the yearly seasonality
            'auto', True, False, or a number for the Fourier order
        quarterly_seasonality : Union[str, bool, int]
            Determines the yearly seasonality
            'auto', True, False, or a number for the Fourier order
        monthly_seasonality : Union[str, bool, int]
            Determines the monthly seasonality
            'auto', True, False, or a number for the Fourier order
        weekly_seasonality : Union[str, bool, int]
            Determines the weekly seasonality
            'auto', True, False, or a number for the Fourier order
        daily_seasonality : Union[str, bool, int]
            Determines the daily seasonality
            'auto', True, False, or a number for the Fourier order
        holiday_lookup_countries : Optional[Union[List[str], str]], optional
            The countries that contain the holidays you intend to model
        holidays_to_model_separately : Optional[Union[List[str], str]], optional
            Which holidays to include in the model.
        holiday_pre_num_days : int
            Model holiday effects for pre_num days before the holiday.
            The unit is days, not periods. It does not depend on input data frequency, by default 2
        holiday_post_num_days : int
            model holiday effects for post_num days after the holiday.
            The unit is days, not periods. It does not depend on input data frequency, by default 2
        holiday_pre_post_num_dict : Optional[Dict[str, List[int]]], optional
            Overrides `pre_num` and `post_num` for each holiday in `holidays_to_model_separately`
        daily_event_df_dict : Optional[Dict[str, pd.DataFrame]], optional
            A dictionary of data frames, each representing events data for the corresponding key.
        changepoints : Optional[Dict[str, Dict[str, Any]]], optional
            Specifies the changepoint configuration. Dictionary with the following
        fit_algorithm_dict : Optional[Dict[str, Any]], optional
            How to fit the model, by default None
        feature_sets_enabled : Union[Dict[str, Optional[Union[str, bool, str]]], bool, str]
            Whether to include interaction terms and categorical variables to increase model
            flexibility. by default False
        max_daily_seas_interaction_order : Optional[int], optional
            Max fourier order to use for interactions with daily seasonality, by default 5
        max_weekly_seas_interaction_order : Optional[int], optional
            Max fourier order to use for interactions with weekly seasonality, by default 2
        extra_pred_cols : Optional[List[str]], optional
            Names of extra predictor columns, by default None
        drop_pred_cols : Optional[List[str]], optional
            Names of predictor columns to be dropped from the final model, by default None
        explicit_pred_cols : Optional[List[str]], optional
            Names of the explicit predictor columns which will be the only variables in the final
            model, by default None
        min_admissible_value : Optional[float], optional
            The lowest admissible value for the forecasts and prediction intervals.
            Any value below this will be mapped back to this value, by default None
        max_admissible_value : Optional[float], optional
            The highest admissible value for the forecasts and prediction intervals.
            Any value above this will be mapped back to this value, by default None
        normalize_method : Optional[str], optional
            The normalization method for the feature matrix,
            one of {'statistical' ,'zero_to_one', 'minus_half_to_half'}, by default None
        regressor_cols : Optional[List[str]], optional
        lagged_regressor_dict : Optional[Dict[str, Union[Dict[str, Any], str]]], optional
            lagged regressors specifications, by default None
        autoregression : Optional[Dict[str, Any]], optional
            Autoregression specifications, by default None
        forecast_one_by_one : Optional[Union[bool, int, List[int]]], optional
            Whether to multiple models spanning the horizon and combine their predictions. This
            may improve forecast quality when forecast horizon > 1 and autoregression or lagged
            regressors are used, by default None
        uncertainty_dict : Union[Dict[str, Any], str], default "auto"
            Specifies the uncertainty interval configuration. Use `prediction_interval_width` to
            set interval size and this argument to tune the calculation.
        prediction_interval_width: float, default 0.95
            Intended coverage of the prediction bands (0.0 to 1.0).
            If None, the upper/lower predictions are not returned, by default None
        """
        if not greykite_installed:
            raise ModuleNotFoundError("Greykite module was not found")

        self.prediction_interval_width = prediction_interval_width

        # best effort to capture param errors for nested params
        if growth_term not in {"linear", "quadratic", "sqrt"}:
            raise ValueError(f"Invalid `growth_term`, see {self._doc_url('growth')}")
        if changepoints and (
            changepoints.keys() - {"changepoints_dict", "seasonality_changepoints_dict"}
        ):
            raise ValueError(f"Invalid `changepoints`, see {self._doc_url('changepoints')}")
        if fit_algorithm_dict and (
            fit_algorithm_dict.keys() - {"fit_algorithm", "fit_algorithm_params"}
        ):
            raise ValueError(
                f"Invalid `fit_algorithm_dict`, see {self._doc_url('custom', 'fit-algorithm')}"
            )
        valid_interactions = set(
            [
                getattr(SilverkiteColumn, k)
                for k in vars(SilverkiteColumn).keys()
                if k.startswith("COLS")
            ]
        )
        if (
            feature_sets_enabled is not None
            and isinstance(feature_sets_enabled, dict)
            and (feature_sets_enabled.keys() - valid_interactions)
        ):
            raise ValueError(
                f"Invalid `feature_sets_enabled`, see {self._doc_url('custom', 'interactions')}"
            )
        if normalize_method and normalize_method not in {
            "statistical",
            "zero_to_one" and "minus_half_to_half",
        }:
            raise ValueError(
                f"Invalid `normalize_method`, see {self._doc_url('custom', 'normalization')}"
            )
        if changepoints and (
            changepoints.keys() - {"changepoints_dict", "seasonality_changepoints_dict"}
        ):
            raise ValueError(f"Invalid `changepoints`, see {self._doc_url('changepoints')}")
        if (
            autoregression
            and not autoregression
            and (autoregression.keys() - {"autoreg_dict", "simulation_num"})
        ):
            raise ValueError(f"Invalid `autoregression`, see {self._doc_url('autoregression')}")
        if uncertainty_dict and isinstance(uncertainty_dict, dict):
            if uncertainty_dict.keys() - {"uncertainty_method", "params"}:
                raise ValueError(f"Invalid `uncertainty_dict`, see {self._doc_url('uncertainty')}")
            if uncertainty_dict["uncertainty_method"] not in {"simple_conditional_residuals"}:
                raise ValueError(
                    "Invalid `uncertainty_dict.uncertainty_method`, "
                    f"see {self._doc_url('uncertainty')}"
                )
            if not isinstance(uncertainty_dict["params"], dict) or (
                uncertainty_dict["params"].keys()
                - {
                    "conditional_cols",
                    "quantiles",
                    "quantile_estimation_method",
                    "sample_size_thresh",
                    "small_sample_size_method",
                    "small_sample_size_quantile",
                }
            ):
                raise ValueError(
                    f"Invalid `uncertainty_dict.params`, see {self._doc_url('uncertainty')}"
                )

        # safely handle holiday pre & post days
        if holiday_pre_post_num_dict is not None:
            holiday_pre_post_num_dict = {
                k: (v[0], v[1]) for k, v in holiday_pre_post_num_dict.items() if len(v) > 1
            }
        model_components = ModelComponentsParam(
            growth=dict(growth_term=growth_term),
            seasonality=dict(
                auto_seasonality=auto_seasonality,
                yearly_seasonality=yearly_seasonality,
                quarterly_seasonality=quarterly_seasonality,
                monthly_seasonality=monthly_seasonality,
                weekly_seasonality=weekly_seasonality,
                daily_seasonality=daily_seasonality,
            ),
            events=dict(
                holidays_to_model_separately=holidays_to_model_separately,
                holiday_lookup_countries=holiday_lookup_countries,
                holiday_pre_num_days=holiday_pre_num_days,
                holiday_post_num_days=holiday_post_num_days,
                holiday_pre_post_num_dict=holiday_pre_post_num_dict,
                daily_event_df_dict=daily_event_df_dict,
            ),
            changepoints=changepoints,
            custom=dict(
                fit_algorithm_dict=fit_algorithm_dict,
                feature_sets_enabled=feature_sets_enabled,
                max_daily_seas_interaction_order=max_daily_seas_interaction_order,
                max_weekly_seas_interaction_order=max_weekly_seas_interaction_order,
                extra_pred_cols=extra_pred_cols,
                drop_pred_cols=drop_pred_cols,
                explicit_pred_cols=explicit_pred_cols,
                min_admissible_value=min_admissible_value,
                max_admissible_value=max_admissible_value,
                normalize_method=normalize_method,
            ),
            regressors=dict(regressor_cols=regressor_cols) if regressor_cols else None,
            lagged_regressors=dict(lagged_regressor_dict=lagged_regressor_dict),
            autoregression=autoregression,
            uncertainty=dict(uncertainty_dict=uncertainty_dict),
        )
        evaluation_period = EvaluationPeriodParam(
            test_horizon=0,  # skip backtest
            cv_horizon=0,  # skip cv
        )
        self.config = ForecastConfig(
            model_template=model_template,
            coverage=prediction_interval_width,
            evaluation_period_param=evaluation_period,
            model_components_param=model_components,
            computation_param=ComputationParam(n_jobs=1),
            forecast_horizon=1,
            forecast_one_by_one=forecast_one_by_one,
        )
        self.fit_data: Optional[TimeIndexedData] = None
        self.fit_covariates: Optional[TimeIndexedData] = None
        self.model: Optional[Pipeline] = None

    @decorators.update_fit_attributes
    def fit(
        self,
        data: TimeIndexedData,
        covariates: Optional[TimeIndexedData] = None,
        suppress_warning: bool = True,
        **kwargs,
    ) -> GreykiteForecaster:
        """Fit the Greykite model to the input time series.

        Parameters
        ----------
        data: TimeIndexedData
            The time series to be modeled. Expected to have values.ndim == 1.
        covariates: Optional[TimeIndexedData], default None
            If applicable, the extra regressors that should be registered with the Greykite model.
        suppress_warning: bool, default True
            whether to suppress warning emitted from underlying model
        kwargs: Dict[str, Any]
            Ignored

        Returns
        -------
        GreykiteForecaster
            self
        """
        if not utils.is_univariate(data):
            raise ValueError("Only univariate `data` is allowed")
        self.fit_data = data
        self.fit_covariates = covariates

        col_specs = {"time_col": "ts", "value_col": "y"}
        dummy_horizon = self.config.forecast_horizon
        self.config.metadata_param = MetadataParam(**col_specs, freq=data.granularity)
        # hack to separate fit & forecast; model requires future data during `run_forecast_config`
        future_time_index = data.future_time_index(dummy_horizon)
        data = data.set_column_names("y")
        data_ext = utils.concatenate(
            [
                data,
                TimeIndexedData.from_time_index(
                    future_time_index,
                    values=np.full((dummy_horizon, *data.shape[1:]), np.nan),
                    column_names=data.column_names,
                ),
            ]
        )
        covariates_ext = (
            utils.concatenate(
                [
                    covariates,
                    TimeIndexedData.from_time_index(
                        future_time_index,
                        values=np.ones((1, *covariates.shape[1:])),
                        column_names=covariates.column_names,
                    ),
                ]
            )
            if covariates
            else None
        )
        # suppress warnings caused by skipping backtest and CV
        warning_action = "ignore" if suppress_warning else "default"
        with warnings.catch_warnings():
            warnings.filterwarnings(warning_action, category=UserWarning)
            results = GKForecaster().run_forecast_config(
                df=utils.prophet_style_dataframe(data_ext, covariates_ext, **col_specs),
                config=self.config,
            )
        self.model = results.model
        return self

    """
    Forecaster methods
    """

    @decorators.check_state_and_input
    def forecast(
        self,
        data: Union[TimeIndex, TimeIndexedData],
        suppress_warning: bool = True,
        **kwargs,
    ) -> GreykiteOutput:
        """Use the fitted model to forecast future values

        Parameters
        ----------
        data: Union[TimeIndex, TimeIndexedData]
            The data to forecast. If no covariates were used during `fit()` then only the time_index
            of `TimeIndexedData` is used.
        suppress_warning: bool, default True
            whether to suppress warning emitted from underlying model
        kwargs: Dict[str, Any]
            params passed through to the underlying sklearn pipeline's `predict` method

        Returns
        -------
        GreykiteOutput
            The forecast result
        """
        df = utils.prophet_future_dataframe(data, time_col="ts")
        df[self.fit_data.column_names[0]] = np.nan
        warning_action = "ignore" if suppress_warning else "default"
        with warnings.catch_warnings():
            warnings.filterwarnings(warning_action, category=UserWarning)
            res = self.model.predict(df, **kwargs)

        time_index = data.time_index if isinstance(data, TimeIndexedData) else data
        column_names = self.fit_data.column_names
        return GreykiteOutput(
            out=TimeIndexedData.from_time_index(
                time_index, res["forecast"], column_names=column_names
            ),
            upper=TimeIndexedData.from_time_index(
                time_index, res["forecast_upper"], column_names=column_names
            ),
            lower=TimeIndexedData.from_time_index(
                time_index, res["forecast_lower"], column_names=column_names
            ),
            interval_width=self.prediction_interval_width,
        )

    def save(self, path: str) -> None:
        """Overrides `Estimator`'s default serialization

        This is needed because of https://github.com/pydata/patsy/issues/26. Internally, it uses
        `dill` to pickle the object states recursively.
        """
        with Path(path).open("wb") as f:
            dump(self, f)

    @classmethod
    def load(cls, path: str) -> GreykiteForecaster:
        """Loads `GreykiteForecaster` from the `path`"""
        with Path(path).open("rb") as f:
            return load(f)

    def _doc_url(self, name: str, subsection: str = "") -> str:
        """link to specific section in the public doc. go to overview page by default"""
        url = os.path.join(
            self.__doc_base_url, self.__doc_sections.get(name, "greykite/overview.html")
        )
        if subsection:
            return url + f"#{subsection}"
        return url
