#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

from datetime import datetime
from typing import List, Optional, Tuple, Union

import numpy as np
import numpy.typing as npt
import pandas as pd
from scipy.optimize import minimize
from scipy.special import huber


def _distance_to_line(x: np.array, y: np.array, m: float, b: float) -> np.array:
    """Compute the distance between a set of points and a line.

    The distance is computed as the orthogonal distance between the line y = mx + b and the points
    (x, y).

    Parameters
    ----------
    x: np.array
        The x values of the points.
    y: np.array
        The y values of the points.
    m: float
        The slope of the line.
    b: float
        The intercept of the line.

    Returns
    -------
    np.array
        The orthogonal distances between the line and the points.
    """
    return np.abs((m * x) - y + b) / np.sqrt(m**2 + 1)


def _get_slope_intercept(x1: float, y1: float, x2: float, y2: float) -> Tuple[float, float]:
    """Compute the slope and intercept of the line passing through two points.

    Parameters
    ----------
    x1: float
        The x value of the first point.
    y1: float
        The y value of the first point.
    x2: float
        The x value of the second point.
    y2: float
        The y value of the second point.

    Returns
    -------
    tuple[float, float]
        The slope and intercept of the line passing through the two points.
    """
    m = (y2 - y1) / (x2 - x1)
    b = y1 - (m * x1)
    return m, b


def _top_split_index_and_score(x: np.array, y: np.array) -> Optional[Tuple[int, float]]:
    """Get the top n_splits split indices that maximize the distance to the line.

    The algorithm works by computing the orthogonal distance between the line y = mx + b and
    the points (x, y). It then selects the split indices that maximize the distance to the line.

    Parameters
    ----------
    x: np.array
        The x values of the points.
    y: np.array
        The y values of the points.

    Returns
    -------
    Tuple[int, float]
        The index of the split that maximizes the distance to the line and the correesponding value.
    """
    if len(x) < 3:
        return None

    m, b = _get_slope_intercept(x[0], y[0], x[-1], y[-1])
    distances = _distance_to_line(x, y, m, b)

    if len(x) == 3:
        return 1, distances[1]

    idx = np.argmax(distances[1:-1]) + 1
    return idx, distances[idx]


def _get_top_splits(x: np.array, y: np.array, n_splits: int) -> np.array:
    """Find the top changepoints with a modified Ramer-Douglas-Peucker algorithm

    Typically the RDP algorithm is used to simplify a polygonal curve by removing
    points that are close to the line connecting the first and last points. This
    implementation is a modified version that finds the top n_splits points that
    maximize the distance to the line connecting the first and last points.

    It uses a divide-and-conquer approach to find the best splits in subregions
    of the data. The maximum depth of the recursion is ceil(log2(n_splits)) + 1.

    Parameters
    ----------
    x: np.array
        The x values of the points.
    y: np.array
        The y values of the points.
    n_splits: int
        The number of splits to find.

    Returns
    -------
    np.array
        The indices of the top n_splits splits. The splits are ranked first by
        the depth at which they were found, then by the distance to the line.
    """
    if n_splits < 1 or len(x) < 3:
        return np.array([], dtype=np.int64)

    max_depth = np.ceil(np.log2(n_splits)) + 1

    stack = [(0, len(x), 0)]
    splits = []
    while len(stack) > 0:
        min_ind, max_ind, depth = stack.pop()  # max_ind is exclusive

        if depth >= max_depth:
            continue

        res = _top_split_index_and_score(x[min_ind:max_ind], y[min_ind:max_ind])
        if res is not None:
            rel_idx, score = res
            split_index = min_ind + rel_idx
            if 0 <= split_index < len(x):
                splits.append((split_index, score, depth))
                stack.append((min_ind, split_index + 1, depth + 1))  # max_ind is exclusive
                if split_index + 1 < max_ind:
                    stack.append((split_index, max_ind, depth + 1))

    top_splits = sorted(splits, key=lambda e: (e[2], -e[1]))
    return np.array(sorted([idx for idx, _, _ in top_splits[:n_splits]]))


def _estimate_changepoints(
    y: np.array, min_ind: int, max_ind: int, max_changepoints: int
) -> np.array:
    """Estimate changepoints in a univariate time series.

    The algorithm is meant to be a fast heuristic to find the most significant changepoints in
    the data. It works by computing the Kolmogorov-Smirnov statistic between two samples of
    the data, one before and one after a potential changepoint. The algorithm then selects the
    changepoints with the highest KS statistic values. Selected points are then filtered to
    ensure they are not too close to each other, by collapsing clusters of contiguous points
    into a single one.

    Parameters
    ----------
    y: np.array
        The y values of a univariate time series.
    min_ind: int
        The minimum index of y for where to start looking for change points.
    max_ind: int
        The maximum index of y for where to stop looking for change points.
    max_changepoints: int
        The maximum number of change points to return.

    Returns
    -------
    np.array
        The array of change point indexes that were found.
    """
    y = y[min_ind:max_ind]
    x = np.arange(len(y))
    return _get_top_splits(x, y, max_changepoints) + min_ind


def _trend_predict(
    x: np.array,
    first_intercept: float,
    changepoints: np.array,
    slopes: np.array,
    last_intercept: Optional[float],
) -> np.array:
    """Predict the MiniProphet trend component

    Construct a piecewise linear interpolation from a set of intercepts and changepoints.

    If there are no changepoints then the trend component is y = first_intercept + slopes[0] * x

    Otherwise, for x <= changepoints[0], the trend component is y = first_intercept + slopes[0] * x,
    for changepoints[0] < x < changepoints[-1], the trend component is a linear interpolation
    between the set of continuous line segments parameterized by the matching slopes (n slopes +
    1 intercept defines a continuous sequence of line segments), and for x >= changepoints[-1],
    the trend component is y = last_intercept + slopes[-1] * x.

    This is a private function and makes the assumption that both `changepoints` is sorted and
    strictly increasing.

    Parameters
    ----------
    x: np.array
        The x values to predict the trend component for.
    first_intercept: float
        The intercept value defining y = mx + b for x <= changepoints[0]
    changepoints: np.array
        A sorted, strictly increasing set of x coordinates corresponding to changepoints.
    slopes: np.array
        The slope values corresponding to each changepoint. There shouild be n_changepoints + 1
        slope values (one additional slope for the left polynomial covering (-inf, changepoints[0])
    last_intercept: Optional[float]
        The intercept value defining y = mx + b for x >= changepoints[-1]. Must be specified
        if len(changepoints) > 0

    Returns
    -------
    np.array
        An array of the interpolated trend component values.
    """
    assert len(changepoints) + 1 == len(slopes), "Shape mismatch between changepoints and slopes"

    if len(x) == 0:
        return np.array([], dtype=np.float64)

    left_poly = np.poly1d([slopes[0], first_intercept])

    if len(changepoints) == 0:
        assert last_intercept is None, "last_intercept must be None if there are no changepoints"
        return left_poly(x)

    assert last_intercept is not None, "last_intercept must be not None if there are changepoints"

    right_poly = np.poly1d([slopes[-1], last_intercept])
    if len(changepoints) == 1:
        return np.piecewise(
            x,
            [x < changepoints[0], x >= changepoints[0]],
            [left_poly, right_poly],
        )

    # We know by now that len(changepoints) >= 2
    # dy = slope * dx
    delta_ys = np.concatenate(([0], slopes[1:-1] * np.diff(changepoints)))
    y_intermediate = left_poly(changepoints[0]) + np.cumsum(delta_ys)
    return np.piecewise(
        x,
        [
            x <= changepoints[0],
            np.logical_and(changepoints[0] < x, x < changepoints[-1]),
            x >= changepoints[-1],
        ],
        [
            left_poly,
            lambda x: np.interp(x, changepoints, y_intermediate),
            right_poly,
        ],
    )


class MiniProphet:
    """Implements the key components of the Prophet forecasting procedure

    MiniProphet has the advantage of offering faster training and a 0-dependency simple codebase
    covering 90% of the common prediction cases solved by these librairies. The memory footprint
    is also reduced significantly (orders of magnitude on large datasets), as the implementation
    minimizes memory copies and does not hold references to the training dataframe, which prevents
    garbage collection. The model has two components: a trend component and a seasonality component.

    The default loss function is Huber, but one can also choose a quantile loss.
    A big emphasis has been put on making the model "parameter free" so it works well without any
    knob-tweaking.
    """

    def __init__(
        self,
        weekly_order: int = 6,
        daily_order: int = 6,
        max_changepoints: Union[int, str] = "auto",
        min_changepoint_samples: int = 10,
        lambda_reg: float = 0.01,
        quantile: Optional[float] = None,
        last_slope_constraint_ub: Optional[float] = None,
        last_slope_constraint_lb: Optional[float] = None,
    ):
        """Initialize the MiniProphet torch model

        Parameters
        ----------
        weekly_order: int, default 6
            Fourier order of the weekly seasonality component.
        daily_order: int, default 6
            Fourier order of the daily seasonality component.
        max_changepoints: Union[int, str], default 'auto'
            The maximum number of changepoints that will be automatically inferred.
        min_changepoint_samples: int, default 10
            A constraint on the first and last changepoints detected in the series. The last
            changepoint will be at least this many non-NaN samples from the end of the series.
            Similarly, the first changepoint will be at least this many non-NaN samples from the
            beginning of the series.
        lambda_reg: float, default 0.01
            Amount of regularization for the model parameters.
        quantile: Optional[float], default None
            If specified, the model will perform quantile regression.
        last_slope_constraint_ub: Optional[float], default None
            If specified, the last slope will be constrained to be less than or equal to this value.
        last_slope_constraint_lb: Optional[float], default None
            If specified, the last slope will be constrained to be greater than or equal to this
            value.

        Raises
        ------
        ValueError
            If `quantile` <= 0 or `quantile >= 1`
        """
        self.weekly_order = weekly_order
        self.daily_order = daily_order
        self.max_changepoints = 10 if max_changepoints == "auto" else max_changepoints
        self.min_changepoint_samples = min_changepoint_samples
        self.lambda_reg = lambda_reg
        self.quantile = quantile
        self.last_slope_constraint_ub = last_slope_constraint_ub
        self.last_slope_constraint_lb = last_slope_constraint_lb
        if quantile is None:
            self.loss = lambda p, y: huber(1.0, np.abs(p - y)).mean()
        elif quantile > 0 and quantile < 1:
            self.loss = lambda p, y: np.where(
                p > y, (p - y) * (1 - quantile), (y - p) * quantile
            ).mean()
        else:
            raise ValueError("Invalid quantile value. Needs to be in ]0, 1[")

        # Fit data attributes
        # Used to normalize the x values
        self.x_first_py_dt: Optional[datetime] = None
        self.x_fit_duration_seconds: Optional[float] = None
        # Used to normalize the y values
        self.yscale: Optional[float] = None
        # Trend parameters
        self.first_intercept: Optional[float] = None
        self.changepoints: Optional[np.array] = None
        self.changepoint_idx: Optional[np.array] = None
        self.slopes: Optional[np.array] = None
        self.last_intercept: Optional[float] = None
        # Fourier coefficients
        self.Wseas_week: Optional[np.array] = None
        self.Wseas_day: Optional[np.array] = None
        # External regressors
        self.Wholiday: Optional[np.array] = None
        # Whether or not the model is ready to make predictions
        self.is_ready: bool = False

    def forecast(
        self, X: pd.Series, is_holiday: "npt.NDArray" = None, trend_only=False
    ) -> pd.Series:
        assert self.is_ready, "Model is not ready to make predictions. Please call `learn` first."
        x_norm, *x_fourier = self._get_all_x_inputs(X)
        y_trend, y_seas_week, y_seas_day = self._predict_components(x_norm, *x_fourier)
        y = y_trend
        if not trend_only:
            y += y_seas_week + y_seas_day
        if self.Wholiday is not None and is_holiday is not None:
            y += self.Wholiday * is_holiday
        return pd.Series(y * self.yscale)

    def _predict_components(self, x_norm, x_seas_week, x_seas_day):
        y_trend = _trend_predict(
            x_norm, self.first_intercept, self.changepoints, self.slopes, self.last_intercept
        )
        y_seas_week = (
            x_seas_week[:, :, 0] @ self.Wseas_week[:, 0]
            + x_seas_week[:, :, 1] @ self.Wseas_week[:, 1]
        )
        y_seas_day = (
            x_seas_day[:, :, 0] @ self.Wseas_day[:, 0] + x_seas_day[:, :, 1] @ self.Wseas_day[:, 1]
        )
        return y_trend, y_seas_week, y_seas_day

    @staticmethod
    def _fourier_terms(s: np.array, period: int, order: int):
        res = (2 * np.pi / period) * np.array(s, dtype=np.float64)
        res = np.arange(1, order + 1)[:, None] * res
        return np.concatenate([np.cos(res), np.sin(res)]).T.reshape(len(s), order, 2)

    def __relative_x(self, x: pd.Timestamp) -> float:
        return (
            x.to_pydatetime() - self.x_first_py_dt
        ).total_seconds() / self.x_fit_duration_seconds

    def _initialize_fit_attributes(
        self,
        X: pd.Series,
        Y: pd.Series,
        is_holiday: Optional["npt.NDArray"] = None,
        seed_point_estimate: Optional[MiniProphet] = None,
    ) -> None:
        self.x_first_py_dt: datetime = X.min().floor("us").to_pydatetime()
        self.x_fit_duration_seconds: float = (
            X.max().floor("us").to_pydatetime() - self.x_first_py_dt
        ).total_seconds()
        if self.x_fit_duration_seconds <= 0:
            raise ValueError("Range of data must be at least 1 microsecond.")

        self.yscale = np.percentile(np.abs(Y), q=95.0)
        if np.abs(self.yscale) < 1e-6:
            self.yscale = 1.0  # No-op for very small values

        x_norm = self._normalize_x(X)
        y_norm = self._normalize_y(Y)

        if seed_point_estimate is None or not seed_point_estimate.is_ready:
            min_samples_required = max(self.min_changepoint_samples, 2)
            max_ind = max(len(X) - min_samples_required, 0)
            min_ind = min(min_samples_required, len(X))
            if min_ind < max_ind:
                self.changepoint_idx = _estimate_changepoints(
                    y_norm, min_ind, max_ind, self.max_changepoints
                )
                self.changepoints = np.array([x_norm[i] for i in self.changepoint_idx])
            else:
                self.changepoint_idx = np.array([])
                self.changepoints = np.array([])
        else:
            self.changepoint_idx = seed_point_estimate.changepoint_idx
            self.changepoints = seed_point_estimate.changepoints

        # None can also mean the end of an array
        first_changepoint_idx = None if len(self.changepoints) == 0 else self.changepoint_idx[0]
        initial_slope, initial_intercept = np.polyfit(
            x_norm[:first_changepoint_idx], y_norm[:first_changepoint_idx], 1
        )

        # Initial guess for parameters
        self.first_intercept: float = initial_intercept
        if len(self.changepoints) > 0:
            last_changepoint_idx = self.changepoint_idx[-1]
            last_slope, last_intercept = np.polyfit(
                x_norm[last_changepoint_idx:], y_norm[last_changepoint_idx:], 1
            )
            self.last_intercept = last_intercept
            slopes = [initial_slope]
            # Intermediate slopes
            for idx1, idx2 in zip(self.changepoint_idx, self.changepoint_idx[1:]):
                x0, y0 = x_norm[idx1], y_norm[idx1]
                x1, y1 = x_norm[idx2], y_norm[idx2]
                slope, _ = _get_slope_intercept(x0, y0, x1, y1) if x1 != x0 else 0
                slopes.append(slope)
            slopes.append(last_slope)
            self.slopes = np.array(slopes, dtype=np.float64)
        else:
            self.last_intercept = None
            self.slopes = np.array([initial_slope], dtype=np.float64)

        # Fourier coefficients
        self.Wseas_week: np.array = np.zeros((self.weekly_order, 2), dtype=np.float64)
        self.Wseas_day: np.array = np.zeros((self.daily_order, 2), dtype=np.float64)

        # External regressors
        self.Wholiday = None
        if is_holiday is not None:
            holiday_indices = np.nonzero(is_holiday)
            is_holiday = is_holiday.astype(np.float64)
            self.Wholiday = y_norm[holiday_indices].mean()

        # Whether or not the model is ready to make predictions
        self.is_ready: bool = True

    def _flat_parameters(self) -> np.array:
        return np.concatenate(
            (
                [self.first_intercept],
                [self.last_intercept] if self.last_intercept is not None else [],
                self.slopes,
                self.Wseas_week.flatten(),
                self.Wseas_day.flatten(),
                [self.Wholiday] if self.Wholiday is not None else [],
            )
        )

    def _flat_bounds(self) -> Optional[List[Tuple]]:
        if self.last_slope_constraint_lb is None and self.last_slope_constraint_ub is None:
            return None

        params = self._flat_parameters()
        bounds = [(None, None) for _ in params]

        n_intercepts = 2 if self.last_intercept is not None else 1
        n_slopes = len(self.slopes)
        last_slope_idx = n_intercepts + n_slopes - 1
        ub = self.last_slope_constraint_ub if self.last_slope_constraint_ub is not None else np.inf
        lb = self.last_slope_constraint_lb if self.last_slope_constraint_lb is not None else -np.inf
        bounds[last_slope_idx] = (lb, ub)

        return bounds

    def _update_params_from_array(self, params: np.array) -> None:
        assert self.is_ready, "Attempting to update parameters prior to initialization."
        self.first_intercept = params[0]
        if self.last_intercept is not None:
            self.last_intercept = params[1]

        offset = 2 if self.last_intercept is not None else 1
        self.slopes = params[offset : offset + len(self.slopes)]

        offset += len(self.slopes)
        self.Wseas_week = params[offset : offset + self.weekly_order * 2].reshape(
            (self.weekly_order, 2), order="F"
        )
        offset += self.weekly_order * 2
        self.Wseas_day = params[offset : offset + self.daily_order * 2].reshape(
            (self.daily_order, 2), order="F"
        )

        if self.Wholiday is not None:
            self.Wholiday = params[-1]

    def _normalize_x(self, x: pd.Series) -> np.array:
        return np.array([self.__relative_x(xi) for xi in x], dtype=np.float64)

    def _normalize_period(self, n_hours: int) -> float:
        return (n_hours * 3600) / self.x_fit_duration_seconds

    def _get_all_x_inputs(self, x: pd.Series) -> np.array:
        x_norm = self._normalize_x(x)
        x_seas_week = self._fourier_terms(x_norm, self._normalize_period(24 * 7), self.weekly_order)
        x_seas_day = self._fourier_terms(x_norm, self._normalize_period(24), self.daily_order)
        return x_norm, x_seas_week, x_seas_day

    def _normalize_y(self, y: pd.Series) -> np.array:
        return np.array(y / self.yscale, dtype=np.float64)

    def _normalize_is_holiday(self, is_holiday: Optional["npt.NDArray"]) -> Optional[np.array]:
        if is_holiday is None:
            return None
        return is_holiday.astype(np.float64)

    def learn(
        self, X: pd.Series, Y: pd.Series, isHoliday=None, seed_point_estimate: MiniProphet = None
    ):
        self._initialize_fit_attributes(X, Y, isHoliday, seed_point_estimate)
        Ytrain = self._normalize_y(Y)
        is_holiday = self._normalize_is_holiday(isHoliday)

        x_norm, x_seas_week, x_seas_day = self._get_all_x_inputs(X)

        def callback(vec):
            self._update_params_from_array(vec)
            y_trend, y_seas_week, y_seas_day = self._predict_components(
                x_norm, x_seas_week, x_seas_day
            )
            pred = y_trend + y_seas_week + y_seas_day
            if self.Wholiday is not None:
                pred += self.Wholiday * is_holiday

            loss = self.loss(pred, Ytrain)
            params = self._flat_parameters()
            grad = np.zeros_like(params, dtype=np.float64)

            if self.quantile is None:
                g_loss = np.where(
                    np.abs(pred - Ytrain) <= 1.0, pred - Ytrain, np.sign(pred - Ytrain)
                )
            else:
                g_loss = np.where(pred > Ytrain, (1.0 - self.quantile), -self.quantile)

            # Compute d(loss) / d(trend parameters)
            # First intercept
            mask = (
                x_norm < self.changepoints[-1]
                if len(self.changepoints) > 0
                else np.ones_like(x_norm, dtype=bool)
            )
            grad[0] = g_loss[mask].sum()

            # Last intercept (if applicable)
            if self.last_intercept is not None:
                mask = x_norm >= self.changepoints[-1]
                grad[1] = g_loss[mask].sum()

            # d(loss) / d(slopes)
            slope_start = 1 if self.last_intercept is None else 2
            if len(self.changepoints) > 0:
                effective_changepoints = np.concatenate(([-np.inf], self.changepoints))
                last_changepoint = self.changepoints[-1]
                for i, cp in enumerate(effective_changepoints):
                    if i < len(effective_changepoints) - 1:
                        mask = np.logical_and(x_norm > cp, x_norm < last_changepoint)
                    else:
                        mask = (
                            x_norm >= cp
                        )  # Last segment includes the last changepoint, and continues to infinity
                    grad[slope_start + i] = (g_loss[mask] * x_norm[mask]).sum()
            else:
                grad[slope_start] = (g_loss * x_norm).sum()

            # d(loss) / d(weekly fourier terms)
            weekly_terms_offset = slope_start + len(self.slopes)
            xw = (g_loss[:, None, None] * x_seas_week).sum(axis=0)
            grad[weekly_terms_offset : weekly_terms_offset + self.weekly_order] = xw[:, 0]
            grad[
                weekly_terms_offset
                + self.weekly_order : weekly_terms_offset
                + 2 * self.weekly_order
            ] = xw[:, 1]

            # d(loss) / d(daily fourier terms)
            daily_terms_offset = weekly_terms_offset + 2 * self.weekly_order
            xd = (g_loss[:, None, None] * x_seas_day).sum(axis=0)
            grad[daily_terms_offset : daily_terms_offset + self.daily_order] = xd[:, 0]
            grad[
                daily_terms_offset + self.daily_order : daily_terms_offset + 2 * self.daily_order
            ] = xd[:, 1]

            # d(loss) / d(isHoliday)
            if self.Wholiday is not None:
                grad[-1] = is_holiday.sum()

            grad /= len(x_norm)

            # regularization
            n_slopes = len(self.slopes)
            lt = 0.5 * self.lambda_reg / n_slopes
            slope_idx = slice(slope_start, slope_start + n_slopes)
            w_delta_trend = params[slope_idx]
            grad[slope_idx] += lt * w_delta_trend
            loss += 0.5 * lt * np.square(w_delta_trend).sum()

            if self.weekly_order > 0:
                lw = self.lambda_reg / self.weekly_order
                w_week = params[weekly_terms_offset : weekly_terms_offset + self.weekly_order * 2]
                grad[weekly_terms_offset : weekly_terms_offset + self.weekly_order * 2] += (
                    lw * w_week
                )
                loss += 0.5 * lw * np.square(w_week).sum()

            if self.daily_order > 0:
                ld = self.lambda_reg / self.daily_order
                w_day = params[daily_terms_offset : daily_terms_offset + self.daily_order * 2]
                grad[daily_terms_offset : daily_terms_offset + self.daily_order * 2] += ld * w_day
                loss += 0.5 * ld * np.square(w_day).sum()

            return loss, grad

        res = minimize(
            callback,
            self._flat_parameters(),
            method="L-BFGS-B",
            jac=True,
            bounds=self._flat_bounds(),
            options={
                "maxiter": 1000,  # control worst case runtime in case of adversarial input
                "maxcor": 25,  # this is ok, because we don't have that many parameters
            },
        )
        self._update_params_from_array(res.x)
