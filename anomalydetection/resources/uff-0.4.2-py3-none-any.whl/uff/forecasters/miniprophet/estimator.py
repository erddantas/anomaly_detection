#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Collection, Dict, Optional, Set, Tuple, Union

import numpy as np
import numpy.typing as npt
import pandas as pd

from ...base import ForecasterWithInterval, decorators
from ...consts import EPSILON
from ...transformers.math import ScaledLogitTransformer
from ...tstypes import (
    ColumnSet,
    TimeIndex,
    TimeIndexedData,
    TimeIndexedOutputWithInterval,
    TimeStamp,
)
from ...utils import is_univariate
from ._miniprophet_impl import MiniProphet

if TYPE_CHECKING:
    import datetime


class MiniProphetForecaster(ForecasterWithInterval):
    """A forecaster that uses the MiniProphet implementation to forecast future values.

    Prediction intervals are computed using quantile regression on the residuals of the point
    estimate model. The "deltas" representing the residuals are transformed using a scaled
    logit transformation to ensure that the output values are bounded between EPSILON and
    the maximum observed residual + 1 standard deviation. As an extra precaution, the valid
    range of residual values is at least EPSILON units wide.
    """

    @decorators.set_init_attributes
    def __init__(
        self,
        weekly_order: Optional[int] = None,
        daily_order: Optional[int] = None,
        max_changepoints: Union[int, str] = "auto",
        min_changepoint_samples: Union[int, str] = "auto",
        lambda_reg: float = 0.001,
        prediction_interval_width: float = 0.95,
        holidays: Optional[Collection[TimeStamp]] = None,
        horizon: Optional[TimeStamp] = None,
    ) -> None:
        """Initialize a MiniProphetForecaster

        Parameters
        ----------
        weekly_order: Optional[int], default None
            Fourier order of the weekly seasonality component. If unspecified, this will be
            determined dynamically based on attributes of the `fit()` data.
        daily_order: Optional[int], default None
            Fourier order of the daily seasonality component. If unspecified, this will be
            determined dynamically based on attributes of the `fit()` data.
        max_changepoints: Optional[int], default None
            The maximum number of changepoints to choose from the training data. If unspecified,
            this will be determined dynamically based on attributes of the `fit()` data.
        min_changepoint_samples: Union[int, str], default "auto"
            A constraint on the first and last changepoints detected in the series. The last
            changepoint will be at least this many non-NaN samples from the end of the series.
            Similarly, the first changepoint will be at least this many non-NaN samples from
            the beginning of the series. If "auto" is specified, then the value will depend on
            the granularity of the `fit()` time series. If the granularity is less than 1 day,
            this will be set such that the expected number of samples is at least 2 days (e.g.
            hourly data will yield a value of 48). If the granularity is greater than 27 days,
            this will be set to 3. Otherwise, this will be set to 14. For time series with
            irregular intervals (e.g. business hour), we recommend setting
            `min_changepoint_samples` manually.
        lambda_reg: float, default 0.001
            Amount of regularization for the point estimate model parameters.
        prediction_interval_width: float, default 0.95
            Width of the uncertainty intervals provided for the forecast.
        holidays: Optional[Collection[TimeStamp]], default None
            A list of dates to be considered as holidays by the model.
        horizon: Optional[TimeStamp], default None
            The forecast horizon. This quantity can be used for "auto" determination of some
            hyperparameter values, which may depend on whether the user intends to do
            long-term vs. short-term forecasting.
        """
        self._weekly_order = weekly_order
        self._daily_order = daily_order
        self._max_changepoints = max_changepoints
        self._min_changepoint_samples = min_changepoint_samples
        self._lambda_reg = lambda_reg
        self._holidays: Set[datetime.date] = {pd.Timestamp(h).date() for h in (holidays or [])}
        self._horizon: Optional[pd.Timestamp] = (
            pd.Timestamp(horizon) if horizon is not None else None
        )

        # Estimators (initialized during fit)
        self._point_model: Optional[MiniProphet] = None
        self._high_model: Optional[MiniProphet] = None
        self._high_preprocessor: Optional[ScaledLogitTransformer] = None
        self._low_model: Optional[MiniProphet] = None
        self._low_preprocessor: Optional[ScaledLogitTransformer] = None

        # Fit attributes
        self._out_cols: Optional[ColumnSet] = None
        self._fit_shape: Optional[Tuple[int]] = None

        # Required ForecasterWithInterval
        self.prediction_interval_width = prediction_interval_width

    def _resolve_kwargs(self, data: TimeIndexedData) -> Dict[str, Any]:
        """Determine values for all `None` or `auto` parameters.

        Parameters
        ----------
        data: TimeIndexedData
            The data that is currently being fit.

        Returns
        -------
        Dict[str, Any]
            A set of MiniProphet keyword arguments with specific values.
        """
        n_samples = len(data)  # Guaranteed to be >=2 by the fit method.
        duration = data.last_timestamp() - data.first_timestamp()
        avg_diff = np.mean(np.diff(data.pd_timestamp_index()))

        # Auto parameters
        # If unset, no more than n_samples // 30 parameters will be fit to each of these components.
        min_changepoint_samples, max_changepoints, daily_order, weekly_order = (
            self._min_changepoint_samples,
            self._max_changepoints,
            self._daily_order,
            self._weekly_order,
        )

        if min_changepoint_samples is None or min_changepoint_samples == "auto":
            if avg_diff < pd.Timedelta(hours=23):
                min_changepoint_samples = max(int(pd.Timedelta(days=14) / avg_diff), 14)
            elif avg_diff > pd.Timedelta(days=27):
                min_changepoint_samples = 3
            else:
                min_changepoint_samples = 14
            if self._horizon is not None:
                n_steps = (self._horizon - data.last_timestamp()) / avg_diff
                min_changepoint_samples = max(min_changepoint_samples, int(n_steps))
        else:
            # User specified a value for min_changepoint_samples.
            min_changepoint_samples = int(min_changepoint_samples)

        if weekly_order is None or weekly_order == "auto":
            if duration < pd.Timedelta(days=14):
                weekly_order = 0
            else:
                weekly_order = np.clip(n_samples // 10, 1, 6)

        if daily_order is None or daily_order == "auto":
            if duration < pd.Timedelta(days=2):
                daily_order = 0
            else:
                daily_order = np.clip(n_samples // 10, 1, 6)

        if max_changepoints is None:
            if avg_diff < pd.Timedelta(days=27):
                # ~6 months between changepoints.
                max_changepoints = max(duration // pd.Timedelta(days=180), 3)
            else:
                # ~10 samples between changepoints.
                max_changepoints = max(n_samples // 10, 3)

        return {
            "weekly_order": weekly_order,
            "daily_order": daily_order,
            "max_changepoints": max_changepoints,
            "min_changepoint_samples": min_changepoint_samples,
            "lambda_reg": self._lambda_reg,
        }

    @decorators.update_fit_attributes
    def fit(
        self,
        data: TimeIndexedData,
        covariates: Optional[TimeIndexedData] = None,
    ) -> MiniProphetForecaster:
        """Fit a MiniProphet model to the input time series.

        Parameters
        ----------
        data: TimeIndexedData
            The univariate input observations.
        covariates: Optional[TimeIndexedData], default None
            This argument is unused as MiniProphet does not yet support external regressors.
            It is kept here to maintain signature compatibility with other estimators.

        Returns
        -------
        MiniProphetForecaster
            A reference to `self`.

        Raises
        ------
        ValueError
            If `data` is not univariate.
        """
        if not is_univariate(data):
            raise ValueError("MiniProphetForecaster only supports univariate data.")

        data = data.dropna()

        if len(data) < 2:
            raise ValueError("At least 2 entries are required to fit the model.")

        # Set estimator attributes
        self._out_cols = data.column_tuples
        self._fit_shape = data.shape[1:]

        # Initialize models
        kwargs = self._resolve_kwargs(data)

        quantile_kwargs = {
            k: v for k, v in kwargs.items() if k not in ("weekly_order", "daily_order")
        }
        quantile_kwargs["weekly_order"] = 0
        quantile_kwargs["daily_order"] = 0

        self._point_model = MiniProphet(**kwargs)
        self._high_model = MiniProphet(
            quantile=0.5 + (self.prediction_interval_width / 2),
            # Prediction interval width must get larger as the forecast horizon increases.
            last_slope_constraint_lb=0,
            **quantile_kwargs,
        )
        self._low_model = MiniProphet(
            quantile=0.5 - (self.prediction_interval_width / 2),
            # Prediction interval width must get larger as the forecast horizon increases.
            last_slope_constraint_ub=0,
            **quantile_kwargs,
        )

        # Unpack data
        x = pd.Series(data.pd_timestamp_index())
        y = pd.Series(data.values.flatten())
        is_holiday = self.__get_is_holiday(data.time_index)

        # Fit point model
        self._point_model.learn(x, y, is_holiday)

        # Compute residuals and prediction interval bounds
        residuals_pd_series = y - self._point_model.forecast(x, is_holiday)
        residuals_std = np.std(residuals_pd_series)
        upper_quantile_limit = max(np.max(residuals_pd_series) + residuals_std, 3 * EPSILON)
        lower_quantile_limit = min(np.min(residuals_pd_series) - residuals_std, -3 * EPSILON)

        # Fit upper quantile estimates
        clipped_residuals = residuals_pd_series.clip(EPSILON, upper_quantile_limit - EPSILON)
        self._high_preprocessor = ScaledLogitTransformer(0, upper_quantile_limit)
        scaled_residuals = self._high_preprocessor.forward_func(clipped_residuals)
        self._high_model.learn(
            x, pd.Series(scaled_residuals), is_holiday, seed_point_estimate=self._point_model
        )

        # Fit lower quantile estimates
        clipped_residuals = residuals_pd_series.clip(lower_quantile_limit + EPSILON, -EPSILON)
        self._low_preprocessor = ScaledLogitTransformer(lower_quantile_limit, 0)
        scaled_residuals = self._low_preprocessor.forward_func(clipped_residuals)
        self._low_model.learn(
            x, pd.Series(scaled_residuals), is_holiday, seed_point_estimate=self._point_model
        )

        return self

    @decorators.check_state_and_input
    def forecast(
        self,
        data: Union[TimeIndex, TimeIndexedData],
        **kwargs: Any,
    ) -> TimeIndexedOutputWithInterval:
        """Use the fitted model to forecast future values

        Parameters
        ----------
        data: Union[TimeIndex, TimeIndexedData]
            The data to forecast.
        kwargs: Dict[str, Any]
            Unused

        Returns
        -------
        TimeIndexedOutputWithInterval
            The forecast result and underlying model.
        """
        index = data if isinstance(data, TimeIndex) else data.time_index
        x = pd.Series(data.pd_timestamp_index())
        is_holiday = self.__get_is_holiday(index)

        # Point estimate
        point_pd = self._point_model.forecast(x, is_holiday, **kwargs)

        # Prediction interval
        scaled_delta = self._high_model.forecast(x, is_holiday, **kwargs)
        delta = self._high_preprocessor.backward_func(scaled_delta)
        upper_pd = point_pd + delta

        # Lower bound
        scaled_delta = self._low_model.forecast(x, is_holiday, **kwargs)
        delta = self._low_preprocessor.backward_func(scaled_delta)
        lower_pd = point_pd + delta

        return TimeIndexedOutputWithInterval(
            out=self._format_result(index, point_pd),
            upper=self._format_result(index, upper_pd),
            lower=self._format_result(index, lower_pd),
            interval_width=self.prediction_interval_width,
        )

    def _format_result(self, index: TimeIndex, result: pd.Series) -> TimeIndexedData:
        return TimeIndexedData.from_time_index(
            index,
            result.to_numpy().reshape((len(index),) + self._fit_shape),
            column_names=self._out_cols,
        )

    def __get_is_holiday(self, index: TimeIndex) -> "npt.NDArray":
        if len(self._holidays) == 0:
            return None

        return np.array(
            [t.date() in self._holidays for t in index.timestamp_values],
            dtype=np.bool_,
        )
