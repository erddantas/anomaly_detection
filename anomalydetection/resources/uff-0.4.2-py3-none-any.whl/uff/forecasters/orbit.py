#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

import contextlib
import logging
import multiprocessing
import re
import sys
from dataclasses import dataclass
from inspect import signature
from typing import Any, Callable, Dict, List, Optional, Set, TypeVar, Union

import numpy as np
import numpy.typing as npt

from .. import utils
from ..base import ForecasterWithInterval, decorators
from ..tstypes import TimeIndex, TimeIndexedData, TimeIndexedOutputWithInterval

# Regressor defaults
DEFAULT_REGRESSOR_SIGN = "="
DEFAULT_REGRESSOR_BETA = 0
DEFAULT_REGRESSOR_SIGMA = 1.0
DEFAULT_INIT_KNOT_LOC = 0
DEFAULT_INIT_KNOT_SCALE = 1
DEFAULT_KNOT_SCALE = 0.1

logger = logging.getLogger(__name__)

OrbitForecaster = TypeVar("OrbitForecaster")


@contextlib.contextmanager
def force_multiprocess_fork():
    """Fix hanging .fit() routines on Python >= 3.8

    Based on the suggestion here https://github.com/uber/orbit/issues/520#issuecomment-1077937181
    """
    orig_method = multiprocessing.get_start_method()
    version = re.search(r"^\d+\.\d+\.\d+", sys.version).group()
    int_version = tuple(int(i) for i in version.split("."))
    if int_version >= (3, 8, 0):
        multiprocessing.set_start_method("fork", force=True)
    try:
        yield
    finally:
        multiprocessing.set_start_method(orig_method, force=True)


def get_prediction_percentiles(width: float) -> List[float]:
    return [
        round(100 * (0.5 - (width / 2)), 3),
        round(100 * (0.5 + (width / 2)), 3),
    ]


@dataclass
class OrbitOutput(TimeIndexedOutputWithInterval):
    """Output for Orbit models

    Attributes
    ----------
    out: TimeIndexedData
        Forecasted point estimates
    upper: TimeIndexedData
        The upper bound of the forecast prediction interval
    lower: TimeIndexedData
        The lower bound of the forecast prediction interval
    interval_width: float
        The width of the prediction interval
    """

    out: TimeIndexedData
    upper: TimeIndexedData
    lower: TimeIndexedData
    interval_width: float


class BaseOrbitForecaster(ForecasterWithInterval):
    _init_constrained_values: Dict[str, Set] = {}
    _fit_constrained_values: Dict[str, Set] = {}
    _supports_regressors: bool = False

    def __init__(
        self,
        initializer: Callable[..., OrbitForecaster],
        init_kwargs: Dict[str, Any],
        fit_kwargs: Dict[str, Any],
        prediction_interval_width: float = 0.95,
    ) -> None:
        values = (init_kwargs, fit_kwargs)
        constraints = (self._init_constrained_values, self._fit_constrained_values)
        for value, constraint in zip(values, constraints):
            for k in set(value).intersection(constraint):
                given, allowed = value[k], constraint[k]
                if given not in allowed:
                    raise ValueError(
                        f"Unexpected value '{given}' for {k}. Allowed values: {', '.join(allowed)}"
                    )

        self._initializer = initializer
        self._init_kwargs = init_kwargs
        self._fit_kwargs = fit_kwargs
        self._set_date_freq = "date_freq" in signature(initializer).parameters

        self._regressors = init_kwargs.get("regressor_col") or []
        if any(r in {"ds", "y"} for r in self._regressors):
            raise ValueError("Regressor columns cannot be named 'ds' or 'y'")

        self.fit_data: Optional[TimeIndexedData] = None
        self.fit_covariates: Optional[TimeIndexedData] = None
        self.model: Optional[OrbitForecaster] = None
        self.prediction_interval_width = prediction_interval_width

    @decorators.update_fit_attributes
    def fit(
        self, data: TimeIndexedData, covariates: Optional[TimeIndexedData] = None, **kwargs
    ) -> BaseOrbitForecaster:
        init_kwargs = {}
        init_kwargs.update(self._init_kwargs)
        if self._set_date_freq:
            init_kwargs.update({"date_freq": data.granularity})
        if (
            covariates is not None
            and "regressor_col" not in init_kwargs
            and self._supports_regressors
        ):
            init_kwargs["regressor_col"] = covariates.column_names

        fit_kwargs = {}
        fit_kwargs.update(self._fit_kwargs)
        fit_kwargs.update(kwargs)

        df = utils.prophet_style_dataframe(data, covariates)
        self.model = self._initializer(**init_kwargs)
        with force_multiprocess_fork():
            self.model.fit(df, **fit_kwargs)
        self.fit_data = data
        self.fit_covariates = covariates
        return self

    @decorators.check_state_and_input
    def forecast(self, data: Union[TimeIndexedData, TimeIndex], **kwargs) -> OrbitOutput:
        index = data if isinstance(data, TimeIndex) else data.time_index
        df = utils.prophet_future_dataframe(data)
        res = self.model.predict(df, **kwargs)

        sorted_percentiles = sorted(get_prediction_percentiles(self.prediction_interval_width))
        out_c, lower_c, upper_c = ["prediction"] + [
            "prediction_" + str(p) if p != 50 else "prediction" for p in sorted_percentiles
        ]

        out, lower, upper = [
            TimeIndexedData.from_time_index(
                index, values=res[c], column_names=self.fit_data.column_names
            )
            for c in (out_c, lower_c, upper_c)
        ]

        # Prediction bounds are not checked for order by Orbit. For small sample sizes (e.g. 1)
        # this means that the quantile estimates may not be properly ordered with respect to the
        # "prediction" value. Here we enforce a proper ordering.
        lower.values = np.minimum(lower.values, out.values)
        upper.values = np.maximum(upper.values, out.values)

        return OrbitOutput(
            out=out,
            upper=upper,
            lower=lower,
            interval_width=self.prediction_interval_width,
        )


class OrbitDltForecaster(BaseOrbitForecaster):
    """OrbitDltForecaster

    Attributes
    ----------
    model: DLT
        If fitted, an OrbitDltForecaster instance will have the property obj.model containing the
        fitted DLT model.
    """

    _init_constrained_values = {
        "regression_penalty": {"fixed_ridge", "lasso", "auto_ridge"},
        "global_trend_option": {"linear", "loglinear", "logistic", "flat"},
        "estimator": {"stan-mcmc", "stan-map"},
    }
    _fit_constrained_values = {"point_method": {"mean", "median"}}
    _supports_regressors: bool = True

    @decorators.set_init_attributes
    def __init__(
        self,
        seasonality: Optional[int] = None,
        seasonality_sm_input: Optional[float] = None,
        level_sm_input: Optional[float] = None,
        regressors: Optional[List[Dict[str, Any]]] = None,
        regression_penalty: str = "fixed_ridge",
        scale: float = 0.5,
        slope_sm_input: Optional[float] = None,
        period: int = 1,
        damped_factor: float = 0.8,
        global_trend_option: str = "linear",
        global_cap: float = 1.0,
        global_floor: float = 0.0,
        estimator: str = "stan-mcmc",
        n_bootstrap_draws: int = 1000,
        point_method: str = "mean",
        prediction_interval_width: float = 0.95,
        **kwargs: Any,
    ) -> None:
        """Initialize a DLT model

        Parameters
        ----------
        seasonality: Optional[int], default None
            Length of seasonality in steps. The actual time length of the seasonality will be
            determined by the granularity of the fit time series.
        seasonality_sm_input: Optional[float], default None
            A value between [0, 1], applicable only if `seasonality` > 1. A larger value puts
            more weight on the current seasonality. If None, the model will estimate this value.
        level_sm_input: Optional[float], default None
            A value between [0.0001, 1]. A larger value puts more weight on the current level.
            If None, the model will estimate this value.
        regressors: Optional[List[Dict[str, Any]]], default None
            A list of extra regressors to be used in the model. The entries are dictionaries with
            a required key "name" and optional keys "sign", "beta_prior", and "sigma_prior".
            "sign" values should be { '+', '-', '=' } such that: '+' indicates regressor
            coefficient estimates are constrained to [0, inf), '-' indicates regressor coefficient
            estimates are constrained to (-inf, 0], '=' indicates regressor coefficient estimates
            can be any value between (-inf, inf). "=" will be assumed if not provided. If
            beta_prior or sigma_prior are not provided, then the model will use un-informative
            priors.
        regression_penalty: str {'fixed_ridge', 'lasso', 'auto_ridge'}, default fixed_ridge
            Regression penalty method
        scale: float, default 0.5
            Regularizing parameter, used if regression_penalty = "lasso" or "auto_ridge"
        slope_sm_input: Optional[float], default None
            Avalue between [0, 1]. A larger value puts more weight on the current slope. If
            None, the model will estimate this value.
        period: int, default 1
            Used to set `time_delta` as `1 / max(period, seasonality)`. The units of
            `time_delta` are steps. The actual time length of the period will be determined by
            the granularity of the fit time series.
        damped_factor: float, default 0.8
            Hyperparameter float value between [0, 1]. A smaller value further dampens the
            previous global trend value.
        global_trend_option: str, { 'linear', 'loglinear', 'logistic', 'flat'}
            Transformation function for the shape of the forecasted global trend.
        global_cap: float, default 1
            Maximum value of global logistic trend. This value is used only when
            `global_trend_option` = 'logistic'
        global_floor: float, default 0
            Minimum value of global logistic trend. This value is used only when
            `global_trend_option` = 'logistic'
        estimator: str {'stan-mcmc', 'stan-map'}, default "stan-mcmc"
            Which estimator to use
        n_bootstrap_draws: int, default 1000
            Number of samples to bootstrap in order to generate the prediction interval. For
            full Bayesian and variational inference forecasters, samples are drawn directly from
            original posteriors. For point-estimated posteriors, it will be used to sample
            noise parameters.
        point_method: str {'mean', 'median'}, default 'mean'
            Which point estimate to use. Will only be used if `estimator` is 'stan-mcmc'
        prediction_interval_width: float, default 0.95
            The width of the output prediction interval [0, 1]
        kwargs: Any
            These are passed directly to the estimator initialization.
        """
        from orbit.models import DLT

        init_kwargs = {
            "seasonality": seasonality,
            "seasonality_sm_input": seasonality_sm_input,
            "level_sm_input": level_sm_input,
            "regression_penalty": regression_penalty,
            "slope_sm_input": slope_sm_input,
            "period": period,
            "damped_factor": damped_factor,
            "global_trend_option": global_trend_option,
            "global_cap": global_cap,
            "global_floor": global_floor,
            "estimator": estimator,
            "n_bootstrap_draws": n_bootstrap_draws,
            "prediction_percentiles": get_prediction_percentiles(prediction_interval_width),
        }
        init_kwargs.update(kwargs)

        if regression_penalty == "lasso":
            init_kwargs["lasso_scale"] = scale
        if regression_penalty == "auto_ridge":
            init_kwargs["auto_ridge_scale"] = scale
        if regressors is not None and len(regressors) > 0:
            init_kwargs["regressor_col"] = [r["name"] for r in regressors]
            init_kwargs["regressor_sign"] = [
                r.get("sign", DEFAULT_REGRESSOR_SIGN) for r in regressors
            ]
            init_kwargs["regressor_beta_prior"] = [
                r.get("beta_prior", DEFAULT_REGRESSOR_BETA) for r in regressors
            ]
            init_kwargs["regressor_sigma_prior"] = [
                r.get("sigma_prior", DEFAULT_REGRESSOR_SIGMA) for r in regressors
            ]

        fit_kwargs = {"point_method": point_method} if estimator == "stan-mcmc" else {}
        super().__init__(DLT, init_kwargs, fit_kwargs, prediction_interval_width)


class OrbitEtsForecaster(BaseOrbitForecaster):
    """OrbitEtsForecaster

    Attributes
    ----------
    model: ETS
        If fitted, an OrbitEtsForecaster instance will have the property obj.model containing the
        fitted ETS model.
    """

    _init_constrained_values = {"estimator": {"stan-mcmc", "stan-map"}}
    _fit_constrained_values = {"point_method": {"mean", "median"}}

    @decorators.set_init_attributes
    def __init__(
        self,
        seasonality: Optional[int] = None,
        seasonality_sm_input: Optional[float] = None,
        level_sm_input: Optional[float] = None,
        estimator: str = "stan-mcmc",
        n_bootstrap_draws: int = 1000,
        point_method: str = "mean",
        prediction_interval_width: float = 0.95,
        **kwargs: Any,
    ) -> None:
        """Initialize a ETS model

        Parameters
        ----------
        seasonality: Optional[int], default None
            Length of seasonality in steps. The actual time length of the seasonality will be
            determined by the granularity of the fit time series.
        seasonality_sm_input: Optional[float], default None
            A value between [0, 1], applicable only if `seasonality` > 1. A larger value puts
            more weight on the current seasonality. If None, the model will estimate this value.
        level_sm_input: Optional[float], default None
            A value between [0.0001, 1]. A larger value puts more weight on the current level.
            If None, the model will estimate this value.
        estimator: str {'stan-mcmc', 'stan-map'}, default "stan-mcmc"
            Which estimator to use
        n_bootstrap_draws: int, default 1000
            Number of samples to bootstrap in order to generate the prediction interval. For full
            Bayesian and variational inference forecasters, samples are drawn directly from
            original posteriors. For point-estimated posteriors, it will be used to sample
            noise parameters.
        point_method: str {'mean', 'median'}, default 'mean'
            Which point estimate to use. Will only be used if `estimator` is 'stan-mcmc'
        prediction_interval_width: float, default 0.95
            The width of the output prediction interval [0, 1]
        kwargs: Any
            These are passed directly to the estimator initialization
        """
        from orbit.models import ETS

        init_kwargs = {
            "seasonality": seasonality,
            "seasonality_sm_input": seasonality_sm_input,
            "level_sm_input": level_sm_input,
            "estimator": estimator,
            "n_bootstrap_draws": n_bootstrap_draws,
            "prediction_percentiles": get_prediction_percentiles(prediction_interval_width),
        }
        init_kwargs.update(kwargs)
        fit_kwargs = {"point_method": point_method} if estimator == "stan-mcmc" else {}
        super().__init__(ETS, init_kwargs, fit_kwargs, prediction_interval_width)


class OrbitKtrForecaster(BaseOrbitForecaster):
    _supports_regressors: bool = True

    @decorators.set_init_attributes
    def __init__(
        self,
        level_knot_scale: float = 0.1,
        level_segments: int = 10,
        level_knot_distance: Optional[float] = None,
        level_knot_dates: Optional["npt.ArrayLike"] = None,
        seasonality: Optional[Union[int, List[int]]] = None,
        seasonality_fs_order: Optional[Union[int, List[int]]] = None,
        seasonality_segments: int = 3,
        seasonal_initial_knot_scale: float = 1.0,
        seasonal_knot_scale: float = 0.1,
        regressors: Optional[List[Dict[str, Any]]] = None,
        regression_segments: int = 5,
        regression_knot_distance: Optional[int] = None,
        regression_knot_dates: Optional["npt.ArrayLike"] = None,
        regression_rho: float = 0.15,
        degree_of_freedom: int = 30,
        coef_prior_list: Optional[List[Dict[str, Any]]] = None,
        flat_multiplier: bool = True,
        residuals_upper_bound: Optional[float] = None,
        n_bootstrap_draws: int = 1000,
        prediction_interval_width: float = 0.95,
        **kwargs: Any,
    ):
        """Initialize a KTR model

        Parameters
        ----------
        level_knot_scale: float, default 0.1
            Sigma for level
        level_segments: int, default 10
            The number of segments partitioned by the knots of level (trend)
        level_knot_distance: Optional[int], default None
            The distance between every two knots of level (trend)
        level_knot_dates: Optional[npt.ArrayLike], default None
            A list of pre-specified dates for the level knots
        seasonality: Optional[Union[int, List[int]]], default None
            Seasonality / seasonalities expressed in a number of steps. The actual time length of
            the seasonality will be determined by the granularity of the fit time series.
        seasonality_fs_order: Optional[Union[int, List[int]]], default None
            Fourier series order for seasonality
        seasonality_segments: int, default 3
            The number of segments partitioned by the knots of seasonality
        seasonal_initial_knot_scale: float, default 1.0
            The scale parameter for seasonal regressors initial coefficient knots.
        seasonal_knot_scale: float, default 0.1
            The scale parameter for seasonal regressors drift of coefficient knots.
        regressors: Optional[List[Dict[str, Any]]], default None
            A list of extra regressors to be used in the model. The entries are dictionaries with
            a required key "name" and optional keys "sign", "init_knot_loc", "init_knot_scale",
            and "knot_scale". "sign" values should be {'+', '-', '='} such that: '+' indicates
            regressor coefficient estimates are constrained to [0, inf), '-' indicates regressor
            coefficient estimates are constrained to (-inf, 0], '=' indicates regressor coefficient
            estimates can be any value between (-inf, inf). If not provided init_knot_loc,
            init_knot_scale and knot_scale will be set to 0, 1, and 0.1 respectively.
        regression_segments: int, default 5
            The number of segments partitioned by the knots of regression
        regression_knot_distance: Optional[int], default None
            The distance between every two knots of regression, if provided.
        regression_knot_dates: Optional[npt.ArrayLike], default None
            A list of pre-specified dates for regression knots
        regression_rho: float, default 0.15
            Sigma in the Gaussian kernel for the regression term
        degree_of_freedom: int, default 30
            Degrees of freedom for error t-distribution
        coef_prior_list: Optional[List[Dict[str, Any]]], default None
            A list of coefficient priors with required keys "name", "prior_start_tp_idx",
            "prior_end_tp_idx", "prior_mean", "prior_sd", and "prior_regressor_col".
            "prior_start_tp_idx" and "prior_end_tp_idx" are inclusive and non-inclusive
            respectively
        flat_multiplier: bool, default True
            If False, the knot scale will be adjusted with a multiplier based on regressor
            volume around each knot. When True, all multipliers will be set to 1.
        residuals_upper_bound: Optional[float], default None
            Upper-bound of the residuals scale
        n_bootstrap_draws: int, default 1000
            Number of samples to bootstrap in order to generate the prediction interval. For
            full Bayesian and variational inference forecasters, samples are drawn directly
            from original posteriors. For point-estimated posteriors, it will be used to sample
            noise parameters.
        prediction_interval_width: float, default 0.95
            The width of the output prediction interval [0, 1]
        kwargs: Any
            These are passed directly to the estimator initialization
        """
        from orbit.models import KTR

        init_kwargs = {
            "level_knot_scale": level_knot_scale,
            "level_segments": level_segments,
            "level_knot_distance": level_knot_distance,
            "level_knot_dates": level_knot_dates,
            "seasonality": seasonality,
            "seasonality_fs_order": seasonality_fs_order,
            "seasonality_segments": seasonality_segments,
            "seasonal_initial_knot_scale": seasonal_initial_knot_scale,
            "seasonal_knot_scale": seasonal_knot_scale,
            "regression_segments": regression_segments,
            "regression_knot_distance": regression_knot_distance,
            "regression_knot_dates": regression_knot_dates,
            "regression_rho": regression_rho,
            "degree_of_freedom": degree_of_freedom,
            "coef_prior_list": coef_prior_list,
            "flat_multiplier": flat_multiplier,
            "residuals_scale_upper": residuals_upper_bound,
            "n_bootstrap_draws": n_bootstrap_draws,
            "prediction_percentiles": get_prediction_percentiles(prediction_interval_width),
        }
        init_kwargs.update(kwargs)
        if regressors is not None and len(regressors) > 0:
            init_kwargs["regressor_col"] = [r["name"] for r in regressors]
            init_kwargs["regressor_sign"] = [
                r.get("sign", DEFAULT_REGRESSOR_SIGN) for r in regressors
            ]
            init_kwargs["regressor_init_knot_loc"] = [
                r.get("init_knot_loc", DEFAULT_INIT_KNOT_LOC) for r in regressors
            ]
            init_kwargs["regressor_init_knot_scale"] = [
                r.get("init_knot_scale", DEFAULT_INIT_KNOT_SCALE) for r in regressors
            ]
            init_kwargs["regressor_knot_scale"] = [
                r.get("knot_scale", DEFAULT_KNOT_SCALE) for r in regressors
            ]

        super().__init__(KTR, init_kwargs, {}, prediction_interval_width)


class OrbitKtrLiteForecaster(BaseOrbitForecaster):
    """OrbitKtrLiteForecaster

    Attributes
    ----------
    model: KTRLite
        If fitted, an OrbitKtrLiteForecaster instance will have the property obj.model containing
        the fitted KTRLite model.
    """

    @decorators.set_init_attributes
    def __init__(
        self,
        level_knot_scale: float = 0.1,
        level_segments: int = 10,
        level_knot_distance: Optional[float] = None,
        level_knot_dates: Optional["npt.ArrayLike"] = None,
        seasonality: Optional[Union[int, List[int]]] = None,
        seasonality_fs_order: Optional[Union[int, List[int]]] = None,
        seasonality_segments: int = 3,
        seasonal_initial_knot_scale: float = 1.0,
        seasonal_knot_scale: float = 0.1,
        degree_of_freedom: int = 30,
        n_bootstrap_draws: int = 1000,
        prediction_interval_width: float = 0.95,
        **kwargs: Any,
    ):
        """Initialize a KTRLite model

        Parameters
        ----------
        level_knot_scale: float, default 0.1
            Sigma for level
        level_segments: int, default 10
            The number of segments partitioned by the knots of level (trend)
        level_knot_distance: Optional[int], default None
            The distance between every two knots of level (trend)
        level_knot_dates: Optional[npt.ArrayLike], default None
            A list of pre-specified dates for the level knots
        seasonality: Optional[Union[int, List[int]]], default None
            Seasonality / seasonalities expressed in a number of steps. The actual time length of
            the seasonality will
            be determined by the granularity of the fit time series.
        seasonality_fs_order: Optional[Union[int, List[int]]], default None
            Fourier series order for seasonality
        seasonality_segments: int, default 3
            The number of segments partitioned by the knots of seasonality
        seasonal_initial_knot_scale: float, default 1.0
            The scale parameter for seasonal regressors initial coefficient knots.
        seasonal_knot_scale: float, default 0.1
            The scale parameter for seasonal regressors drift of coefficient knots.
        degree_of_freedom: int, default 30
            Degrees of freedom for error t-distribution
        n_bootstrap_draws: int, default 1000
            Number of samples to bootstrap in order to generate the prediction interval. For
            full Bayesian and variational inference forecasters, samples are drawn directly from
            original posteriors. For point-estimated posteriors, it will be used to sample noise
            parameters.
        prediction_interval_width: float, default 0.95
            The width of the output prediction interval [0, 1]
        kwargs: Any
            These are passed directly to the estimator initialization
        """
        from orbit.models import KTRLite

        init_kwargs = {
            "level_knot_scale": level_knot_scale,
            "level_segments": level_segments,
            "level_knot_distance": level_knot_distance,
            "level_knot_dates": level_knot_dates,
            "seasonality": seasonality,
            "seasonality_fs_order": seasonality_fs_order,
            "seasonality_segments": seasonality_segments,
            "seasonal_initial_knot_scale": seasonal_initial_knot_scale,
            "seasonal_knot_scale": seasonal_knot_scale,
            "degree_of_freedom": degree_of_freedom,
            "n_bootstrap_draws": n_bootstrap_draws,
            "prediction_percentiles": get_prediction_percentiles(prediction_interval_width),
        }
        init_kwargs.update(kwargs)
        super().__init__(KTRLite, init_kwargs, {}, prediction_interval_width)


class OrbitLgtForecaster(BaseOrbitForecaster):
    """OrbitLgtForecaster

    Attributes
    ----------
    model: LGT
        If fitted, an OrbitLgtForecaster instance will have the property obj.model containing the
        fitted LGT model.
    """

    _init_constrained_values = {"estimator": {"stan-mcmc", "stan-map", "pyro-svi"}}
    _fit_constrained_values = {"point_method": {"mean", "median"}}
    _supports_regressors: bool = True

    @decorators.set_init_attributes
    def __init__(
        self,
        seasonality: Optional[int] = None,
        seasonality_sm_input: Optional[float] = None,
        level_sm_input: Optional[float] = None,
        regressors: Optional[List[Dict[str, Any]]] = None,
        regression_penalty: str = "fixed_ridge",
        scale: float = 0.5,
        slope_sm_input: Optional[float] = None,
        estimator: str = "stan-mcmc",
        n_bootstrap_draws: int = 1000,
        prediction_interval_width: float = 0.95,
        point_method: str = "mean",
        **kwargs: Any,
    ):
        """Initialize a LGT model

        Parameters
        ----------
        seasonality: Optional[int], default None
            Length of seasonality in steps. The actual time length of the seasonality will be
            determined by the granularity of the fit time series.
        seasonality_sm_input: Optional[float], default None
            A value between [0, 1], applicable only if `seasonality` > 1. A larger value puts more
            weight on the current seasonality. If None, the model will estimate this value.
        level_sm_input: Optional[float], default None
            A value between [0.0001, 1]. A larger value puts more weight on the current level.
            If None, the model will estimate this value.
        regressors: Optional[List[Dict[str, Any]]], default None
            A list of extra regressors to be used in the model. The entries are dictionaries with
            a required key "name" and optional keys "sign", "beta_prior", and "sigma_prior". "sign"
            values should be { '+', '-', '=' } such that: '+' indicates regressor coefficient
            estimates are constrained to [0, inf), '-' indicates regressor coefficient estimates
            are constrained to (-inf, 0], '=' indicates regressor coefficient estimates can be
            any value between (-inf, inf). "=" will be assumed if not provided. If beta_prior or
            sigma_prior are not provided, then the model will use un-informative priors.
        regression_penalty: str {'fixed_ridge', 'lasso', 'auto_ridge'}, default fixed_ridge
            Regression penalty method
        scale: float, default 0.5
            Regularizing parameter, used if regression_penalty = "lasso" or "auto_ridge"
        slope_sm_input: Optional[float], default None
            Avalue between [0, 1]. A larger value puts more weight on the current slope. If None,
            the model will estimate this value.
        estimator: str {'stan-mcmc', 'stan-map'}, default "stan-mcmc"
            Which estimator to use
        n_bootstrap_draws: int, default 1000
            Number of samples to bootstrap in order to generate the prediction interval. For
            full Bayesian and variational inference forecasters, samples are drawn directly
            from original posteriors. For point-estimated posteriors, it will be used to sample
            noise parameters.
        prediction_interval_width: float, default 0.95
            The width of the output prediction interval [0, 1]
        point_method: str {'mean', 'median'}, default 'mean'
            Which point estimate to use. Will only be used if `estimator` is 'stan-mcmc'
        kwargs: Any
            These are passed directly to the estimator initialization
        """
        from orbit.models import LGT

        init_kwargs = {
            "seasonality": seasonality,
            "seasonality_sm_input": seasonality_sm_input,
            "level_sm_input": level_sm_input,
            "regression_penalty": regression_penalty,
            "slope_sm_input": slope_sm_input,
            "estimator": estimator,
            "n_bootstrap_draws": n_bootstrap_draws,
            "prediction_percentiles": get_prediction_percentiles(prediction_interval_width),
        }
        init_kwargs.update(kwargs)

        if regression_penalty == "lasso":
            init_kwargs["lasso_scale"] = scale
        if regression_penalty == "auto_ridge":
            init_kwargs["auto_ridge_scale"] = scale
        if regressors is not None and len(regressors) > 0:
            init_kwargs["regressor_col"] = [r["name"] for r in regressors]
            init_kwargs["regressor_sign"] = [
                r.get("sign", DEFAULT_REGRESSOR_SIGN) for r in regressors
            ]
            init_kwargs["regressor_beta_prior"] = [
                r.get("beta_prior", DEFAULT_REGRESSOR_BETA) for r in regressors
            ]
            init_kwargs["regressor_sigma_prior"] = [
                r.get("sigma_prior", DEFAULT_REGRESSOR_SIGMA) for r in regressors
            ]

        fit_kwargs = {"point_method": point_method} if estimator == "stan-mcmc" else {}
        super().__init__(LGT, init_kwargs, fit_kwargs, prediction_interval_width)
