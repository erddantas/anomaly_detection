#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

# To do: Refactor so Robust STL does not have multiple possible predict
# interfaces. go/jira/DSTM-85
from __future__ import annotations

import operator
from datetime import timedelta
from typing import Dict, Optional, Union

import numpy as np
import numpy.typing as npt
import pandas as pd
from scipy.optimize import curve_fit
from statsmodels.nonparametric.smoothers_lowess import lowess

from .. import logger
from ..base import Forecaster, Transformer, decorators
from ..tstypes import TimeIndex, TimeIndexedData, TimeIndexedOutput, TimeUnit


def fourier_term(t: float, n: float, p: float) -> float:
    return 2 * np.pi * t * n / p


def fourier_series(x: float, *coeff: float, harmonics: Dict[float, int]) -> float:
    """
    Helper function for Fourier regression fitting routine
    """
    assert len(coeff) == 1 + 2 * sum(harmonics.values())
    ret = coeff[0]
    coeff_offset = 1
    for p, h in harmonics.items():
        ret += sum(
            coeff[2 * i + coeff_offset] * np.sin(fourier_term(x, i + 1, p))
            + coeff[2 * i + coeff_offset + 1] * np.cos(fourier_term(x, i + 1, p))
            for i in range(h)
        )
        coeff_offset += 2 * h
    return ret


class RobustStlModel(Forecaster, Transformer):
    """Model class for robust STL

    Robust STL stands for seasonal trend decomposition by LOESS.

    The modeling routine proceeds as follows
        1. Model and remove trend using LOESS (additive or multiplicative option)
        2. Model and remove seasonality using robust Fourier regression

    The predict method performs a forward linear projection for the trend term, and extrapolates
    the Fourier model for the seasonality

    Disclaimer: in its current implementation, the model is designed to support business metrics
    with 15min - 1day time granularity and ideally at least a couple months of training data.
    For cases outside these parameters, use at your own risk!

    Attributes
    ------
    fit_data: Optional[TimeIndexedData]
        The original dataset passed into the fit routine
    trend_lookback: Optional[TimeUnit]
        Lookback period for modeling trend.  If None, use full series.
    seasonality_lookback: Optional[TimeUnit]
        Lookback period for modeling seasonality.  If None, use full series.
    seasonality_adjustment: str
        "m" for multiplicative (default), "a" for additive
    fourier_model_order: Optional[Dict[float, int]]
        dict in the format {period: harmonics}.  Period is normalized to 1 day.
        Example 1: {7: 16} means we can use up to 16 harmonices of weekly seasonality
        Example 2: {7: 16, 1: 4} is modeling both weekly and daily seasonality
        Series assumed to be sub-daily granularity in Example 2
    Raises
    ------
    ValueError
        If `validate_params` method fails or if the TimeIndexedData passed into fit is not
        univariate
    """

    @decorators.set_init_attributes
    def __init__(
        self,
        trend_lookback: Optional[TimeUnit] = None,
        seasonality_lookback: Optional[TimeUnit] = None,
        seasonality_adjustment: str = "m",
        fourier_model_order: Optional[Dict[float, int]] = None,
    ) -> None:
        self.fit_data: Optional[TimeIndexedData] = None
        self.trend_lookback: Optional[TimeUnit] = trend_lookback
        self.seasonality_lookback: Optional[TimeUnit] = seasonality_lookback
        self.seasonality_adjustment: str = seasonality_adjustment
        self.fourier_model_order: Optional[Dict[float, int]] = fourier_model_order or {7: 16}
        self._df: pd.DataFrame = pd.DataFrame()
        self._original_data_series: pd.Series = pd.Series(dtype=float)
        self._fourier_coeff: Optional[np.array] = None
        self._huber_estimator: Optional[float] = None
        self.validate_params()

    def validate_params(self) -> None:
        """Validate Robust STL parameters

        Currently we only check that the seasonality adjustment is a valid value (multiplicative
        or additive)
        """
        if self.seasonality_adjustment not in ("m", "a"):
            raise ValueError("only multiplicative or additive seasonlity adjustments are supported")

    def validate_training_data(self, data: TimeIndexedData) -> None:
        # For best results, time granularity should be sub-daily
        if data.time_index.granularity >= pd.Timedelta("1d"):
            logger.warning(
                f"training data with time granularity {data.time_index.granularity} provided, "
                "RobustSTL is designed for series with sub-daily granularity"
            )
        if data.last_timestamp() - data.first_timestamp() < pd.Timedelta("2w"):
            logger.warning(
                "Less than 2 weeks of training data provided, more data is suggested for "
                "fitting weekly seasonality effects"
            )

    @decorators.update_fit_attributes
    def fit(self, data: TimeIndexedData, **kwargs) -> RobustStlModel:
        self.validate_training_data(data)
        self.fit_data = data
        self._df = self.fit_data.to_pandas(time_col="ts", time_as_pd_timestamps=True).set_index(
            "ts"
        )
        # This model is intended for univariate series with no covariates
        # If we see more than 2 columns, throw error
        if len(self._df.columns) != 1:
            raise ValueError(
                "RobustStlModel expecting univariate time series as input to training routine"
            )
        self._fit_trend_model()
        self._fit_seasonality_model()

    def is_fitted(self) -> bool:
        return self.fit_data is not None

    def _fit_trend_model(self) -> None:
        # Fit LOESS regression to the weekly median
        ts = self.fit_data
        if (
            self.trend_lookback is not None
            and pd.Timedelta(self.trend_lookback) < ts.last_timestamp() - ts.first_timestamp()
        ):
            ts = ts.time_slice(start=ts.last_timestamp() - pd.Timedelta(self.trend_lookback))

        weekly_medians = ts.resample(freq="W", reducer=np.median)
        smoothed_daily_medians = lowess(
            weekly_medians.values,
            range(len(weekly_medians.values)),
            is_sorted=True,
            frac=min(1, 52 / (len(weekly_medians.values))),
            it=0,
        )
        weekly_medians = weekly_medians.to_pandas(
            time_col="ts", time_as_pd_timestamps=True
        ).set_index("ts")
        weekly_medians["smoothed"] = np.array([v[1] for v in smoothed_daily_medians])
        t = weekly_medians.index
        r = ts.pd_timestamp_index()
        ts_smoothed = weekly_medians["smoothed"].reindex(t.union(r)).interpolate("index").loc[r]
        self._df = self._df.join(ts_smoothed)

    def _fit_seasonality_model(self) -> None:
        if self.seasonality_adjustment == "m":
            detrended_series = self.fit_data.values / self._df.loc[:, "smoothed"]
        elif self.seasonality_adjustment == "a":
            detrended_series = self.fit_data.values - self._df.loc[:, "smoothed"]
        if (
            self.seasonality_lookback is not None
            and pd.Timedelta(self.seasonality_lookback)
            < detrended_series.index[-1] - detrended_series.index[0]
        ):
            detrended_series = detrended_series.loc[
                detrended_series.index[-1] - pd.Timedelta(self.seasonality_lookback) :
            ]

        self._fourier_coeff, _ = curve_fit(
            self._fourier_objective_fn,
            self._fourier_x_val(detrended_series.index).values,
            detrended_series.values,
            p0=[0] + [0] * 2 * sum(self.fourier_model_order.values()),
            method="trf",
            loss="huber",
        )
        self._df = self._df.join(
            (
                detrended_series
                - self._fourier_objective_fn(
                    self._fourier_x_val(detrended_series.index).values, *self._fourier_coeff
                )
            ).rename("residuals")
        )

    def _fourier_objective_fn(self, x, *coeff):
        return fourier_series(x, *coeff, harmonics=self.fourier_model_order)

    def _fourier_x_val(self, timestamp: npt.ArrayLike[pd.Timestamp]):
        return (pd.DatetimeIndex(timestamp) - self._df.index[0]) / timedelta(days=1)

    @decorators.check_state_and_input
    def forecast(self, data: Union[TimeIndex, TimeIndexedData], **kwargs) -> TimeIndexedOutput:
        """Predict with fitted Robust STL model
        Parameters
        ----------
        data : Union[TimeIndex, TimeIndexedData]
            Data containing variables for prediction. If TimeIndexedData is provided, only the
            time_index is used.
        Returns
        -------
        RobustStlOutput
            Output prediction from the robust STL model
        Raises
        ------
        ValueError
            If a model has not been fitted
        ValueError
            If future contains indices that are before the end of `fit_data`
        """

        if not self.is_fitted():
            raise ValueError("Call fit() before predict().")

        if not self.fit_data.strictly_before(data):
            raise ValueError(
                f"indices for `data` must start after {self.fit_data.pd_timestamp_index()[-1]}"
            )

        future = data if isinstance(data, TimeIndex) else data.time_index
        timestamps = np.array(future.timestamp_values)

        if self.seasonality_adjustment == "m":
            apply_seasonality = operator.mul
        elif self.seasonality_adjustment == "a":
            apply_seasonality = operator.add

        y = apply_seasonality(
            self.extrapolated_trend_component(timestamps),
            self.extrapolated_seasonal_component(timestamps),
        )
        return TimeIndexedOutput(
            out=TimeIndexedData(
                time_array=timestamps,
                values=y,
            )
        )

    def extrapolated_trend_component(
        self, timestamp: npt.ArrayLike[pd.Timestamp]
    ) -> npt.ArrayLike[float]:
        last_smoothed_obs = self._df.loc[:, "smoothed"][-10:]
        a = (last_smoothed_obs[-1] - last_smoothed_obs[0]) / (
            last_smoothed_obs.index[-1] - last_smoothed_obs.index[0]
        ).seconds
        return (
            last_smoothed_obs[-1]
            + a * (pd.DatetimeIndex(timestamp) - last_smoothed_obs.index[-1]).total_seconds()
        )

    def extrapolated_seasonal_component(
        self, timestamp: npt.ArrayLike[pd.Timestamp]
    ) -> npt.ArrayLike[float]:
        return fourier_series(
            self._fourier_x_val(timestamp), *self._fourier_coeff, harmonics=self.fourier_model_order
        )

    @decorators.check_state_and_input
    def transform(self, data: TimeIndexedData, **kwargs) -> TimeIndexedOutput:
        """Given an input TimeSeriesData object, we detrend and deseasonalize using
            the RobustSTLModel
        If the timestamps lie within the period during which the RobustSTLModel was
            trained, we interpolate the point estimates from the trained model
        If the timestamps lie in the future, we extrapolate the trend model
        If the timestamps lie in the past, NaN is returned for the corresponding time points
        Parameters
        ----------
        data : TimeIndexedData
            Data to be transformed
        Returns
        -------
        TimeIndexedData
            Transformed data, with same indices as input data
        Raises
        ------
        ValueError
            If input data is not a univariate time series
        """

        ts = data.to_pandas(time_col="ts", time_as_pd_timestamps=True).set_index("ts").sort_index()
        if len(ts.columns) != 1:
            raise ValueError("RobustStlModel cannot transform a multivariate time series")
        value_col_name = ts.columns[0]
        r = ts.index
        # For any timestamps within the training period, we interpolate the trend value
        trend_ts = self._df.loc[:, "smoothed"]
        t = trend_ts.index
        smoothed = trend_ts.reindex(t.union(r)).interpolate("index").loc[r]
        # For any timestamps after the training period, we extrapolate the trend value
        future_ts = smoothed.loc[trend_ts.index[-1] :]
        if len(future_ts) > 0:
            future_ts = self.extrapolated_trend_component(future_ts.index)
            smoothed.loc[trend_ts.index[-1] :] = future_ts

        if self.seasonality_adjustment == "m":
            ts = ts.div(smoothed, axis="index")
        elif self.seasonality_adjustment == "a":
            ts = ts.sub(smoothed, axis="index")

        # Remove seasonality component
        ts = ts.sub(self.extrapolated_seasonal_component(ts.index), axis="index")

        return TimeIndexedOutput(out=TimeIndexedData.from_pandas(ts, value_col=value_col_name))
