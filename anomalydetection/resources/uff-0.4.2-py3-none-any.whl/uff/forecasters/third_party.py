#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Optional, Protocol, Type, TypeVar, Union

from ..base import Forecaster, decorators
from ..tstypes import (
    ColumnSet,
    FloatTensor,
    TimeIndex,
    TimeIndexedData,
    TimeIndexedOutput,
)

FitRegressorsT = TypeVar("FitRegressorsT")
FitTargetsT = TypeVar("FitTargetsT")
PredictRegressorsT = TypeVar("PredictRegressorsT")

FitDataCallback = Callable[[TimeIndexedData], FitTargetsT]
FitCovariatesCallback = Callable[[TimeIndexedData], FitRegressorsT]
ForecastCovariatesCallback = Callable[[Union[TimeIndex, TimeIndexedData]], PredictRegressorsT]


class Learner(Protocol):
    def fit(self, X: FitRegressorsT, y: FitTargetsT) -> Predictor: ...


class Predictor(Protocol):
    def predict(self, X: PredictRegressorsT) -> FloatTensor: ...


@dataclass
class ThirdPartyRegressorOutput(TimeIndexedOutput):
    """Output for third party regression models

    Attributes
    ----------
    out: TimeIndexedData
        Forecasted point estimates
    """

    out: TimeIndexedData


class ThirdPartyRegressor(Forecaster):
    """Third party regressor UFF interface

    Attributes
    ----------
    model: Union[Predictor, None]
        If fitted, a ThirdPartyRegressor instance `model` property will return the fitted
        third-party regressor.
    """

    @decorators.set_init_attributes(requires_covariates=True)
    def __init__(
        self,
        estimator_class: Type[Learner],
        *args: Any,
        preprocess_fit_data: Optional[FitDataCallback] = None,
        preprocess_fit_covariates: Optional[FitCovariatesCallback] = None,
        preprocess_predict_data: Optional[ForecastCovariatesCallback] = None,
        **kwargs: Any,
    ) -> None:
        """Initialize a third party regression forecaster

        Parameters
        ----------
        estimator_class: Learner
            User defined estimator for forecasting
        preprocess_fit_data: Optional[FitDataCallback], default None
            functions to preprocess target variables for regression model during .fit()
        preprocess_fit_covariates: Optional[FitDataCallback], default None
            functions to preprocess predictor variables for regression model during .fit()
        preprocess_predict_data: Optional[FitDataCallback], default None
            functions to preprocess predictor variables for regression model during .predict()
        """
        self._learner = estimator_class(*args, **kwargs)
        self._model: Union[Predictor, None] = None
        self._fit_data: bool = False
        self._target_name: Optional[ColumnSet] = None

        # Callbacks
        self._prep_fit_data = preprocess_fit_data
        self._prep_fit_covariates = preprocess_fit_covariates
        self._prep_predict = preprocess_predict_data

    @property
    def model(self) -> Union[Predictor, None]:
        return self._model

    @decorators.update_fit_attributes
    def fit(
        self, data: TimeIndexedData, covariates: TimeIndexedData, **kwargs: Any
    ) -> ThirdPartyRegressor:
        """Fit the regression model to the input time series.

        Parameters
        ----------
        data: TimeIndexedData
            The target variable (y) to be modeled.
        covariates: TimeIndexedData
            The regressors (X) to train the forecast model.
        kwargs: Dict[str, Any]
            Passed directly to .fit() of the selected model.

        Returns
        -------
        ThirdPartyRegressor
            self
        """

        y = self._prep_fit_data(data) if self._prep_fit_data else data.values
        X = (
            self._prep_fit_covariates(covariates)
            if self._prep_fit_covariates
            else covariates.values_at_least_2d
        )
        self._model = self._learner.fit(X, y, **kwargs)
        self._fit_data = True
        self._target_names = data.column_names
        return self

    """
    Forecaster methods
    """

    @decorators.check_state_and_input
    def forecast(
        self, data: Union[TimeIndex, TimeIndexedData], **kwargs: Any
    ) -> ThirdPartyRegressorOutput:
        """Use the fitted model to forecast future values

        Parameters
        ----------
        data: TimeIndexedData
            The data to forecast.
        kwargs: Any
            Passed directly to .fit() of the selected model.

        Returns
        -------
        TimeIndexedData
            The forecast result.

        Raises
        ------
        ValueError
            If forecast() is called before fit()
        ValueError
            If TimeIndexed type covariates are expected and not provided
        """
        X = self._prep_predict(data) if self._prep_predict else data.values_at_least_2d
        res = self._model.predict(X, **kwargs)
        index = data if isinstance(data, TimeIndex) else data.time_index

        return ThirdPartyRegressorOutput(
            out=TimeIndexedData.from_time_index(index, res, column_names=self._target_names)
        )
