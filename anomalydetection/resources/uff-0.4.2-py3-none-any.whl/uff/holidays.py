#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from collections import defaultdict
from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd

from .tstypes import TimeIndex, TimeIndexedData
from .utils import hstack


def get_multi_country_holidays(
    index: Union[TimeIndex, TimeIndexedData],
    countries: List[str],
    days_before: Optional[Dict[str, int]] = None,
    days_after: Optional[Dict[str, int]] = None,
    min_t: Optional[pd.Timestamp] = None,
    max_t: Optional[pd.Timestamp] = None,
    **kwargs: Any,
) -> TimeIndexedData:
    """Get holidays for multiple countries as a TimeIndexedData object.

    All holidays for which the intercal [ds - days_before, ds + days_after] intersects with the
    interval [min_t, max_t] will be returned as a matching holiday.

    Parameters
    ----------
    index : Union[TimeIndex, TimeIndexedData]
        The time index for which to get the holidays.
    countries : List[str]
        A list of ISO 3166-1 Alpha-2 country codes.
    days_before: Optional[Dict[str, int]], default None
        Number of days before the holiday to also mark as that holiday.
    days_after: Optional[Dict[str, int]], default None
        Number of days after the holiday to also mark as that holiday.
    min_t: Optional[pd.Timestamp], default None
        The minimum timestamp to consider. If not specified then the minimum timestamp in the index
        will be used.
    max_t: Optional[pd.Timestamp], default None
        The maximum timestamp to consider. If not specified then the maximum timestamp in the index
        will be used.
    **kwargs: Any
        Passed directly to `holidays.country_holidays()`

    Returns
    -------
    TimeIndexedData
        A TimeIndexedData object with the holidays as columns and 1.0 for the holidays and 0.0
        otherwise. The column index is hierarchical with the first level being the country code
        and the second level being the holiday name.
    """
    results = [
        get_country_holidays(
            index=index,
            country=country,
            days_before=days_before,
            days_after=days_after,
            min_t=min_t,
            max_t=max_t,
            **kwargs,
        )
        for country in countries
    ]
    return hstack(results, column_prefixes=countries)


def get_country_holidays(
    index: Union[TimeIndex, TimeIndexedData],
    country: str,
    days_before: Optional[Dict[str, int]] = None,
    days_after: Optional[Dict[str, int]] = None,
    min_t: Optional[pd.Timestamp] = None,
    max_t: Optional[pd.Timestamp] = None,
    **kwargs: Any,
) -> TimeIndexedData:
    """Get country holidays as a TimeIndexedData object.

    All holidays for which the intercal [ds - days_before, ds + days_after] intersects with the
    interval [min_t, max_t] will be returned as a matching holiday.

    Parameters
    ----------
    index : Union[TimeIndex, TimeIndexedData]
        The time index for which to get the holidays.
    country : str
        An ISO 3166-1 Alpha-2 country code.
    days_before: Optional[Dict[str, int]], default None
        Number of days before the holiday to also mark as that holiday.
    days_after: Optional[Dict[str, int]], default None
        Number of days after the holiday to also mark as that holiday.
    min_t: Optional[pd.Timestamp], default None
        The minimum timestamp to consider. If not specified then the minimum timestamp in the index
        will be used.
    max_t: Optional[pd.Timestamp], default None
        The maximum timestamp to consider. If not specified then the maximum timestamp in the index
        will be used.
    **kwargs: Any
        Passed directly to `holidays.country_holidays()`

    Returns
    -------
    TimeIndexedData
        A TimeIndexedData object with the holidays as columns and 1.0 for the holidays and 0.0
        otherwise.
    """
    import holidays

    index = index if isinstance(index, TimeIndex) else index.time_index

    if len(index) == 0 and (min_t is None or max_t is None):
        return TimeIndexedData.from_time_index(index, np.zeros((0, 0)), column_names=[])

    days_before = days_before or {}
    days_after = days_after or {}
    min_t = index.first_timestamp() if min_t is None else min_t
    max_t = index.last_timestamp() if max_t is None else max_t
    min_date = min_t.date()
    max_date = max_t.date()

    date_to_name = holidays.country_holidays(
        country, years=range(min_t.year - 1, max_t.year + 1), **kwargs
    )
    date_to_name_set = defaultdict(set)
    for ds, name in date_to_name.items():
        date_to_name_set[ds].add(name)
        if name in days_before:
            for i in range(1, days_before[name] + 1):
                ds_before = ds - pd.Timedelta(days=i)
                date_to_name_set[ds_before].add(name)
        if name in days_after:
            for i in range(1, days_after[name] + 1):
                ds_after = ds + pd.Timedelta(days=i)
                date_to_name_set[ds_after].add(name)

    date_to_name_set = {
        ds: names for ds, names in date_to_name_set.items() if min_date <= ds <= max_date
    }
    sorted_holidays = sorted(set.union(*date_to_name_set.values()))
    name_to_j = {name: j for j, name in enumerate(sorted_holidays)}
    values = np.zeros((len(index), len(sorted_holidays)), dtype=float)

    for i, ts in enumerate(index.timestamp_values):
        for name in date_to_name_set.get(ts.date(), []):
            j = name_to_j[name]
            values[i, j] = 1.0

    return TimeIndexedData.from_time_index(index, values, column_names=sorted_holidays)
