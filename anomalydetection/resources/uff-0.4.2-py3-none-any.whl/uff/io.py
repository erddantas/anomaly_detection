#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

import io
import json
import os
import shutil
import zipfile
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Iterable, List, Type, Union

from .base import Estimator
from .utils import get_estimator


def _to_str(path: Union[str, Path]) -> str:
    if isinstance(path, Path):
        return str(path.resolve())
    return path


def cloudpickle_dump(*args, **kwargs):
    """An alias for import cloudpickle; cloudpickle.dump(*args, **kwargs)"""
    import cloudpickle

    cloudpickle.dump(*args, **kwargs)


def cloudpickle_load(*args, **kwargs):
    """An alias for import cloudpickle; cloudpickle.load(*args, **kwargs)"""
    import cloudpickle

    return cloudpickle.load(*args, **kwargs)


def save(estimator: Estimator, path: Union[str, Path]) -> None:
    """Save an Estimator to a single output location.

    If a standard UFF Estiamtor class is used, then it will be serialized with .save(). Any
    unrecognized classes will be serialized with cloudpickle.

    Parameters
    ----------
    estimators: Estimator
        An Estimator to save
    path: Union[str, Path]
        The name of the output file to create
    """
    save_multiple([estimator], path)


def load(path: Union[str, Path]) -> List[Estimator]:
    """Load a serialized estimator

    This function assumes that the file is a zip archive created by `uff.io.save()`

    Parameters
    ----------
    path: Union[str, Path]
        The name of the input file

    Returns
    -------
    Estimator
        A deserialized estimator
    """
    return load_multiple(path)[0]


def save_multiple(estimators: Iterable[Estimator], path: Union[str, Path]) -> None:
    """Save multiple estimators to a single output location.

    If standard UFF Estiamtor classes are used, then they are individually serialized with .save().
    Any unrecognized classes are serialized with cloudpickle. Once individual models have been
    serialized, a single zip archive is created and given the name `path`.

    Parameters
    ----------
    estimators: Iterable[Estimator]
        The estimators to save
    path: Union[str, Path]
        The name of the output file to create
    """
    path = _to_str(path)

    tempdir = TemporaryDirectory()
    prefix = Path(tempdir.name)
    for i, estimator in enumerate(estimators):
        estimator_file = str(Path(prefix) / f"estimator_{i}")
        type_e = type(estimator)
        _save_estimator(estimator, estimator_file)
        with open(str(Path(prefix) / f"name_{i}"), "w") as f:
            name = type_e.__name__ if _is_recoverable_by_name(type_e) else None
            json.dump(name, f)

    create_archive(tempdir.name, path)


def load_multiple(path: Union[str, Path]) -> List[Estimator]:
    """Load multiple estimators stored in a single output file.

    This function assumes that the file is a zip archive created by `save_multiple()`

    Parameters
    ----------
    path: Union[str, Path]
        The name of the input file

    Returns
    -------
    List[Estimator]
        A collection of deserialized estimators
    """
    path = _to_str(path)

    unpack_dir = TemporaryDirectory()
    unpack_path = Path(unpack_dir.name)
    unpack_archive(path, str(unpack_path))

    res = []
    i = 0
    while True:
        fname = str(unpack_path / f"name_{i}")
        if os.path.isfile(fname):
            with open(fname, "r") as f:
                class_name = json.load(f)
            res.append(_load_estimator(class_name, str(unpack_path / f"estimator_{i}")))
            i += 1
        else:
            break
    return res


def create_archive(dir_name: str, destination: str) -> None:
    archive_dir = TemporaryDirectory()
    archive_name = str(Path(archive_dir.name) / "archive.zip")

    dir_path = Path(dir_name)

    with zipfile.ZipFile(archive_name, "w", zipfile.ZIP_DEFLATED) as zip_file:
        for entry in dir_path.rglob("*"):
            zip_file.write(entry, entry.relative_to(dir_path))

    shutil.move(archive_name, destination)


def unpack_archive(path: str, output_dir: str) -> None:
    with open(path, "rb") as f:
        buf = io.BytesIO(f.read())
        with zipfile.ZipFile(buf) as zipf:
            zipf.extractall(output_dir)


def _save_estimator(estimator: Estimator, path: str):
    if _is_recoverable_by_name(type(estimator)):
        estimator.save(path)
    else:
        with open(path, "wb") as f:
            cloudpickle_dump(estimator, f)


def _load_estimator(class_name: Union[str, None], path: str) -> Estimator:
    if class_name is not None:
        return get_estimator(class_name).load(path)

    with Path(path).open("rb") as f:
        return cloudpickle_load(f)


def _is_recoverable_by_name(est_class: Type) -> bool:
    try:
        return get_estimator(est_class.__name__) == est_class
    except KeyError:
        return False
