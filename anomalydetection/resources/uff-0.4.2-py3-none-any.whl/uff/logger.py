#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import logging
import warnings
from contextlib import contextmanager

__LOGGER: logging.Logger = logging.getLogger("uff")
__RAISE_WARNINGS: bool = True


def get_logger() -> logging.Logger:
    """Get a reference to the global UFF logger object"""
    return __LOGGER


def set_level(level: int) -> None:
    """Set the logging level

    Parameters
    ----------
    level: int
        The logger level. Can also be consts like logging.INFO, logging.DEBUG, etc.
    """
    get_logger().setLevel(level)


def warning(msg: str) -> None:
    """Log a warning message

    Log warnings should be used if there is nothing the client application can do about the
    situation, but the event should still be noted. If the client application can be modified to
    eliminate the warning, then `raise_warning` should be used instead.

    Parameters
    ----------
    msg: str
        The warning message
    """
    get_logger().warning(msg)


def info(msg: str) -> None:
    """Log an info message

    Parameters
    ----------
    msg: str
        The informational message
    """
    get_logger().info(msg)


@contextmanager
def route_raised_warnings_to_logger() -> None:
    """While enclosed, route warnings to logger.warning() instead of warnings.warn()"""
    global __RAISE_WARNINGS
    old_snapshot = __RAISE_WARNINGS
    __RAISE_WARNINGS = False

    try:
        yield
    finally:
        __RAISE_WARNINGS = old_snapshot


def raise_warning(msg: str) -> None:
    """Raise a warning via the `warnings` module

    If the global state `route_raise_warnings_to_logger()` was previously set to True, then the
    message will instead be routed to logger.wwarning().

    `raise_warning` should be used if the client application can be modified to eliminate the
    warning. If there is nothing the client appliation can do, then `warning` should be used
    instead.

    Parameters
    ----------
    msg: str
        The warning message
    """
    if __RAISE_WARNINGS:
        warnings.warn(msg)
    else:
        warning(msg)
