#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

from functools import update_wrapper, wraps
from types import MethodType
from typing import Any, Dict, Iterable, Optional, Set, Tuple, Type, Union

from ..base import (
    Estimator,
    FeatureSelector,
    Forecaster,
    ForecasterWithInterval,
    Incremental,
    InitializationSpec,
    ReversibleTransformer,
    Transformer,
)
from ..tstypes import TimeIndex, TimeIndexedData, TimeIndexedOutput

__all__ = [
    "EstimatorSpecification",
    "MetaEstimator",
    "create_estimator_instance",
]


EstimatorSpecification = Union[Dict, InitializationSpec, Estimator]


def create_estimator_instance(
    obj: EstimatorSpecification,
    exp_class: Optional[Union[Type, Tuple[Type, ...]]] = None,
) -> Estimator:
    """Create a fresh instance of an Estimator from a specification

    Parameters
    ----------
    obj: EstimatorSpecification
        A dictionary, InitializationSpec, or Estimator object.
    exp_class: Optional[Union[Type, Tuple[Type, ...]] default None
        A set of types or mixins that the resulting Estimator should have. If multiple classes
        are provided then the resulting Estimator must implement at least one of the class
        interfaces.

    Returns
    -------
    Estimator
        An instance of an Estimator. If an Estimator is provided as input, the result is a new
        instance of the estimator with the same parameters, not a copy of the input.
    """
    res = None
    if isinstance(obj, dict):
        res = InitializationSpec.from_dict(obj).create_instance()
    if isinstance(obj, InitializationSpec):
        res = obj.create_instance()
    if isinstance(obj, Estimator):
        res = obj.params.create_instance()

    if exp_class is None:
        exp_class_tup = tuple()
    elif not isinstance(exp_class, tuple):
        exp_class_tup = (exp_class,)
    else:
        exp_class_tup = exp_class

    if res is None:
        raise ValueError(f"Could not parse. Expected dict, Estimtor or InitializationSpec: {obj}")
    if len(exp_class_tup) > 0:
        if isinstance(res, MetaEstimator):
            if not any([cls in res.mixins() for cls in exp_class_tup]):
                raise ValueError(
                    f"Expected {exp_class}, received MetaEstimator without the proper mixin {res}"
                )
        elif not isinstance(res, exp_class_tup):
            raise ValueError(f"Expected {exp_class}, received {res}")

    return res


def get_type_check(objs: Iterable[EstimatorSpecification]) -> Dict[Type, bool]:
    """Return a set of mixins from a collection of Estimator specifications

    Parameters
    ----------
    objs: Iterable[Union[Dict, InitializationSpec, Estimator]]
        A collection of Estimator specifications. Dictionaries are assumed to be valid
        InitializationSpecs

    Returns
    -------
    Dict[Type, bool]
        True if all `objs` are instances of `key`. keys are Forecaster, ForecasterWithInterval,
        Transformer, ReversibleTransformer, Incremental
    """
    mixins = (
        Forecaster,
        ForecasterWithInterval,
        Transformer,
        ReversibleTransformer,
        FeatureSelector,
        Incremental,
    )
    type_check = {mixin: True for mixin in mixins}
    for obj in objs:
        estimator = create_estimator_instance(obj)
        for mixin in mixins:
            if isinstance(estimator, MetaEstimator):
                if mixin not in estimator.mixins():
                    type_check[mixin] = False
            elif not isinstance(estimator, mixin):
                type_check[mixin] = False

    return type_check


def get_mixins(objs: Iterable[EstimatorSpecification]) -> Set[Type]:
    """Return a set of mixins from a collection of Estimator specifications

    Parameters
    ----------
    objs: Iterable[Union[Dict, InitializationSpec, Estimator]]
        A collection of Estimator specifications. Dictionaries are assumed to be valid
        InitializationSpecs

    Returns
    -------
    Set[Type]
        A set of learning & prediction mixins from base

    Raises
    ------
    ValueError
        If a single prediction mixin (Forecaster or Transformer but not both) cannot be
        determined from the input. If base estimators are Forecaster instances which do not
        inherit from BatchEstimator or OnlineEstimator
    """
    type_check = get_type_check(objs)
    return {mixin for mixin in type_check if type_check[mixin]}


class _AvailableIfDescriptor:
    """Implements a conditional property using the descriptor protocol.

    Using this class to create a decorator will raise an `AttributeError` if check(self) returns
    a falsey value. Note that if check raises an error this will also result in hasattr returning
    false.

    See https://docs.python.org/3/howto/descriptor.html for an explanation of descriptors.
    """

    def __init__(self, fn, check, attribute_name):
        self.fn = fn
        self.check = check
        self.attribute_name = attribute_name
        update_wrapper(self, fn)

    def __get__(self, obj, owner=None):
        attr_err = AttributeError(
            f"This {repr(owner.__name__)} has no attribute {repr(self.attribute_name)}"
        )
        if obj is not None:
            if not self.check(obj):
                raise attr_err
            out = MethodType(self.fn, obj)

        else:

            @wraps(self.fn)
            def out(*args, **kwargs):
                if not self.check(args[0]):
                    raise attr_err
                return self.fn(*args, **kwargs)

        return out


def available_if(check):
    """An attribute that is available only if check returns a truthy value."""
    return lambda fn: _AvailableIfDescriptor(fn, check, attribute_name=fn.__name__)


class MetaEstimator(Estimator):
    """Base class for all meta-estimators

    Meta-estimators are Estimators which accept other Estimators as initialization parameters.
    One example is ColumnEnsembleEstimator which applies estimators independently to all columns
    in a `TimeIndexedData` object.

    MetaEstimators themselves are not instances of Forecaster, or Transformer. Instead, they
    propagate the methods ofthe estimators used to construct the instance. E.g. a
    ColumnEnsembleEstimator initialized with a Forecaster object will also implement a
    `forecast()` method.

    All MetaEstiamtors provide the public property `.mixins()` which describes the end-to-end
    behavior of the MetaEstimator. For example a ColumnEnsembleEstimator(ProphetForecaster())
    would have `model.mixin()s == {uff.base.Forecaster, uff.base.ForecasterWithInterval}`
    """

    # Available only if ForecasterWithInterval is present in mixins
    __MetaEstimator_prediction_interval_width: Optional[float] = None

    def mixins(self) -> Set[Type]:
        # A set of mixins describing the end-to-end behavior of the MetaEstimator
        raise NotImplementedError()

    def _set_init_attributes_from_wrapped_estimator(self, estimator: Estimator) -> None:
        """Set the init attributes of a MetaEstimator from an underlying Estimator"""
        self.requires_fit = estimator.requires_fit
        self.requires_covariates = estimator.requires_covariates
        self.ray_serializable = estimator.ray_serializable
        self.joblib_serializable = estimator.joblib_serializable
        if estimator.is_forecaster_with_interval():
            self.prediction_interval_width = estimator.prediction_interval_width

    @property
    def prediction_interval_width(self) -> float:
        if ForecasterWithInterval not in self.mixins():
            raise AttributeError(
                "MetaEstimator does not implement ForecasterWithInterval interface. "
                "'prediction_interval_width' attribute not found."
            )

        if self.__MetaEstimator_prediction_interval_width is None:
            raise RuntimeError(
                "MetaEstimator has not properly set `prediction_interval_width` attribute."
            )
        return self.__MetaEstimator_prediction_interval_width

    @prediction_interval_width.setter
    def prediction_interval_width(self, value: float) -> None:
        if self.is_fit:
            raise RuntimeError(
                "prediction_interval_width cannot be changed after an estimator is fit."
            )
        self.__MetaEstimator_prediction_interval_width = value

    def fit(
        self,
        data: TimeIndexedData,
        covariates: Optional[TimeIndexedData] = None,
        **kwargs: Any,
    ) -> MetaEstimator:
        raise NotImplementedError()

    def _partial_fit(
        self,
        data: Union[TimeIndex, TimeIndexedData],
        covariates: Optional[TimeIndexedData] = None,
        **kwargs: Any,
    ) -> MetaEstimator:
        raise NotImplementedError()

    def _forecast(
        self,
        data: Union[TimeIndexedData, TimeIndex],
        **kwargs: Any,
    ) -> TimeIndexedOutput:
        raise NotImplementedError()

    def _transform(
        self,
        data: TimeIndexedData,
        **kwargs: Any,
    ) -> TimeIndexedOutput:
        raise NotImplementedError()

    def _inverse_transform(
        self,
        data: TimeIndexedData,
        **kwargs: Any,
    ) -> TimeIndexedOutput:
        raise NotImplementedError()

    def _transform_covariates(
        self,
        data: TimeIndexedData,
        **kwargs: Any,
    ) -> TimeIndexedOutput:
        raise NotImplementedError()

    def is_incremental(self) -> bool:
        return Incremental in self.mixins()

    def is_forecaster(self) -> bool:
        return Forecaster in self.mixins() or ForecasterWithInterval in self.mixins()

    def is_forecaster_with_interval(self) -> bool:
        return ForecasterWithInterval in self.mixins()

    def is_transformer(self) -> bool:
        return Transformer in self.mixins()

    def is_reversible_transformer(self) -> bool:
        return ReversibleTransformer in self.mixins()

    def is_feature_selector(self) -> bool:
        return FeatureSelector in self.mixins()

    @available_if(is_incremental)
    def partial_fit(
        self,
        data: TimeIndexedData,
        covariates: Optional[TimeIndexedData] = None,
        **kwargs: Any,
    ) -> MetaEstimator:
        return self._partial_fit(data, covariate=covariates, **kwargs)

    @available_if(is_forecaster)
    def forecast(self, data: Union[TimeIndexedData, TimeIndex], **kwargs: Any) -> TimeIndexedOutput:
        return self._forecast(data, **kwargs)

    @available_if(is_transformer)
    def transform(self, data: TimeIndexedData, **kwargs: Any) -> TimeIndexedOutput:
        return self._transform(data, **kwargs)

    @available_if(is_reversible_transformer)
    def inverse_transform(self, data: TimeIndexedData, **kwargs: Any) -> TimeIndexedOutput:
        return self._inverse_transform(data, **kwargs)

    @available_if(is_feature_selector)
    def transform_covariates(self, data: TimeIndexedData, **kwargs: Any) -> TimeIndexedOutput:
        return self._transform_covariates(data, **kwargs)
