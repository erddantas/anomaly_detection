#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

import os
import uuid
from dataclasses import dataclass
from functools import partial
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any, Dict, List, Optional, Set, Tuple, Type, Union

import numpy as np

from .. import io
from ..base import (
    Estimator,
    Forecaster,
    ForecasterWithInterval,
    Incremental,
    InitializationSpec,
    Transformer,
    decorators,
)
from ..distributed import conditional_distributed_evaluate, current_backend
from ..tstypes import (
    ColumnPath,
    ColumnType,
    TimeIndex,
    TimeIndexedData,
    TimeIndexedOutput,
    TimeIndexedOutputWithInterval,
)
from ..utils import deterministic_rng, hstack, random_seed
from .base import (
    EstimatorSpecification,
    MetaEstimator,
    create_estimator_instance,
    get_type_check,
)


class _NotFittedMarker(Forecaster, Incremental):
    @decorators.set_init_attributes(requires_fit=False, requires_covariates=False)
    def __init__(self, model: Estimator, data: TimeIndexedData) -> None:
        self._fit_cols = data.column_tuples
        self._fit_shape = data.shape[1:]
        self._pred_width = None
        if isinstance(model, ForecasterWithInterval):
            self._pred_width = model.prediction_interval_width

    def _empty_result(self, index: TimeIndex) -> TimeIndexedData:
        nans = np.empty((len(index),) + self._fit_shape)
        nans[:] = np.nan
        return TimeIndexedData.from_time_index(index, nans, column_names=self._fit_cols)

    @decorators.update_fit_attributes
    def partial_fit(
        self, data: TimeIndexedData, covariates: Optional[TimeIndexedData] = None, **kwargs
    ) -> Estimator:
        return self

    @decorators.check_state_and_input
    def forecast(
        self,
        data: Union[TimeIndex, TimeIndexedData],
        **kwargs: Dict[str, Any],
    ) -> TimeIndexedOutput:
        index = data if isinstance(data, TimeIndex) else data.time_index
        if self._pred_width is not None:
            return TimeIndexedOutputWithInterval(
                out=self._empty_result(index),
                upper=self._empty_result(index),
                lower=self._empty_result(index),
                interval_width=self._pred_width,
            )
        else:
            return TimeIndexedOutput(out=self._empty_result(index))


def _gen_unique_filename(prefix: Path) -> Path:
    directory = prefix / ".uff"
    if not directory.exists():
        directory.mkdir(parents=True, exist_ok=True)

    return directory / uuid.uuid4().hex


def _model_or_path(
    model: Estimator, backend: Optional[str], prefix: Optional[Path]
) -> Union[Estimator, Path]:
    if prefix is None or backend is None:
        return model

    if (backend == "ray" and not model.ray_serializable) or (
        backend == "joblib" and not model.joblib_serializable
    ):
        path = _gen_unique_filename(prefix)
        io.save(model, path)
        return path

    return model


@dataclass
class ColumnEnsembleOutput(TimeIndexedOutput):
    out: TimeIndexedData
    column_output: List[TimeIndexedOutput]


@dataclass
class ColumnEnsembleWithIntervalOutput(TimeIndexedOutputWithInterval):
    out: TimeIndexedData
    upper: TimeIndexedData
    lower: TimeIndexedData
    interval_width: float
    column_output: List[TimeIndexedOutputWithInterval]


class ColumnEnsembleEstimator(MetaEstimator):
    """A MetaEstimator which applies the same Estimator to all columns in a TimeIndexedData object.

    Individual column models are trainied completely independently. If `covariates` is specified,
    then it will be applied equally to all models.

    When inferring `mixins(self)`, ColumnEnsembleEstimator will reduce `estimator` and
    `column_specific_estimators` using `all()`. I.e. `ForecasterWithInterval in ensemble.mixins()`
    will return `True` if all of the provided estimators are instances of `ForecasterWithInterval`.
    """

    min_distribution_size: int = 30

    @decorators.set_init_attributes
    def __init__(
        self,
        estimator: EstimatorSpecification,
        dropna: bool = True,
        column_specific_estimators: Optional[Dict[ColumnPath, EstimatorSpecification]] = None,
        column_subset_estimators: Optional[Dict[str, EstimatorSpecification]] = None,
        cache_dir: Optional[Union[Path, str]] = None,
        permissive: bool = False,
    ) -> None:
        """Initialize a ColumnEnsembleEstimator

        Parameters
        ----------
        estimator: EstimatorSpecification
            The estimator specification that should be applied to all columns
        dropna: bool, default True
            If True, NaN entries will be dropped from the individual data columns before calling
            `fit()` or `partial_fit()`. NaN entries will not be dropped during `forecast()`
            `transform()` or `inverse_transform()` in order to guarantee that the `TimeIndex`
            passed in to the prediction method matches the `TimeIndex` in the result.
        column_specific_estimators: Optional[Dict[ColumnPath, EstimatorSpecification]], default None
            If column names are known ahead of time, `column_specific_estimators` can be used to
            specify different Estimators that should be trained on specific columns. Any columns
            not found in `column_specific_estimators` will be passed through the default `estimator`
        column_subset_estimators: Optional[Dict[str, EstimatorSpecification]], default None
            A dictionary mapping valid query strings to EstimatorSpecifications. The query strings
            will be used to filter column subsets of the `data` argument during `fit()` and / or
            `partial_fit()`. If there are any `column_specific_estimators` specified, those will
            take precedence over `column_subset_estimators`. If columns match multiple conditions,
            then the order of the queries will be used to disambiguate, similar to a SQL case
            statement. If a column is not found in either `column_specific_estimators` or
            `column_subset_estimators`, then the default `estimator` will be used.
        cache_dir: Optional[Union[Path, str]], default None
            If specified, this will be treated as the prefix of a cache directory that can be
            used as a storage location for unserializable models. This can be helpful if
            `ColumnEnsembleEstimator` (1) is being fit / evaluated in a distributed context and
            (2) it contains Estimators which cannot be serialized automatically by `ray` or
            `joblib`. A unique directory {cache_dir}/.uff will be created in the event of a
            serialization error and used throughout the Estimators lifetime to store
            unserializable univariate models. If the parallelization backend allows tasks to run
            on different hardward, then `cache_dir` should reference a location in a distributed
            file system that is accessible by all workers.
        permissive: bool, default False
            Only applicable to Forecasters. If True, then the estimator will not raise an error
            if an individual column-specific estimator experiences an error during .fit() or
            .partial_fit(). Instead, the estimator will mark the column as skipped and any
            subsequent calls to .forecast() will return NaN for that column. If False, then the
            estimator will not ignore any column-specific errors.
        """
        type_check = get_type_check([estimator] + list((column_specific_estimators or {}).values()))

        if type_check[Forecaster] == type_check[Transformer]:
            received = "both" if type_check[Forecaster] else "neither"
            raise ValueError(f"Expected Forecaster or Transformer, received {received}")

        self._mixins = {mixin for mixin in type_check if type_check[mixin]}

        self._permissive = permissive

        self._default_estimator: Estimator = create_estimator_instance(estimator)
        self._column_specific_estimators: Dict[Tuple[ColumnType], Estimator] = {
            k if isinstance(k, tuple) else (k,): create_estimator_instance(v)
            for k, v in (column_specific_estimators or {}).items()
        }

        # Initialize estimators and state tracking for column subsets
        self._column_subset_estimators: Dict[str, Estimator] = {
            k: create_estimator_instance(v) for k, v in (column_subset_estimators or {}).items()
        }
        self._all_models_have_been_initialized: bool = False

        self._cache_dir_prefix: Optional[Path] = None
        if cache_dir is not None:
            cache_dir = Path(cache_dir)
            if os.access(str(cache_dir.resolve()), os.W_OK):
                self._cache_dir_prefix = cache_dir
            else:
                raise FileNotFoundError(f"{cache_dir} does not exist or is not writeable.")

        prediction_interval_width = None
        all_estimators = [self._default_estimator] + list(self._column_specific_estimators.values())

        if self.is_forecaster_with_interval():
            for est in all_estimators:
                width = est.prediction_interval_width
                if prediction_interval_width is None:
                    prediction_interval_width = width
                elif not np.isclose(width, prediction_interval_width):
                    raise ValueError(
                        "ForecasterWithInterval estimators are expected to have the same "
                        "prediction interval width"
                    )

        if prediction_interval_width is not None:
            self.prediction_interval_width = prediction_interval_width

        self.models: Dict[Tuple[ColumnType], Estimator] = {}
        self.ordered_columns: Optional[Tuple[ColumnType]] = None
        self.dropna = dropna
        # Column ensemble forecasting always requires fit
        self.requires_fit = any(est.requires_fit or est.is_forecaster() for est in all_estimators)
        self.requires_covariates = any(est.requires_covariates for est in all_estimators)
        self.ray_serializable = all(est.ray_serializable for est in all_estimators)
        self.joblib_serializable = all(est.joblib_serializable for est in all_estimators)

    def _instantiate_estimators_and_update_state(self, data: TimeIndexedData) -> None:
        if self._all_models_have_been_initialized:
            raise RuntimeError("Column specific estimators have already been initialized")

        # Resolve queries into column specific estimators now that we know the column names
        for query, est in self._column_subset_estimators.items():
            selected_columns: List[Tuple[ColumnType]] = data.get_matching_columns(query)
            for col in selected_columns:
                if col not in self._column_specific_estimators:
                    self._column_specific_estimators[col] = est

        # Initialize the models
        self.ordered_columns = data.column_tuples
        self.models = {}
        for c in self.ordered_columns:
            base = self._column_specific_estimators.get(c, self._default_estimator)
            self.models[c] = base.params.create_instance()

        # Update state
        self._all_models_have_been_initialized = True

    @property
    def models_have_been_initialized(self) -> bool:
        return self._all_models_have_been_initialized

    """
    Required methods for MetaEstimator
    """

    def mixins(self) -> Set[Type]:
        # A set of mixins present in the base estimator(s)
        return set(self._mixins)

    def is_feature_selector(self) -> bool:
        return False

    @decorators.update_fit_attributes
    def fit(
        self,
        data: TimeIndexedData,
        covariates: Optional[TimeIndexedData] = None,
        **kwargs: Any,
    ) -> MetaEstimator:
        return self._train(data, covariates, partial_fit=False, **kwargs)

    @decorators.update_fit_attributes
    def _partial_fit(
        self,
        data: TimeIndexedData,
        covariates: Optional[TimeIndexedData] = None,
        **kwargs: Any,
    ) -> MetaEstimator:
        return self._train(data, covariates, partial_fit=True, **kwargs)

    def _train(
        self,
        data: TimeIndexedData,
        covariates: Optional[TimeIndexedData] = None,
        partial_fit: bool = False,
        **kwargs: Any,
    ) -> MetaEstimator:
        if not self.models_have_been_initialized:
            self._instantiate_estimators_and_update_state(data)

        column_tuples = data.column_tuples
        tasks = []
        for col in column_tuples:
            selection = data[[col]]
            selected_covs = covariates

            if self.dropna:
                matrix = selection.values_at_least_2d
                is_nan = np.isnan(matrix).max(axis=tuple(range(1, matrix.ndim)))
                selection = selection.mask(~is_nan)
                if selected_covs is not None:
                    selected_covs = selected_covs.mask(~is_nan)

            tasks.append(
                partial(
                    self._fit_one,
                    random_seed(),
                    self.models[col].params,
                    selection,
                    selected_covs,
                    partial_fit=partial_fit,
                    cache_dir=self._cache_dir_prefix,
                    permissive=self._permissive,
                    backend=current_backend(),
                    **kwargs,
                )
            )

        results = conditional_distributed_evaluate(
            tasks, distribution_checks=len(column_tuples) >= self.min_distribution_size
        )

        for col, res in zip(column_tuples, results):
            self.models[col] = res if isinstance(res, Estimator) else io.load(res)

        return self

    @staticmethod
    def _fit_one(
        seed: int,
        estimator: InitializationSpec,
        data: TimeIndexedData,
        covariates: Optional[TimeIndexedData] = None,
        partial_fit: bool = False,
        cache_dir: Optional[Path] = None,
        permissive: bool = False,
        backend: Optional[str] = None,
        **kwargs: Any,
    ) -> Union[Estimator, Path]:
        estimator = estimator.create_instance()
        with deterministic_rng(seed):
            try:
                if partial_fit:
                    estimator.partial_fit(data, covariates, **kwargs)
                else:
                    estimator.fit(data, covariates, **kwargs)
            except (AssertionError, ValueError, TypeError, ArithmeticError, LookupError) as e:
                if permissive and estimator.is_forecaster():
                    # Return a marker that the column was skipped
                    return _model_or_path(
                        _NotFittedMarker(estimator, data), backend=backend, prefix=cache_dir
                    )
                elif permissive:
                    raise ValueError(
                        "`permissive` ColumnEnsembleEstimator behavior can only be used with "
                        "Forecasters. The following error was encountered fitting"
                        f" column(s) {data.column_names}:\n{e}"
                    )
                else:
                    raise e

        return _model_or_path(estimator, backend=backend, prefix=cache_dir)

    @decorators.check_state_and_input
    def _forecast(
        self,
        data: Union[TimeIndexedData, TimeIndex],
        **kwargs: Any,
    ) -> TimeIndexedOutput:
        results = conditional_distributed_evaluate(
            [
                partial(
                    self._predict_one,
                    random_seed(),
                    "forecast",
                    _model_or_path(
                        self.models[col],
                        backend=current_backend(),
                        prefix=self._cache_dir_prefix,
                    ),
                    data,
                    **kwargs,
                )
                for col in self.ordered_columns
            ],
            distribution_checks=len(self.ordered_columns) >= self.min_distribution_size,
        )
        if all(isinstance(r, TimeIndexedOutputWithInterval) for r in results):
            return ColumnEnsembleWithIntervalOutput(
                out=hstack([r.out for r in results]),
                upper=hstack([r.upper for r in results]),
                lower=hstack([r.lower for r in results]),
                interval_width=results[0].interval_width,
                column_output=results,
            )
        return ColumnEnsembleOutput(
            out=hstack([r.out for r in results]),
            column_output=results,
        )

    @decorators.check_state_and_input
    def _transform(
        self,
        data: TimeIndexedData,
        **kwargs: Any,
    ) -> TimeIndexedOutput:
        return self._transform_impl(data, "transform", **kwargs)

    @decorators.check_state_and_input
    def _inverse_transform(
        self,
        data: TimeIndexedData,
        **kwargs: Any,
    ) -> TimeIndexedData:
        return self._transform_impl(data, "inverse_transform", **kwargs)

    def _transform_impl(self, data: TimeIndexedData, mode: str, **kwargs: Any) -> TimeIndexedOutput:
        if not self.models_have_been_initialized:
            self._instantiate_estimators_and_update_state(data)

        results = conditional_distributed_evaluate(
            [
                partial(
                    self._predict_one,
                    random_seed(),
                    mode,
                    _model_or_path(
                        self.models[col],
                        backend=current_backend(),
                        prefix=self._cache_dir_prefix,
                    ),
                    data[[col]],
                    **kwargs,
                )
                for col in self.ordered_columns
            ],
            distribution_checks=len(self.ordered_columns) >= self.min_distribution_size,
        )

        return ColumnEnsembleOutput(
            out=hstack([r.out for r in results]),
            column_output=results,
        )

    @staticmethod
    def _predict_one(
        seed: int,
        mode: str,
        estimator: Union[Estimator, Path],
        data: Union[TimeIndex, TimeIndexedData],
        **kwargs: Any,
    ) -> TimeIndexedOutput:
        if isinstance(estimator, Path):
            estimator = io.load(estimator)
        with deterministic_rng(seed):
            if mode == "forecast":
                return estimator.forecast(data, **kwargs)
            elif mode == "transform":
                return estimator.transform(data, **kwargs)
            elif mode == "inverse_transform":
                return estimator.inverse_transform(data, **kwargs)
            else:
                raise ValueError(f"Invalid mode '{mode}'")

    """
    Required Methods for Estimator
    """

    def save(self, path: str) -> None:
        """Persist this estimator at the location specified by `path`

        If standard UFF Estimator classes are used, then they are individually serialized with
        .save(). Any unrecognized classes are serialized with cloudpickle. Once individual models
        and ensemble-specific parameters have been serialized, a single zip archive is created and
        given the name `path`.

        Parameters
        ----------
        path: str
            A path to the serialized Estimator's output destination.
        """
        tempdir = TemporaryDirectory()
        prefix = Path(tempdir.name)

        override_columns = list(self._column_specific_estimators.keys())
        override_queries = list(self._column_subset_estimators.keys())

        # Save params
        json_data = {
            # Universal params
            "dropna": self.dropna,
            "default_estimator_name": type(self._default_estimator).__name__,
            "cache_dir": self._cache_dir_prefix,
            "permissive": self._permissive,
            # Column specific overrides
            "override_columns": override_columns,
            "override_queries": override_queries,
            # Fitted models
            "fitted_columns": self.ordered_columns,
            # Private state variables
            "_all_models_have_been_initialized": self._all_models_have_been_initialized,
        }
        with (Path(prefix) / "params").open("wb") as f:
            io.cloudpickle_dump(json_data, f)

        io.save_multiple([self._default_estimator], str(prefix / "default_estimator"))
        io.save_multiple(
            [self._column_specific_estimators[c] for c in override_columns],
            str(prefix / "override_estimators"),
        )
        io.save_multiple(
            [self._column_subset_estimators[c] for c in override_queries],
            str(prefix / "override_query_estimators"),
        )
        io.save_multiple(
            [self.models[c] for c in self.ordered_columns or []],
            str(prefix / "fitted_estimators"),
        )

        io.create_archive(str(prefix), path)

    @classmethod
    def load(cls, path: str) -> ColumnEnsembleEstimator:
        """Load a previously saved Estimator instance from `path`

        This is assumed to be a zip archive generated by ColumnEnsembleEstimator.save(). First
        the archive is unpacked and then individual estimators are deserialized. If standard UFF
        Estimators are used, then they are deserialized with Estimator.load(), otherwise they
        are deserialized with cloudpickle.load()

        Parameters
        ----------
        path: str
            A path to the serialized Estimator
        """
        unpack_dir = TemporaryDirectory()
        unpack_path = Path(unpack_dir.name)
        io.unpack_archive(path, str(unpack_path))

        with (unpack_path / "params").open("rb") as f:
            params = io.cloudpickle_load(f)

        default = io.load_multiple(str(unpack_path / "default_estimator"))[0]
        override_estimators = io.load_multiple(str(unpack_path / "override_estimators"))
        override_query_estimators = io.load_multiple(str(unpack_path / "override_query_estimators"))
        fitted_estimators = io.load_multiple(str(unpack_path / "fitted_estimators"))

        instance = cls(
            default,
            dropna=params["dropna"],
            column_specific_estimators={
                c: e for c, e in zip(params["override_columns"], override_estimators)
            },
            column_subset_estimators={
                c: e for c, e in zip(params["override_queries"], override_query_estimators)
            },
            cache_dir=params["cache_dir"],
            permissive=params["permissive"],
        )

        # In-place update of private state variables
        instance._all_models_have_been_initialized = params["_all_models_have_been_initialized"]

        if params["fitted_columns"] is not None:
            instance.ordered_columns = params["fitted_columns"]
            instance.models = {c: e for c, e in zip(params["fitted_columns"], fitted_estimators)}

        return instance
