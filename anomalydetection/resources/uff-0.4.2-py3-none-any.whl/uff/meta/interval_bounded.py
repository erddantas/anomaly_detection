#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any, Dict, Optional, Set, Type, Union

import numpy as np

from .. import io
from ..base import Forecaster, ForecasterWithInterval, decorators
from ..consts import EPSILON
from ..transformers.math import (
    LowerBoundTransformer,
    ScaledLogitTransformer,
    UpperBoundTransformer,
)
from ..tstypes import (
    TimeIndex,
    TimeIndexedData,
    TimeIndexedOutput,
    TimeIndexedOutputWithInterval,
)
from ..utils import clip
from .base import (
    EstimatorSpecification,
    MetaEstimator,
    create_estimator_instance,
    get_type_check,
)


@dataclass
class _UserParams:
    lower: Optional[float]
    upper: Optional[float]
    inclusive: str
    clip_lower: float = field(init=False)
    clip_upper: float = field(init=False)
    transformer: Union[LowerBoundTransformer, ScaledLogitTransformer, UpperBoundTransformer] = (
        field(init=False)
    )

    def __post_init__(self):
        if self.inclusive not in ("neither", "left", "right", "both"):
            raise ValueError(f"Unrecognized `inclusive` value: {self.inclusive}")

        float_lower = -np.inf if self.lower is None else float(self.lower)
        float_upper = np.inf if self.upper is None else float(self.upper)
        lower_specified = np.isfinite(float_lower)
        upper_specified = np.isfinite(float_upper)

        if not (lower_specified or upper_specified):
            raise ValueError(
                "At least one of `upper, lower` should be specified as a finite number."
            )
        if float_lower + (2 * EPSILON) >= float_upper:
            raise ValueError(
                f"`upper` should be at least {2 * EPSILON} larger than `lower`, if specified."
            )

        left_inclusive = self.inclusive in ("both", "left")
        right_inclusive = self.inclusive in ("both", "right")

        # If the interval is not left-inclusive, clip values at lower + epsilon
        # if the interval is not right-inclusive, clip values at upper - epsilon
        self.clip_lower = float_lower + (0 if left_inclusive else EPSILON)
        self.clip_upper = float_upper - (0 if right_inclusive else EPSILON)

        # These must specify an open interval to avoid NaN / inf in the output
        interval_lower = self.clip_lower - EPSILON
        interval_upper = self.clip_upper + EPSILON
        if lower_specified and upper_specified:
            self.transformer = ScaledLogitTransformer(lower=interval_lower, upper=interval_upper)
        elif lower_specified:
            self.transformer = LowerBoundTransformer(lower=interval_lower)
        else:
            self.transformer = UpperBoundTransformer(upper=interval_upper)

    def input_json(self) -> Dict[str, Any]:
        return {"lower": self.lower, "upper": self.upper, "inclusive": self.inclusive}


class IntervalBoundedForecaster(MetaEstimator):
    @decorators.set_init_attributes
    def __init__(
        self,
        forecaster: EstimatorSpecification,
        lower: Optional[float] = None,
        upper: Optional[float] = None,
        inclusive: str = "both",
    ) -> None:
        """Initialize an IntervalBoundedForecaster

        Parameters
        ----------
        forecaster: EstimatorSpecification
            An Estimator, InitializationSpec, or InitializationSpec-compatible dictionary
            specifying a class with the `Forecaster` mixin.
        lower: Optional[float], default None
            The lower bound of the forecasted interval
        upper: Optional[float], default None
            The upper bound of the forecasted interval
        inclusive: str, default "both"
            Describes the inclusivity of the interval. One of "both" for [a, b],
            "left" for [a, b), "right" for (a, b], or "neither" for (a, b)

        Raises
        ------
        ValueError
            If an unrecognized `inclusive` value is provided, or both `lower` and `upper` are
            unspecified / not propertly ordered.
        """
        self._params = _UserParams(lower=lower, upper=upper, inclusive=inclusive)
        self._forecaster: Forecaster = create_estimator_instance(forecaster, Forecaster)

        transformer = self._params.transformer
        type_check = get_type_check([self._forecaster])
        self._mixins = {k for k in type_check if type_check[k]}

        self.requires_fit = self._forecaster.requires_fit
        self.requires_covariates = self._forecaster.requires_covariates
        self.ray_serializable = self._forecaster.ray_serializable and transformer.ray_serializable
        self.joblib_serializable = (
            self._forecaster.joblib_serializable and transformer.joblib_serializable
        )
        if ForecasterWithInterval in self._mixins:
            self.prediction_interval_width = self._forecaster.prediction_interval_width

    """
    Required methods for MetaEstimator
    """

    def mixins(self) -> Set[Type]:
        # A set of mixins present in the base estimator(s)
        return self._mixins

    @decorators.update_fit_attributes
    def fit(
        self,
        data: TimeIndexedData,
        covariates: Optional[TimeIndexedData] = None,
        **kwargs: Any,
    ) -> MetaEstimator:
        return self._train(data, covariates, partial_fit=False, **kwargs)

    @decorators.update_fit_attributes
    def _partial_fit(
        self,
        data: TimeIndexedData,
        covariates: Optional[TimeIndexedData] = None,
        **kwargs: Any,
    ) -> MetaEstimator:
        return self._train(data, covariates, partial_fit=True, **kwargs)

    def _train(
        self,
        data: TimeIndexedData,
        covariates: Optional[TimeIndexedData] = None,
        partial_fit: bool = False,
        **kwargs: Any,
    ) -> MetaEstimator:
        data = self._rescale(data)

        if partial_fit:
            self._forecaster.partial_fit(data, covariates, **kwargs)
        else:
            self._forecaster.fit(data, covariates, **kwargs)

        return self

    def _rescale(self, data: TimeIndexedData) -> TimeIndexedData:
        data = clip(data, self._params.clip_lower, self._params.clip_upper)
        return self._params.transformer.transform(data).out

    def _original_scale(self, data: TimeIndexedData) -> TimeIndexedData:
        data = self._params.transformer.inverse_transform(data).out
        return clip(data, self._params.clip_lower, self._params.clip_upper)

    @decorators.check_state_and_input
    def _forecast(
        self,
        data: Union[TimeIndexedData, TimeIndex],
        **kwargs: Any,
    ) -> TimeIndexedOutput:
        fcst_result = self._forecaster.forecast(data, **kwargs)

        fcst_result.out = self._original_scale(fcst_result.out)
        if isinstance(fcst_result, TimeIndexedOutputWithInterval):
            fcst_result.upper = self._original_scale(fcst_result.upper)
            fcst_result.lower = self._original_scale(fcst_result.lower)

        return fcst_result

    """
    Required Methods for Estimator
    """

    def save(self, path: str) -> None:
        """Persist this estimator at the location specified by `path`

        Parameters
        ----------
        path: str
            A path to the serialized Estimator's output destination.
        """
        tempdir = TemporaryDirectory()
        prefix = Path(tempdir.name)

        with (Path(prefix) / "params").open("wb") as f:
            io.cloudpickle_dump(self._params.input_json(), f)

        io.save(self._forecaster, str(prefix / "forecaster"))
        io.create_archive(str(prefix), path)

    @classmethod
    def load(cls, path: str) -> IntervalBoundedForecaster:
        """Load a previously saved Estimator instance from `path`

        Parameters
        ----------
        path: str
            A path to the serialized Estimator
        """
        unpack_dir = TemporaryDirectory()
        unpack_path = Path(unpack_dir.name)
        io.unpack_archive(path, str(unpack_path))

        with (unpack_path / "params").open("rb") as f:
            params = io.cloudpickle_load(f)

        forecaster = io.load(str(unpack_path / "forecaster"))

        instance = cls(forecaster.params, **params)
        instance._forecaster = forecaster

        return instance
