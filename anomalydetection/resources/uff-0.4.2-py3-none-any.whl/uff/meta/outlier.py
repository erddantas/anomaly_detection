#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any, Optional, Set, Type, Union

import numpy as np
from scipy.spatial import KDTree

from .. import io
from ..base import Estimator, decorators
from ..tstypes import TimeIndex, TimeIndexedData, TimeIndexedOutput
from .base import (
    EstimatorSpecification,
    MetaEstimator,
    create_estimator_instance,
    get_mixins,
)


class OutlierRemovalPreprocessor(MetaEstimator):
    """A MetaEstimator for removing outliers from `data` and `covariates` before passing to `fit()`.

    Outliers are determined based on `data`, and the same indices are removed from `data` and
    `covariates` before fitting the underlying `Estimator`.
    """

    @decorators.set_init_attributes
    def __init__(
        self,
        estimator: EstimatorSpecification,
        contamination: float = 0.01,
    ) -> None:
        """Initialize a OutlierRemovalPreprocessor

        Parameters
        ----------
        estimator: EstimatorSpecification
            An Estimator, InitializationSpec, or InitializationSpec-compatible dictionary
        contamination: float, default=0.01
            The proportion of outliers to remove from the input data. Must be between 0 and 0.5.
        """
        self._estimator = (
            create_estimator_instance(estimator)
            if not isinstance(estimator, Estimator)
            else estimator
        )
        self._mixins = get_mixins([self._estimator])
        self._set_init_attributes_from_wrapped_estimator(self._estimator)
        self._contamination = float(contamination)
        if self._contamination < 0 or self._contamination > 0.5:
            raise ValueError("Contamination must be between 0 and 0.5")

    """
    Required methods for MetaEstimator
    """

    def mixins(self) -> Set[Type]:
        # A set of mixins present in the base estimator(s)
        return set(self._mixins)

    @decorators.update_fit_attributes
    def fit(
        self,
        data: TimeIndexedData,
        covariates: Optional[TimeIndexedData] = None,
        **kwargs: Any,
    ) -> MetaEstimator:
        """Fit the underlying estimator after removing outliers from `data` and `covariates

        Parameters
        ----------
        data: TimeIndexedData
            The input data to fit the estimator. The values in `data` are used to determine
            outliers.
        covariates: Optional[TimeIndexedData]
            The covariates to fit the estimator. If provided, the same outliers are removed from
            `covariates` and `data` before fitting.
        kwargs: Any
            Additional keyword arguments to pass to the underlying estimator's `fit()` method.

        Returns
        -------
        self: MetaEstimator
            The fitted MetaEstimator
        """
        n_inliers = int(len(data) * (1 - self._contamination))
        if n_inliers >= 2 and n_inliers < len(data):
            val2d_or_more = data.values_at_least_2d
            n_rows = val2d_or_more.shape[0]
            val2d = val2d_or_more.reshape((n_rows, val2d_or_more.size // n_rows))

            tree = KDTree(val2d)
            distances, _ = tree.query(val2d, k=3)
            max_dist = np.max(distances, axis=1)
            max_inlier_score = np.sort(max_dist)[n_inliers - 1]
            inlier_mask = max_dist <= max_inlier_score
            data = data.mask(inlier_mask)
            if covariates is not None:
                covariates = covariates.mask(inlier_mask)

        self._estimator.fit(data, covariates, **kwargs)
        return self

    @decorators.check_state_and_input
    def _forecast(
        self,
        data: Union[TimeIndexedData, TimeIndex],
        **kwargs: Any,
    ) -> TimeIndexedOutput:
        return self._estimator.forecast(data, **kwargs)

    @decorators.check_state_and_input
    def _transform(
        self,
        data: TimeIndexedData,
        **kwargs: Any,
    ) -> TimeIndexedOutput:
        return self._estimator.transform(data, **kwargs)

    @decorators.check_state_and_input
    def _inverse_transform(
        self,
        data: TimeIndexedData,
        **kwargs: Any,
    ) -> TimeIndexedOutput:
        return self._estimator.inverse_transform(data, **kwargs)

    @decorators.check_state_and_input
    def _transform_covariates(
        self,
        data: TimeIndexedData,
        **kwargs: Any,
    ) -> TimeIndexedOutput:
        return self._estimator.transform_covariates(data, **kwargs)

    """
    Required Methods for Estimator
    """

    def save(self, path: str) -> None:
        """Persist this estimator at the location specified by `path`

        Parameters
        ----------
        path: str
            A path to the serialized Estimator's output destination.
        """
        tempdir = TemporaryDirectory()
        prefix = Path(tempdir.name)

        with (Path(prefix) / "contamination").open("wb") as f:
            io.cloudpickle_dump(self._contamination, f)

        io.save(self._estimator, str(prefix / "estimator"))
        io.create_archive(str(prefix), path)

    @classmethod
    def load(cls, path: str) -> OutlierRemovalPreprocessor:
        """Load a previously saved Estimator instance from `path`

        Parameters
        ----------
        path: str
            A path to the serialized Estimator
        """
        unpack_dir = TemporaryDirectory()
        unpack_path = Path(unpack_dir.name)
        io.unpack_archive(path, str(unpack_path))

        with (unpack_path / "contamination").open("rb") as f:
            contamination = io.cloudpickle_load(f)

        estimator = io.load(str(unpack_path / "estimator"))
        return cls(estimator, contamination=contamination)
