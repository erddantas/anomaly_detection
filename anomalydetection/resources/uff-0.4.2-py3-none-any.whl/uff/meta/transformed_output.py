#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

from typing import Any, Iterable, List, Optional, Set, Type, Union

from .. import io
from ..base import (
    FeatureSelector,
    Forecaster,
    ForecasterWithInterval,
    Incremental,
    ReversibleTransformer,
    decorators,
)
from ..tstypes import (
    TimeIndex,
    TimeIndexedData,
    TimeIndexedOutput,
    TimeIndexedOutputWithInterval,
)
from .base import (
    EstimatorSpecification,
    MetaEstimator,
    create_estimator_instance,
    get_type_check,
)


class TransformedOutputForecaster(MetaEstimator):
    """A MetaEstimator for transforming, forecasting, and inverse-transforming resulting data.

    Instances of `ReversibleTransformer` and `CovariateTransformer` are acceptable as
    preprocessing steps. If no covariates are provided, only `ReversibleTransformer` instances
    are fitted. If covariates are provided, all transformers are fitted.
    """

    @decorators.set_init_attributes
    def __init__(
        self,
        transformers: Iterable[EstimatorSpecification],
        forecaster: EstimatorSpecification,
    ) -> None:
        """Initialize a TransformedOutputForecaster

        Parameters
        ----------
        transformers: Iterable[EstimatorSpecification]
            A collection of Estimators, InitializationSpecs, or InitializationSpec-compatible
            dictionaries. Each element should specify a class with the `ReversibleTransformer` or
            `FeatureSelector` mixin.
        forecaster: EstimatorSpecification
            An Estimator, InitializationSpec, or InitializationSpec-compatible dictionary
            specifying a class with the `Forecaster` mixin.
        """
        self._forecaster: Forecaster = create_estimator_instance(forecaster, Forecaster)

        self._transformers: List[Union[ReversibleTransformer, FeatureSelector]] = [
            create_estimator_instance(est, (ReversibleTransformer, FeatureSelector))
            for est in transformers
        ]
        self._feature_selectors_only: List[FeatureSelector] = [
            est for est in self._transformers if est.is_feature_selector()
        ]
        self._reversible_transformers_only: List[ReversibleTransformer] = [
            est for est in self._transformers if est.is_reversible_transformer()
        ]

        # Finalize mixins
        fcst_types = get_type_check([self._forecaster])
        transformer_types = get_type_check(self._transformers)
        self._mixins: Set[Type] = {Forecaster}
        if fcst_types[ForecasterWithInterval]:
            self._mixins.add(ForecasterWithInterval)
        if fcst_types[Incremental] and transformer_types[Incremental]:
            self._mixins.add(Incremental)

        # Infer model lifecycle values
        all_estimators = [self._forecaster] + self._transformers
        self.requires_fit = any(est.requires_fit for est in all_estimators)
        self.requires_covariates = self._forecaster.requires_covariates
        self.ray_serializable = all(est.ray_serializable for est in all_estimators)
        self.joblib_serializable = all(est.joblib_serializable for est in all_estimators)
        if ForecasterWithInterval in self._mixins:
            self.prediction_interval_width = self._forecaster.prediction_interval_width

    """
    Required methods for MetaEstimator
    """

    def mixins(self) -> Set[Type]:
        # A set of mixins present in the base estimator(s)
        return self._mixins

    @decorators.update_fit_attributes
    def fit(
        self,
        data: TimeIndexedData,
        covariates: Optional[TimeIndexedData] = None,
        **kwargs: Any,
    ) -> MetaEstimator:
        return self._train(data, covariates, partial_fit=False, **kwargs)

    @decorators.update_fit_attributes
    def _partial_fit(
        self,
        data: TimeIndexedData,
        covariates: Optional[TimeIndexedData] = None,
        **kwargs: Any,
    ) -> MetaEstimator:
        return self._train(data, covariates, partial_fit=True, **kwargs)

    def _train(
        self,
        data: TimeIndexedData,
        covariates: Optional[TimeIndexedData] = None,
        partial_fit: bool = False,
        **kwargs: Any,
    ) -> MetaEstimator:
        current_data = data
        current_covariates = covariates

        to_fit = self._reversible_transformers_only if covariates is None else self._transformers

        for i in range(len(to_fit)):
            if partial_fit:
                to_fit[i].partial_fit(current_data, current_covariates)
            else:
                to_fit[i].fit(current_data, current_covariates)

            if to_fit[i].is_transformer():
                current_data = to_fit[i].transform(current_data).out
            elif to_fit[i].is_feature_selector():
                current_covariates = to_fit[i].transform_covariates(current_covariates).out

        if partial_fit:
            self._forecaster.partial_fit(current_data, current_covariates, **kwargs)
        else:
            self._forecaster.fit(current_data, current_covariates, **kwargs)

        return self

    @decorators.check_state_and_input
    def _forecast(
        self,
        data: Union[TimeIndexedData, TimeIndex],
        **kwargs: Any,
    ) -> TimeIndexedOutput:
        if self.was_fit_with_covariates:
            for cov_transformer in self._feature_selectors_only:
                data = cov_transformer.transform_covariates(data).out

        fcst_result = self._forecaster.forecast(data, **kwargs)

        out, upper, lower = fcst_result.out, None, None
        if isinstance(fcst_result, TimeIndexedOutputWithInterval):
            upper = fcst_result.upper
            lower = fcst_result.lower

        for transformer in reversed(self._reversible_transformers_only):
            out = transformer.inverse_transform(out).out
            upper = upper if upper is None else transformer.inverse_transform(upper).out
            lower = lower if lower is None else transformer.inverse_transform(lower).out

        if self.is_forecaster_with_interval():
            return TimeIndexedOutputWithInterval(out, upper, lower, self.prediction_interval_width)
        else:
            return TimeIndexedOutput(out)

    """
    Required Methods for Estimator
    """

    def save(self, path: str) -> None:
        """Persist this estimator at the location specified by `path`

        If standard UFF Estimator classes are used, then they are individually serialized with
        .save(). Any unrecognized classes are serialized with cloudpickle.

        Parameters
        ----------
        path: str
            A path to the serialized Estimator's output destination.
        """
        io.save_multiple([self._forecaster] + self._transformers, path)

    @classmethod
    def load(cls, path: str) -> TransformedOutputForecaster:
        """Load a previously saved Estimator instance from `path`

        Parameters
        ----------
        path: str
            A path to the serialized Estimator
        """
        forecaster, *transformers = io.load_multiple(path)
        instance = cls(transformers, forecaster)

        instance._transformers = transformers
        instance._forecaster = forecaster

        return instance
