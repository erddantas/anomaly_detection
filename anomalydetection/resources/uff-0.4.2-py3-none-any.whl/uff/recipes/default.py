#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Collection, List, Optional, Union

import numpy as np
import pandas as pd

import uff
from uff.base import ForecasterWithInterval, decorators
from uff.forecasters.prophet import ProphetForecaster
from uff.tstypes import (
    ColumnSet,
    TimeIndex,
    TimeIndexedData,
    TimeIndexedOutputWithInterval,
    TimeStamp,
    TimeUnit,
)


def default_univariate_forecast(
    time_stamps: Collection[TimeStamp],
    values: Collection[float],
    horizon: int,
    granularity: TimeUnit,
    prediction_interval_width: float = 0.95,
    on_duplicate: Union[str, Callable[[Collection[float]], float]] = "ignore",
) -> pd.DataFrame:
    """Generate a forecast for univariate time series data

    Parameters
    ----------
    time: Collection[TimeStamp]
        A collection of time stamps
    values: Collection[float]
        A corresponding collection of observations
    horizon: int
        The number of steps into the future to forecast
    granularity: TimeUnit
        The granularity of the forecasting step. `granularity` and `horizon` are passed to
        `time_range()` to generate the domain of the forecast.
    prediction_interval_width: float, default 0.95
        The width of the prediction interval [0, 1]
    on_duplicate: str, default "ignore"
        One of "ignore", "raise" or a reduction function like np.mean()

    Returns
    -------
    pd.DataFrame
        A dataframe with the columns "time", "value", "value_upper", "value_lower". "time" will
        contain pd.Timestamp objects

    Raises
    ------
    ValueError
        If on_duplicate is not a recognized option, or len(time_stamps) != len(values)
    """
    if isinstance(on_duplicate, str) and on_duplicate not in ("ignore", "raise"):
        raise ValueError(f"Unrecognized option on_duplicate='{on_duplicate}'")
    if len(time_stamps) != len(values):
        raise ValueError("time_stamps and values must have equal length")

    collection = {}
    for t, value in zip(time_stamps, values):
        if t not in collection:
            collection[t] = []
        collection[t].append(value)

        if len(collection[t]) > 1 and on_duplicate == "raise":
            raise RuntimeError("Found duplicate time stamps")

    reducer = on_duplicate if isinstance(on_duplicate, Callable) else lambda x: x[0]
    reduced = {t: reducer(values) for t, values in collection.items()}

    sorted_t = sorted(reduced.keys())
    data = TimeIndexedData(sorted_t, [reduced[t] for t in sorted_t])
    future = TimeIndex(
        uff.time_range(start=data.last_timestamp(), periods=horizon + 1, freq=granularity)[1:],
        granularity=granularity,
    )
    model = DefaultUnivariateForecaster(prediction_interval_width=prediction_interval_width).fit(
        data
    )
    res = model.forecast(future)

    return (
        uff.hstack((res.out, res.upper, res.lower), column_prefixes=["mean", "upper", "lower"])
        .set_column_names(["value", "value_upper", "value_lower"])
        .to_pandas(time_col="time", time_as_pd_timestamps=True)
    )


@dataclass
class DefaultUnivaraiteForecasterOutput(TimeIndexedOutputWithInterval):
    out: TimeIndexedData
    upper: TimeIndexedData
    lower: TimeIndexedData
    interval_width: float


class DefaultUnivariateForecaster(ForecasterWithInterval):
    """A relatively robust and assumption-free univariate forecaster

    This module is designed to be a reasonable default forecasting algorithm for a variety of
    applications.

    It is robust to missing data and outliers, and relatively assumption-free.
    """

    @decorators.set_init_attributes
    def __init__(
        self,
        country_holidays: str = "US",
        custom_holidays: Optional[List[TimeStamp]] = None,
        uncertainty_samples: int = 1000,
        prediction_interval_width: float = 0.95,
    ):
        self.country_holidays = country_holidays
        self.custom_holidays = custom_holidays
        self.uncertainty_samples = uncertainty_samples
        self.prediction_interval_width = prediction_interval_width

        self.best_model: Optional[ProphetForecaster] = None
        self.identically_zero: bool = False
        self.fit_cols: Optional[ColumnSet] = None

    @decorators.update_fit_attributes
    def fit(
        self, data: TimeIndexedData, covariates: Optional[TimeIndexedData] = None
    ) -> DefaultUnivariateForecaster:
        self.fit_cols = data.column_names

        if len(data) < 2:
            self.identically_zero = True
            return self

        mad = np.median(data - np.median(data))
        const_params = {
            "changepoint_range": 1 - min(7 / len(data), 1),
            "country_holidays": self.country_holidays,
            "holidays": (
                None
                if self.custom_holidays is None
                else pd.DataFrame(
                    {
                        "ds": [pd.Timestamp(h).date() for h in self.custom_holidays],
                        "holiday": [str(i) for i in range(len(self.custom_holidays))],
                    }
                )
            ),
            "prediction_interval_width": self.prediction_interval_width,
            "uncertainty_samples": self.uncertainty_samples,
            "cap": np.max(data) + mad,
            "floor": np.min(data) - mad,
        }

        # TO DO - Add grid search for non-constant parameters like growth, seasonality
        best = ProphetForecaster(**const_params)
        self.best_model = best.fit(data)
        return self

    @decorators.check_state_and_input
    def forecast(
        self, data: Union[TimeIndex, TimeIndexedData]
    ) -> DefaultUnivaraiteForecasterOutput:
        if self.identically_zero:
            out, upper, lower = (self.all_zeros(data) for _ in range(3))
        else:
            res = self.best_model.forecast(data)
            out, upper, lower = res.out, res.upper, res.lower
        return DefaultUnivaraiteForecasterOutput(
            out=out,
            upper=upper,
            lower=lower,
            interval_width=self.prediction_interval_width,
        )

    def all_zeros(self, data: Union[TimeIndex, TimeIndexedData]) -> TimeIndexedData:
        return TimeIndexedData.from_time_index(
            data if isinstance(data, TimeIndex) else data.time_index,
            [0] * len(data),
            column_names=self.fit_cols,
        )
