#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

from datetime import date, datetime
from functools import reduce
from typing import Callable, List, Optional, Protocol, Union

import numpy as np
import pandas as pd
from pandas.api.types import is_integer_dtype
from pandas.tseries.offsets import DateOffset

import uff
from uff.base import ForecasterWithInterval
from uff.forecasters.prophet import PermissiveProphetForecaster
from uff.meta import ColumnEnsembleEstimator
from uff.tstypes import TimeIndex, TimeIndexedData

_STR_TO_NULLABLE_DTYPE = {
    "int8": pd.Int8Dtype(),
    "int16": pd.Int16Dtype(),
    "int32": pd.Int32Dtype(),
    "int64": pd.Int64Dtype(),
    "uint8": pd.UInt8Dtype(),
    "uint16": pd.UInt16Dtype(),
    "uint32": pd.UInt32Dtype(),
    "uint64": pd.UInt64Dtype(),
}


class SparkDataFrame(Protocol):
    def toPandas(self) -> pd.DataFrame: ...


class SparkContext(Protocol):
    def createDataFrame(self, df: pd.DataFrame, schema: str) -> SparkDataFrame: ...


def _get_default_forecaster(prediction_interval_width: float) -> ColumnEnsembleEstimator:
    return ColumnEnsembleEstimator(
        PermissiveProphetForecaster(prediction_interval_width=prediction_interval_width)
    )


def forecast_pandas_dataframe(
    data: pd.DataFrame,
    horizon: int,
    time_granularity: str,
    time_col: str,
    value_cols: Union[str, List[str]],
    dimension_cols: Optional[List[str]] = None,
    prediction_interval_width: float = 0.95,
    create_forecaster: Callable[[float], ForecasterWithInterval] = _get_default_forecaster,
    strict_granularity: bool = False,
) -> pd.DataFrame:
    """Forecast a dataframe `horizon` steps into the future.

    Parameters
    ----------
    data: pd.DataFrame
        A dataframe with at least the columns `time_col`, `value_col` and `dimension_cols`
    horizon: int
        The number of time steps into the future to forecast
    time_granularity: str
        The granularity of the time measurements. This is expected to be a valid input to Spark
        SQL's date_trunc function i.e. year, quarter, month, day, hour, minute, second.
    time_col: str
        The name of the `time` column. Should have dtype = object or integer. Objects will be
        cast to pd.Timestamp objects. Integers will be treated as unix timestamps.
    value_cols: Union[str, List[str]]
        The metric column(s)
    dimension_cols: Optional[List[str]], default None
        The group by column(s) if any
    prediction_interval_width: float, default 0.95
        The 0-1 prediction interval width. Default is 0.95 for 95% intervals.
    create_forecaster: Callable[[float], ForecasterWithInterval], optional
        An optional callable that can be used to generate a forecaster with the provided
        prediction_interval_width. Power users can construct a functools.partial() object or
        similar callable to invoke a model with specific parameterization. The model should in
        most cases be capable of multivariate forecasting, unless input data has a single value_col
        and no dimension_cols.
    strict_granularity: bool, default False
        If True, then `time_granularity` will be applied to the input data, throwing an error if
        the timestamps are not compatible. Otherwise `time_granularity` will only be used to
        determine the future timestamps. This should be `True` if using an autoregressive
        forecaster like ARIMA where the notion of a "step" is important.

    Returns
    -------
    pd.DataFrame
        An output dataframe with the same schema as `data` plus the additional columns
        `{v}_upper` and `{v}_lower` for each `value_col`. Unused columns will be passed through
        as missing values. The dtype of any unused integer columns will be pd.Int64Dtype() with
        pd.NA representing the missing vlaues. Unused float columns will be populated with `NaN`
        and all other colums will be populated with `None` in the original dtype. `{v}_upper`
        and `{v}_lower` columns will have dtype float64. `time_col` will contain `pd.Timestamp`
        objects.
    """
    value_cols = value_cols if isinstance(value_cols, list) else [value_cols]
    ordered_cols = list(data.columns) + [f"{v}_{b}" for v in value_cols for b in ("upper", "lower")]

    dimension_cols = dimension_cols or []
    if isinstance(dimension_cols, str):
        dimension_cols = [dimension_cols]

    if len(value_cols) != len(set(value_cols)):
        raise ValueError("Duplicate values found in `value_cols`")

    if len(dimension_cols) != len(set(dimension_cols)):
        raise ValueError("Duplicate values found in `dimension_cols`")

    # Identify the "pass through" columns
    used_columns = set([time_col] + value_cols + dimension_cols)
    unused_columns = set(data.columns) - used_columns

    # Infer input / output schema mapping
    integer_columns = {k for k, v in data.dtypes.items() if is_integer_dtype(v)}

    # Unused integer columns must be returned as pd.IntegerDtype to support missing data.
    coerce = {
        c: _STR_TO_NULLABLE_DTYPE.get(data.dtypes[c].name.lower(), pd.Int64Dtype())
        for c in unused_columns & integer_columns
    }
    output_schema = {k: coerce[k] if k in coerce else v for k, v in data.dtypes.items()}
    for v in value_cols:
        for suffix in ("upper", "lower"):
            output_schema[f"{v}_{suffix}"] = np.dtype("float64")

    # Unpack to UFF types and train the model
    ts_data = TimeIndexedData.from_pandas(
        data,
        value_cols,
        time_col=time_col,
        group_by=dimension_cols,
        granularity=time_granularity if strict_granularity else None,
    )

    if strict_granularity:
        future = ts_data.future_time_index(n_steps=horizon)
    else:
        future = uff.time_range(
            ts_data.last_timestamp(), periods=horizon + 1, freq=time_granularity
        )
        future = future[:-1] if future[0] > ts_data.last_timestamp() else future[1:]
        future = TimeIndex(future)

    # Initialize and train the model
    model = create_forecaster(prediction_interval_width)
    model.fit(ts_data)
    output = model.forecast(future)
    results = (output.out, output.upper, output.lower)

    # Return the data in long format
    dataframes = []
    for res, suffix in zip(results, ("", "_upper", "_lower")):
        res.set_column_names([(f"{c[0]}{suffix}", *c[1:]) for c in res.column_tuples])
        res_df = res.to_long_format_pandas(
            time_as_pd_timestamps=True,
            time_col=time_col,
            metric_level=0,
            dimension_columns=dimension_cols,
        )
        dataframes.append(res_df)

    join_key = [time_col] + dimension_cols
    merged = reduce(lambda left, right: pd.merge(left, right, on=join_key, how="outer"), dataframes)
    for col in unused_columns:
        missing_val = pd.NA if col in coerce else None
        merged[col] = pd.Series([missing_val] * len(merged), dtype=output_schema[col])

    return merged[ordered_cols].astype(output_schema)


def forecast_report_table(
    spark: SparkContext,
    spark_df: SparkDataFrame,
    horizon: int,
    time_start_col: str = "time_granularity_start",
    time_end_col: str = "time_granularity_end",
    value_col: str = "metric_value",
    dimension_cols: Optional[List[str]] = None,
    granularity_col: str = "time_granularity_id",
    prediction_interval_width: float = 0.95,
    create_forecaster: Callable[[float], ForecasterWithInterval] = _get_default_forecaster,
    strict_granularity: bool = False,
) -> SparkDataFrame:
    """Create a Spark Dataframe from the specified forecaster result

    Parameters
    ----------
    spark: SparkContext
        A SparkContext that will be used to create the resulting dataframe.
    spark_df: SparkDataFrame
        A Spark Dataframe containing a subset of a Metric Store report table.
    horizon: int
        The number of steps into the future to forecast the metrics. The specific length of time
        will be determined by `granularity_col`
    time_start_col: str, default "time_granularity_start"
        The timestamp column. These represent the point in time that the metric observation
        corresponds to.
    time_end_col: str, default "time_granularity_end"
        The timestamp end column. This will be unused by the forecast, but projected forward in
        `granularity_col` steps to fill future values.
    value_col: str, default "metric_value"
        A DOUBLE column representing the metric observations.
    dimension_cols: Optional[List[str]], default None
        These columns uniquely identify a single metric_value observation. If unspecified, then
        "dimension_value", "metric_granularity", "metric_granularity_id", "metric_id",
        "metric_name" will be used. If `dimension_cols` is specified but does not include all
        columns, then any unused columns will be present as NULL values in the forecast result.
        Because it is a constant value, `granularity_col` will always be added to the
        `dimension_cols` if not provided.
    granularity_col: str, default "time_granularity_id"
        The column containing the metric time granularity. There should only be one unique value
        in this column.
    prediction_interval_width: float, default 0.95
        The 0-1 prediction interval width. Default is 0.95 for 95% intervals.
    create_forecaster: Callable[[float], ForecasterWithInterval]
        An optional callable that can be used to generate a forecaster with the provided
        prediction_interval_width. Power users can construct a functools.partial() object or
        similar callable to invoke a model with specific parameterization.
    strict_granularity: bool, default False
        If True, then `time_granularity` will be applied to the input data, throwing an error if
        the timestamps are not compatible. Otherwise `time_granularity` will only be used to
        determine the future timestamps. This should be `True` if using an autoregressive
        forecaster like ARIMA where the notion of a "step" is important.

    Returns
    -------
    SparkDataFrame
        A dataframe with the columns `time_start_col` `time_end_col` `granularity_col`
        `dimension_cols` `forecast` `forecast_upper` and `forecast_lower`

    Raises
    ------
    ValueError
        If more than one unique value is present in `granularity_col`, or the column "forecast" is
        present in the input dataframe.
    """
    df = spark_df.toPandas()
    time_start_is_date = all(
        isinstance(x, date) and not isinstance(x, datetime) for x in df[time_start_col]
    )
    time_end_is_date = all(
        isinstance(x, date) and not isinstance(x, datetime) for x in df[time_end_col]
    )

    if time_start_is_date != time_end_is_date:
        raise ValueError(
            "Expected time_start_col and time_end_col to have the same type (dates or timestamps)"
        )

    df[time_start_col] = df[time_start_col].apply(pd.Timestamp)
    df[time_end_col] = df[time_end_col].apply(pd.Timestamp)

    if any(col in df for col in ("forecast", "forecast_upper", "forecast_lower")):
        raise ValueError(
            "Name conflict. forecast (+upper/lower) column is reserved for the forecast output."
        )

    granularities = list(set(df[granularity_col]))
    if len(granularities) > 1:
        raise ValueError("Multiple granularity values were found in the provided dataframe.")

    granularity = granularities[0]
    time_unit = uff.get_custom_granularity(granularity)
    if time_unit is None:
        raise ValueError(f"Unexpected granularity value {granularity}")

    if dimension_cols is None:
        dimension_cols = [
            "dimension_value",
            "metric_granularity",
            "metric_granularity_id",
            "metric_id",
            "metric_name",
        ]
    else:
        dimension_cols = list(dimension_cols)

    if granularity_col not in dimension_cols:
        dimension_cols.append(granularity_col)

    res_df = forecast_pandas_dataframe(
        df,
        horizon=horizon,
        time_granularity=granularities[0],
        time_col=time_start_col,
        value_cols=value_col,
        dimension_cols=dimension_cols,
        prediction_interval_width=prediction_interval_width,
        create_forecaster=create_forecaster,
        strict_granularity=strict_granularity,
    )
    res_df = res_df.rename(
        columns={
            value_col: "forecast",
            f"{value_col}_upper": "forecast_upper",
            f"{value_col}_lower": "forecast_lower",
        }
    )
    # Assume there are no sub-second granularity metrics
    adjustment = DateOffset(days=1) if time_start_is_date else pd.Timedelta(seconds=1)
    res_df[time_end_col] = res_df[time_start_col].apply(lambda x: x + time_unit - adjustment)

    # Convert to spark output type
    if time_start_is_date:
        res_df[time_start_col] = res_df[time_start_col].apply(lambda x: x.date())
        res_df[time_end_col] = res_df[time_end_col].apply(lambda x: x.date())
    else:
        res_df[time_start_col] = res_df[time_start_col].apply(lambda x: x.to_pydatetime())
        res_df[time_end_col] = res_df[time_end_col].apply(lambda x: x.to_pydatetime())

    # Reorder columns
    keep_cols = {
        granularity_col,
        time_end_col,
        time_start_col,
        "forecast",
        "forecast_upper",
        "forecast_lower",
        *dimension_cols,
    }
    out_cols = [c for c in res_df.columns if c in keep_cols]
    fcst_types = {k: float for k in ("forecast", "forecast_upper", "forecast_lower")}
    return spark.createDataFrame(res_df[out_cols].astype(fcst_types))
