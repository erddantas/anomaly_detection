#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
from hierarchicalforecast.core import HierarchicalReconciliation
from hierarchicalforecast.methods import (
    ERM,
    BottomUp,
    HReconciler,
    MiddleOut,
    MinTrace,
    OptimalCombination,
    TopDown,
)

from . import logger
from .tstypes import (
    All,
    ColumnType,
    TimeIndexedData,
    TimeIndexedOutput,
    TimeIndexedOutputWithInterval,
)
from .utils import interpolate, random_seed

__all__ = [
    "BaseReconciler",
    "BottomUpReconciler",
    "ErmReconciler",
    "MiddleOutReconciler",
    "MinTraceReconciler",
    "OptimalCombinationReconciler",
    "TopDownReconciler",
]


@dataclass
class _NixtlaDataRequirements:
    str_to_col: Dict[str, Tuple[ColumnType]]
    Y_hat_df: pd.Dataframe
    S_df: pd.DataFrame
    tags: Dict[str, List[str]]
    Y_df: Optional[pd.DataFrame]


def _get_nixtla_dataframe(
    data: TimeIndexedData,
    col_to_str: Dict[Tuple[ColumnType], str],
    *,
    in_sample_data: Optional[TimeIndexedData] = None,
    upper: Optional[TimeIndexedData] = None,
    lower: Optional[TimeIndexedData] = None,
    interval_width: Optional[float] = None,
) -> pd.DataFrame:
    """Generate a Nixtla dataframe from fully-specified hierarchical data

    Parameters
    ----------
    data: TimeIndexedData
        Fully specified hierarchical data
    col_to_str: Dict[Tuple[ColumnType], str]
        A dictionary mapping hierarchical column tuples to unique string IDs
    in_sample_data: Optional[TimeIndexedData], default None
        If specified, hierarchical data with the same shape as `data`.
    upper: Optional[TimeIndexedData], default None
        Upper bound of prediction interval
    lower: Optional[TimeIndexedData], default None
        Lower bound of prediction interval
    interval_width: Optional[float], default None
        [0-1] prediction interval width

    Returns
    -------
    pd.DataFrame
        A nixtla-style pandas dataframe
    """
    level_str = None if interval_width is None else str(interval_width * 100)
    ds = data.pd_timestamp_index()
    dfs = []
    for col in data.column_tuples:
        df = pd.DataFrame({"ds": ds, "fcst": data[col]})
        if in_sample_data is not None:
            df["y"] = in_sample_data[col]
        if level_str is not None:
            df[f"fcst-hi-{level_str}"] = upper[col]
            df[f"fcst-lo-{level_str}"] = lower[col]
        df["unique_id"] = col_to_str[col]
        dfs.append(df)
    return pd.concat(dfs, ignore_index=True).set_index("unique_id")


def _parse_data(
    data: TimeIndexedData,
    in_sample_data: Optional[TimeIndexedData] = None,
    in_sample_forecasts: Optional[TimeIndexedData] = None,
    upper: Optional[TimeIndexedData] = None,
    lower: Optional[TimeIndexedData] = None,
    interval_width: Optional[float] = None,
) -> _NixtlaDataRequirements:
    """Generate Nixtla hierarchical reconciliation arguments from UFF datatypes

    Parameters
    ----------
    data: TimeIndexedData
        2D fully-specified hierarchical data
    in_sample_data: Optional[TimeIndexedData], default None
        Observed data with the same columns as `data`
    in_sample_forecasts: Optional[TimeIndexedData], default None
        In-sample point forecasts. Should have the same shape as `in_sample_data`
    upper: Optional[TimeIndexedData], default None
        Upper bound of prediction interval
    lower: Optional[TimeIndexedData], default None
        Lower bound of prediction interval
    interval_width: Optional[float], default None
        [0-1] prediction interval width

    Returns
    -------
    _NixtlaDataRequirements
        The required parameters for Nixtla hierarchical reconciliation

    Raises
    ------
    ValueError
        If data has ndim > 2
    """
    if data.ndim > 2:
        raise ValueError("data must have ndim <= 2")

    all_nodes = data.column_tuples
    leaf_nodes = [c for c in all_nodes if data.is_leaf_node(c)]

    node_index = {c: i for i, c in enumerate(all_nodes)}
    leaf_index = {c: i for i, c in enumerate(leaf_nodes)}

    col_to_str = {c: str(i) for c, i in node_index.items()}
    str_to_col = {i: c for c, i in col_to_str.items()}

    node_strings = [col_to_str[c] for c in all_nodes]
    leaf_strings = [col_to_str[c] for c in leaf_nodes]

    Y_hat_df = _get_nixtla_dataframe(
        data,
        col_to_str,
        upper=upper,
        lower=lower,
        interval_width=interval_width,
    )
    Y_df = None
    if in_sample_data is not None:
        # We make sure to construct in_sample_forecasts upstream.
        Y_df = _get_nixtla_dataframe(
            in_sample_forecasts,
            col_to_str,
            in_sample_data=in_sample_data,
        )

    S_array = np.zeros((len(all_nodes), len(leaf_nodes)))
    for node_tuple in all_nodes:
        row = node_index[node_tuple]
        for leaf in data.get_aggregated_columns(node_tuple):
            col = leaf_index[leaf]
            S_array[row][col] = 1

    tags = {}
    for col, str_col in col_to_str.items():
        level = str(len(col) - sum(ci == All for ci in col))
        if level not in tags:
            tags[level] = []
        tags[level].append(str_col)

    return _NixtlaDataRequirements(
        str_to_col=str_to_col,
        Y_hat_df=Y_hat_df,
        S_df=pd.DataFrame(S_array, columns=leaf_strings, index=node_strings),
        tags=tags,
        Y_df=Y_df,
    )


class BaseReconciler:
    methods: Tuple[str] = tuple()

    def initialize_model(self) -> HReconciler:
        """Must be implemented by the reconciler child classes"""
        raise NotImplementedError()

    @property
    def use_insample(self) -> bool:
        """Must be implemented by the reconciler child classes"""
        raise NotImplementedError()

    @property
    def supports_intervals(self) -> bool:
        return True

    @property
    def nonnegative(self) -> bool:
        return False

    @classmethod
    def check_method_string(cls, method: str) -> None:
        if method not in cls.methods:
            raise ValueError(f"Unknown method {method}")

    def reconcile(
        self,
        data: Union[TimeIndexedData, TimeIndexedOutput],
        in_sample_data: Optional[TimeIndexedData] = None,
        in_sample_forecasts: Optional[TimeIndexedData] = None,
        intervals_method: str = "normality",
        num_samples: Optional[int] = None,
        seed: Optional[int] = None,
    ) -> TimeIndexedOutput:
        """Perform hierarchical reconciliation

        Parameters
        ----------
        data: Union[TimeIndexedData, TimeIndexedOutput]
            Out-of-sample hierarchical forecasts to reconcile.
        in_sample_data: Optional[TimeIndexedData], default None
            Observed hierarchical data. Should have the same columns as `data`.
        in_sample_forecasts: Optional[TimeIndexedData], default None
            In-sample unreconciled point forecasts. To match guideance from the literature, this
            should be one-step-ahead forecasts. If this argument is not supplied, the overlap
            between `data` and `in_sample_data` will be used to fill the in-sample forecasts. This
            argument is required when computing intervals with `intervals_method="bootstrap"` as
            the bootstrapping procedure requires at least len(data) residual observations.
        intervals_method: str, default "normality"
            One of "normality", "bootstrap", or "permbu". Passed directly to Nixtla .reconcile().
        num_samples: Optional[int]
            Passed directly to Nixtla .reconcile(). If intervals_method is "permbu" or "bootstrap",
            and num_samples is unspecified then it will be set to 200.
        seed: Optional[int]
            Passed directly to Nixtla .reconcile() if specified.

        Returns
        -------
        TimeIndexedOutput
            Reconciled forecasts. `.out` have the same size and shape as the time series input. If a
            `TimeIndexedOutputWithInterval` is provided then the output will also be an instance of
            `TimeIndexedOutputWithInterval`

        Raises
        ------
        ValueError
            If any of the following conditions are met
                * in-sample data is required but not provided, or is provided with the wrong shape.
                * residuals are required but no matching in-sample / out-of-sample pairs were found.
                * the pandas output from Nixtla does not match the expected shape.
        """
        original_input = data
        intervals_method = intervals_method.lower()
        return_interval = False
        upper, lower, interval = None, None, None
        if isinstance(data, TimeIndexedOutputWithInterval):
            data, upper, lower, interval = data.out, data.upper, data.lower, data.interval_width
            return_interval = True
            if not self.supports_intervals:
                raise ValueError(
                    f"{self} does not support prediction interval calculation. "
                    "Please pass in the data without prediction intervals if using this method."
                )
        elif isinstance(data, TimeIndexedOutput):
            data = data.out

        if data.n_group_dimensions() < 2 or not data.contains_agggregates():
            logger.raise_warning("Data is not hierarchical. Skipping reconciliation")
            return (
                original_input
                if isinstance(original_input, TimeIndexedOutput)
                else TimeIndexedOutput(data)
            )

        if in_sample_data is not None and in_sample_forecasts is None:
            in_sample_forecasts = interpolate(in_sample_data.time_index, data, interp="nan")

        if self.use_insample:
            if in_sample_data is None:
                raise ValueError(f"Valid (non-NaN) in-sample residuals are required for {self}")
            if set(in_sample_data.column_tuples) != set(data.column_tuples):
                raise ValueError("In-sample data does not match out-of-sample hierarchy")

        if return_interval:
            if intervals_method in ("permbu", "bootstrap") and in_sample_data is None:
                raise ValueError(
                    "Any reconcilation method called with TimeIndexedOutputWithInterval and "
                    "intervals_method 'permbu' or 'bootstrap' requires valid (non-NaN) in-sample "
                    "residuals."
                )
            if intervals_method == "bootstrap":
                # We know by now both objects are not None
                n_residuals = len((in_sample_data - in_sample_forecasts).dropna())
                if n_residuals < len(data):
                    raise ValueError(
                        "Bootstrapping prediction intervals requires at least as many residuals as "
                        "there are timestamps to reconcile. Please supply `in_sample_forecasts` "
                        "as a separate argument if you are not already doing so, and make sure "
                        "the total number of non-NaN residuals is greater than len(data)"
                    )
            if self.nonnegative and intervals_method in ("permbu", "bootstrap"):
                raise ValueError(
                    "Non-negative reconciliation is not supported by PERMBU or bootstrap "
                    "reconciliation"
                )

        reconciler = HierarchicalReconciliation([self.initialize_model()])
        spec = _parse_data(
            data,
            in_sample_data=in_sample_data,
            in_sample_forecasts=in_sample_forecasts,
            upper=upper,
            lower=lower,
            interval_width=interval,
        )

        kwargs = {"intervals_method": intervals_method}
        if return_interval:
            kwargs["level"] = [interval * 100]
            if intervals_method in ("permbu", "bootstrap"):
                kwargs["num_samples"] = num_samples or 200

        if seed is None:
            seed = random_seed()

        if seed is not None:
            kwargs["seed"] = seed

        input_cols = {"unique_id"}.union(spec.Y_hat_df.columns)
        res = reconciler.reconcile(
            Y_hat_df=spec.Y_hat_df,
            S=spec.S_df,
            tags=spec.tags,
            Y_df=spec.Y_df,
            **kwargs,
        ).reset_index()

        out_cols = list(set(res.columns) - input_cols)
        out, upper, lower = self._unpack_df_result(res, out_cols, spec, data, interval)
        if return_interval:
            if upper is None or lower is None:
                raise ValueError("Expected prediction intervals but none were returned")

            # Prediction bounds are not checked for sampled results. For small sample sizes
            # (e.g. 1) this means that the quantile estimates may not be properly ordered with
            # respect to the "prediction" value. Here we enforce a proper ordering.
            lower.values = np.minimum(lower.values, out.values)
            upper.values = np.maximum(upper.values, out.values)
            return TimeIndexedOutputWithInterval(out, upper, lower, interval)

        return TimeIndexedOutput(out)

    @staticmethod
    def _unpack_df_result(
        res: pd.DataFrame,
        out_cols: List[str],
        spec: _NixtlaDataRequirements,
        data: TimeIndexedData,
        interval_width: Optional[float],
    ) -> Tuple:
        kwargs = {
            "time_col": "ds",
            "group_by": "unique_id",
            "granularity": data.granularity,
            "unixtime_t0": data.unixtime_t0,
            "unixtime_unit": data.unixtime_unit,
        }
        sample_cols = [c for c in out_cols if re.match(r".*-sample-\d+$", c)]
        if len(sample_cols) > 0:
            # Nixtla returned bootstrapped examples
            unpacked = TimeIndexedData.from_pandas(res, value_col=sample_cols, **kwargs)
            out = unpacked.aggregate(group_by=1, reducer=np.median).drop_group_level()
            upper = unpacked.aggregate(
                group_by=1, reducer=0.5 + (interval_width / 2)
            ).drop_group_level()
            lower = unpacked.aggregate(
                group_by=1, reducer=0.5 - (interval_width / 2)
            ).drop_group_level()
        elif any("-hi-" in c for c in out_cols):
            # Nixtla returned explicit estimates
            # [{col}, {col}-hi-{float}, {col}-lo-{float}, ...other]
            # Output columns are constructed with suffixes, so the point estimate will be the
            # first entry
            out_cols = sorted(out_cols)
            out_col = out_cols[0]

            # There should only be one column matching each of these conditions
            upper_col, lower_col = None, None
            for c in out_cols:
                if "-hi-" in c:
                    upper_col = c
                if "-lo-" in c:
                    lower_col = c

                if upper_col is not None and lower_col is not None:
                    break
            else:
                raise ValueError("Could not find upper/lower columns in dataframe result")

            out = TimeIndexedData.from_pandas(res, out_col, **kwargs)
            upper = TimeIndexedData.from_pandas(res, upper_col, **kwargs)
            lower = TimeIndexedData.from_pandas(res, lower_col, **kwargs)
        elif len(out_cols) == 1:
            # Nixtla returned no interval estimates
            unpacked = TimeIndexedData.from_pandas(res, value_col=out_cols, **kwargs)
            out, upper, lower = unpacked, None, None
        else:
            raise ValueError(f"Coult not parse Nixtla result {res}")

        def fmt_output(ts: Optional[TimeIndexedData]) -> Optional[TimeIndexedData]:
            if ts is None:
                return None
            depth = ts.n_group_dimensions()
            if depth > 2:
                raise RuntimeError(f"Expected <=2 group dimensions, found {depth}")
            if depth == 2:
                ts.drop_group_level(0)
            return ts.set_column_names([spec.str_to_col[s] for s in ts.column_names])

        return (fmt_output(out), fmt_output(upper), fmt_output(lower))


class BottomUpReconciler(BaseReconciler):
    """Bottom Up Reconciliation Class.

    The most basic hierarchical reconciliation is performed using an Bottom-Up strategy. It was
    proposed for the first time by Orcutt in 1968.

    References
    ----------
    .. [1] Orcutt, G.H., Watts, H.W., & Edwards, J.B.(1968). "Data aggregation and information
    loss". The American Economic Review, 58, 773-787.

    See Also
    --------
    https://nixtla.github.io/hierarchicalforecast/methods.html#bottomup
    """

    def initialize_model(self) -> BottomUp:
        return BottomUp()

    @property
    def use_insample(self) -> bool:
        return False


class TopDownReconciler(BaseReconciler):
    """Top Down Reconciliation Class.

    The Top Down hierarchical reconciliation method distributes the total aggregate predictions
    and decomposes it down the hierarchy using proportions that can be actual historical values
    or estimated.

    References
    ----------
    .. [1] [CW. Gross (1990). "Disaggregation methods to expedite product line forecasting".
    Journal of Forecasting, 9, 233-254.
    https://onlinelibrary.wiley.com/doi/abs/10.1002/for.3980090304.

    .. [2] [G. Fliedner (1999). "An investigation of aggregate variable time series forecast
    strategies with specific subaggregate time series statistical correlation". Computers and
    Operations Research, 26 , 1133-1149. https://doi.org/10.1016/S0305-0548(99)00017-9.

    See Also
    --------
    https://nixtla.github.io/hierarchicalforecast/methods.html#topdown
    """

    methods: Tuple[str] = ("average_proportions", "proportion_averages", "forecast_proportions")

    def __init__(self, method: str) -> None:
        """Initialize TopDownReconciler

        Parameters
        ----------
        method: str
            One of 'average_proportions', 'proportion_averages', 'forecast_proportions'
        """
        self.check_method_string(method)
        self.method_str = method

    def __repr__(self) -> str:
        return f"TopDownReconciler({self.method_str})"

    def initialize_model(self) -> TopDown:
        return TopDown(self.method_str)

    @property
    def use_insample(self) -> bool:
        return self.method_str in ("average_proportions", "proportion_averages")

    @property
    def supports_intervals(self) -> bool:
        return self.method_str != "forecast_proportions"


class ErmReconciler(BaseReconciler):
    """Empirircal Risk Minimization Class.

    The Empirical Risk Minimization reconciliation strategy relaxes the unbiasedness assumptions
    from reconciliation methods like MinTrace and optimizes squared errors between the reconciled
    predictions and the validation data to obtain an optimal reconciliation matrix.

    References
    ----------
    .. [1] Ben Taieb, S., & Koo, B. (2019). Regularized regression for hierarchical forecasting
    without unbiasedness conditions. In Proceedings of the 25th ACM SIGKDD International
    Conference on Knowledge Discovery & Data Mining KDD '19 (p. 1337-1347). New York, NY, USA:
    Association for Computing Machinery.

    See Also
    --------
    https://nixtla.github.io/hierarchicalforecast/methods.html#erm
    """

    in_sample_methods: Tuple[str] = ("closed", "reg", "reg_bu")

    def __init__(self, method: str, regularization: float = 1e-2) -> None:
        """Initialize ErmReconciler

        Parameters
        ----------
        method: str
            One of 'closed', 'reg', 'reg_bu'
        regularization: float, default 0.01
            l1 regularization strength. Only used for 'reg' and 'reg_bu'
        """
        self.check_method_string(method)
        self.method_str = method
        self.regularization = regularization

    def initialize_model(self) -> ERM:
        return ERM(method=self.method_str, lambda_reg=self.regularization)

    @property
    def use_insample(self) -> bool:
        return True


class MiddleOutReconciler(BaseReconciler):
    """Middle Out Reconciliation Class.

    This method is only available for strictly hierarchical structures (data where the number of
    paths before the bottom level is equal to the number of nodes on the previous level).
    Middle-out anchors the base predictions in a middle level. The levels above the base
    predictions use the Bottom-Up approach, while the levels below use a Top-Down.

    References
    ----------
    .. [1] Hyndman, R.J., & Athanasopoulos, G. (2021). "Forecasting: principles and practice,
    3rd edition: Chapter 11: Forecasting hierarchical and grouped series.". OTexts: Melbourne,
    Australia. OTexts.com/fpp3 Accessed on July 2022.

    See Also
    --------
    https://nixtla.github.io/hierarchicalforecast/methods.html#middleout
    """

    methods: Tuple[str] = TopDownReconciler.methods

    def __init__(self, middle_level: int, method: str) -> None:
        """Initialize MiddleOutReconciler

        Parameters
        ----------
        middle_level: int
            The specified middle level. Top-down reconciliation will be applied below this level,
            and bottom-up reconcilation will be applied above.
        method: str
            The top-down reconciliation method to use below `middle_level`. One of
            'average_proportions', 'proportion_averages', 'forecast_proportions'
        """
        self.check_method_string(method)
        self.middle_level = middle_level
        self.method_str = method

    def __repr__(self) -> str:
        return f"MiddleOutReconciler({self.method_str}, middle_level={self.middle_level})"

    def initialize_model(self) -> MiddleOut:
        return MiddleOut(middle_level=str(self.middle_level), top_down_method=self.method_str)

    @property
    def use_insample(self) -> bool:
        return self.method_str in ("average_proportions", "proportion_averages")

    @property
    def supports_intervals(self) -> bool:
        # At the time of writing, `level` is unused by MiddleOut.fit_predict
        return False


class MinTraceReconciler(BaseReconciler):
    """MinTrace Reconciliation Class.

    This reconciliation algorithm proposed by Wickramasuriya et al. depends on a generalized least
    squares estimator and an estimator of the covariance matrix of the coherency errors. The Min
    Trace algorithm minimizes the squared errors for the coherent forecasts under an unbiasedness
    assumption.

    References
    ----------
    .. [1] Wickramasuriya, S. L., Athanasopoulos, G., & Hyndman, R. J. (2019). "Optimal forecast
    reconciliation for hierarchical and grouped time series through trace minimization". Journal of
    the American Statistical Association, 114 , 804-819. doi:10.1080/01621459.2018.1448825.

    .. [2] Wickramasuriya, S.L., Turlach, B.A. & Hyndman, R.J. (2020). "Optimal non-negative
    forecast reconciliation". Statistics & Computing 30, 1167-1182,
    https://doi.org/10.1007/s11222-020-09930-0.

    See Also
    --------
    https://nixtla.github.io/hierarchicalforecast/methods.html#min-trace
    """

    methods: Tuple[str] = ("wls_var", "mint_cov", "mint_shrink", "ols", "wls_struct")

    def __init__(
        self,
        method: str,
        nonnegative: bool = False,
        regularization: float = 2e-8,
    ) -> None:
        """Initialize MinTraceReconciler

        Parameters
        ----------
        method: str
            One of "wls_var", "mint_cov", "mint_shrink", "ols", "wls_struct"
        nonnegative: bool, default False
            If True, constrain reconciled forecasts to be nonnegative
        regularization: float, default 2e-8
            Ridge regression strength for the mint_shrink covariance estimator
        """
        self.check_method_string(method)
        self.method_str = method
        self._nonnegative = nonnegative
        self.regularization = regularization

    @property
    def nonnegative(self) -> bool:
        return self._nonnegative

    def __repr__(self) -> str:
        return (
            "MinTraceReconciler("
            f"{self.method_str}, "
            f"nonnegative={self.nonnegative}, "
            f"regularization={self.regularization}"
            ")"
        )

    def initialize_model(self) -> MinTrace:
        return MinTrace(
            method=self.method_str,
            nonnegative=self.nonnegative,
            mint_shr_ridge=self.regularization,
        )

    @property
    def use_insample(self) -> bool:
        return self.method_str in ("wls_var", "mint_cov", "mint_shrink")


class OptimalCombinationReconciler(MinTraceReconciler):
    """Optimal Combination Reconciliation Class.

    This reconciliation algorithm was proposed by Hyndman et al. 2011, the method uses generalized
    least squares estimator using the coherency errors covariance matrix. The projection matrix is
    constructed using the pseudoinverse of the covariance of the base forecast. This method was
    later proved to be equivalent to MinTrace.

    References
    ----------
    .. [1] Rob J. Hyndman, Roman A. Ahmed, George Athanasopoulos, Han Lin Shang (2010). "Optimal
    Combination Forecasts for Hierarchical Time Series".

    .. [2] Shanika L. Wickramasuriya, George Athanasopoulos and Rob J. Hyndman (2010). "Optimal
    Combination Forecasts for Hierarchical Time Series".

    .. [3] Wickramasuriya, S.L., Turlach, B.A. & Hyndman, R.J. (2020). "Optimal non-negative
    forecast reconciliation". Statistics & Computing 30, 1167-1182,
    https://doi.org/10.1007/s11222-020-09930-0.

    See Also
    --------
    https://nixtla.github.io/hierarchicalforecast/methods.html#optimal-combination

    https://en.wikipedia.org/wiki/Generalized_inverse
    """

    methods: Tuple[str] = ("ols", "wls_struct")

    def __init__(self, method: str, nonnegative: bool = False) -> None:
        """Initialize OptimalCombinationReconciler

        Parameters
        ----------
        method: str
            One of 'ols', 'wls_struct'
        nonnegative: bool, default False
            If True, constrain reconciled forecasts to be nonnegative
        """
        self.check_method_string(method)
        self.method_str = method
        self._nonnegative = nonnegative

    def __repr__(self) -> str:
        return (
            "OptimalCombinationReconciler("
            f"{self.method_str}, "
            f"nonnegative={self.nonnegative}, "
            ")"
        )

    def initialize_model(self) -> OptimalCombination:
        return OptimalCombination(method=self.method_str, nonnegative=self.nonnegative)

    @property
    def use_insample(self) -> bool:
        return False

    @property
    def nonnegative(self) -> bool:
        return self._nonnegative
