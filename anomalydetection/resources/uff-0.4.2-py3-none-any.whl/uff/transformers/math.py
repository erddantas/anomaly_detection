#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

from typing import Any, Callable

import numpy as np

from ..base import ReversibleTransformer, decorators
from ..tstypes import TimeIndexedData, TimeIndexedOutput

__all__ = [
    "IdentityTransformer",
    "LogTransformer",
    "ScaledLogitTransformer",
    "TranslationTransformer",
]


class _ReversibleFunctionTransformer(ReversibleTransformer):
    def __init__(
        self,
        forward_func: Callable,
        backward_func: Callable,
    ) -> None:
        self._forward_func = forward_func
        self._backward_func = backward_func

    def forward_func(self, x: Any):
        return self._forward_func(x)

    def backward_func(self, x: Any):
        return self._backward_func(x)

    @decorators.check_state_and_input
    def transform(self, data: TimeIndexedData) -> TimeIndexedOutput:
        return self._predict(data, reverse=False)

    @decorators.check_state_and_input
    def inverse_transform(self, data: TimeIndexedData) -> TimeIndexedOutput:
        return self._predict(data, reverse=True)

    def _predict(self, data: TimeIndexedData, reverse: bool) -> TimeIndexedOutput:
        x = data.values_at_least_2d
        new_x = self._backward_func(x) if reverse else self._forward_func(x)
        new_x = new_x.reshape(data.shape)
        return TimeIndexedOutput(
            TimeIndexedData.from_time_index(data.time_index, new_x, column_names=data.column_tuples)
        )


class IdentityTransformer(_ReversibleFunctionTransformer):
    """A no-op reversible transformer.

    Sometimes useful as a placeholder or as a toggle during parameter search
    """

    @decorators.set_init_attributes(requires_fit=False)
    def __init__(self) -> None:
        super().__init__(
            forward_func=lambda x: x,
            backward_func=lambda x: x,
        )


class LogTransformer(_ReversibleFunctionTransformer):
    """Apply a log transform to the input data"""

    @decorators.set_init_attributes(requires_fit=False)
    def __init__(self, base: float = np.e) -> None:
        super().__init__(
            forward_func=lambda x: np.log(x) / np.log(base),
            backward_func=lambda x: np.power(base, x),
        )


class ScaledLogitTransformer(_ReversibleFunctionTransformer):
    """Scaled logit transform maps (a, b) to the whole real line.

    This transformer is useful to constrain forecast results (including prediction interval) to an
    open interval (a, b)
    """

    @decorators.set_init_attributes(requires_fit=False)
    def __init__(self, lower: float, upper: float) -> None:
        delta = upper - lower
        if delta <= 0:
            raise ValueError("`upper` must be larger than `lower`")
        super().__init__(
            forward_func=lambda x: np.log((x - lower) / (upper - x)),
            backward_func=lambda x: lower + (delta / (1 + np.exp(-x))),
        )


class LowerBoundTransformer(_ReversibleFunctionTransformer):
    """LowerBoundTransformer maps (a, inf) to the whole real line and back again"""

    @decorators.set_init_attributes(requires_fit=False)
    def __init__(self, lower: float) -> None:
        super().__init__(
            forward_func=lambda x: np.log(x - lower),
            backward_func=lambda y: lower + np.exp(y),
        )


class UpperBoundTransformer(_ReversibleFunctionTransformer):
    """UpperBoundTransformer maps (-inf, b) to the whole real line and back again"""

    @decorators.set_init_attributes(requires_fit=False)
    def __init__(self, upper: float) -> None:
        super().__init__(
            forward_func=lambda x: -np.log(upper - x),
            backward_func=lambda y: upper - np.exp(-y),
        )


class TranslationTransformer(_ReversibleFunctionTransformer):
    """Add `delta` to the input time series"""

    @decorators.set_init_attributes(requires_fit=False)
    def __init__(self, delta: float = 0) -> None:
        super().__init__(
            forward_func=lambda x: x + delta,
            backward_func=lambda x: x - delta,
        )
