#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

"""
Wrappers for sklearn's preprocessing transformers.
"""

from __future__ import annotations

from typing import Any, List, Optional, Tuple, Type, Union

import numpy as np
import pandas as pd
from sklearn import preprocessing as prep
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import Pipeline

from ..base import ReversibleTransformer, decorators
from ..tstypes import TimeIndex, TimeIndexedData, TimeIndexedOutput
from ..utils import hstack, time_based_regressors

__all__ = [
    "MaxAbsScaler",
    "MinMaxScaler",
    "StandardScaler",
    "PowerTransformer",
    "RobustScaler",
]


class _WrappedSklearnPreprocessor(ReversibleTransformer):
    def __init__(
        self,
        model_class: Type,
        *args: Any,
        **kwargs: Any,
    ) -> None:
        self.model = model_class(*args, **kwargs)
        self.high_dim_shape: Tuple[int] = tuple()

    @decorators.update_fit_attributes
    def fit(
        self, data: TimeIndexedData, covariates: Optional[TimeIndexedData]
    ) -> _WrappedSklearnPreprocessor:
        self.model.fit(data.values_at_least_2d)
        self.high_dim_shape = data.shape[1:]
        return self

    @decorators.check_state_and_input
    def transform(self, data: TimeIndexedData) -> TimeIndexedOutput:
        return self._predict(data, reverse=False)

    @decorators.check_state_and_input
    def inverse_transform(self, data: TimeIndexedData) -> TimeIndexedOutput:
        return self._predict(data, reverse=True)

    def _predict(self, data: TimeIndexedData, reverse: bool) -> TimeIndexedOutput:
        x = data.values_at_least_2d
        new_x = self.model.inverse_transform(x) if reverse else self.model.transform(x)
        new_x = new_x.reshape((len(data),) + self.high_dim_shape)
        return TimeIndexedOutput(
            TimeIndexedData.from_time_index(data.time_index, new_x, column_names=data.column_tuples)
        )


class MinMaxScaler(_WrappedSklearnPreprocessor):
    @decorators.set_init_attributes
    def __init__(self, feature_range: Tuple[float, float] = (0, 1)) -> None:
        """Scale each TimeIndexedData column to a given range.

        Parameters
        ----------
        feature_range: Tuple[float, float], default (0, 1)
            The desired range of the transformed data
        """
        super().__init__(prep.MinMaxScaler, feature_range=feature_range)


class StandardScaler(_WrappedSklearnPreprocessor):
    @decorators.set_init_attributes
    def __init__(self, with_mean: bool = True, with_std: bool = True) -> None:
        """Standardize each column by removing the mean and scaling to unit variance.

        Parameters
        ----------
        with_mean: bool, default True
            If True, center the data before scaling.
        with_std: bool, default True
            If True, scale the data to unit variance.
        """
        super().__init__(prep.StandardScaler, with_mean=with_mean, with_std=with_std)


class MaxAbsScaler(_WrappedSklearnPreprocessor):
    @decorators.set_init_attributes
    def __init__(self) -> None:
        """Scale each TimeIndexedData column by its maximum absolute value."""
        super().__init__(prep.MaxAbsScaler)


class PowerTransformer(_WrappedSklearnPreprocessor):
    @decorators.set_init_attributes
    def __init__(self, method: str = "yeo-johnson", standardize=True) -> None:
        """Scale columns of TimeIndexedData with a power transform

        Apply a Box-Cox or Yeo-Johnson transform to each column independently. The optimal
        parameter for stabilizing variance and minimizing skewness is estimated through
        maximum likelihood.

        Box-Cox requires input data to be strictly positive, while Yeo-Johnson supports both
        positive or negative data.

        By default, zero-mean, unit-variance normalization is applied to the transformed data.

        Parameters
        ----------
        method: str, {"yeo-johnson", "box-cox"}, default "yeo-johnson"
            The power transform method. "box-cox" only works on strictly-positive data
        standardize: bool, default True
            Whether to apply zero-mean, unit-variance normalization to the transformed output.
        """
        super().__init__(prep.PowerTransformer, method=method, standardize=standardize)


class RobustScaler(_WrappedSklearnPreprocessor):
    @decorators.set_init_attributes
    def __init__(
        self,
        with_centering: bool = True,
        with_scaling: bool = True,
        quantile_range: Tuple[float, float] = (25.0, 75.0),
        unit_variance: bool = False,
    ) -> None:
        """Scale a TimeIndexedData object's .values using statistics that are robust to outliers.

        This Scaler removes the median and scales the data according to the quantile range
        (defaults to IQR: Interquartile Range). The IQR is the range between the 1st quartile
        (25th quantile) and the 3rd quartile (75th quantile).

        Parameters
        ----------
        with_centering: bool, default True
            If True, center the data before scaling.
        with_scaling: bool, default True
            If True, scale the data to interquartile range.
        quantile_range: Tuple[float, float], default (25.0, 75.0)
            Quantile range used to scale the data. Unlike other UFF estimators which accept
            `(0, 1)` quantiles, these quantiles should be in the interval `(0, 100)`. Quantiles
            are expressed this way to keep the API familiar to sklearn users.
        unit_variance: bool, default True
            If True, scale data so that normally distributed features have a variance of 1. In
            general, if the difference between the x-values of q_max and q_min for a standard
            normal distribution is greater than 1, the dataset will be scaled down. If less than
            1, the dataset will be scaled up.
        """
        super().__init__(
            prep.RobustScaler,
            with_centering=with_centering,
            with_scaling=with_scaling,
            quantile_range=quantile_range,
            unit_variance=unit_variance,
        )


class AutoTrendTransformer(ReversibleTransformer):
    @decorators.set_init_attributes
    def __init__(self) -> None:
        """Conditionally apply a power transform to TimeIndexedData.

        This transformer is useful when the data is possibly exponential and you want to
        transform it to linear data. If the data has at least 4 non-NaN rows, it will fit a OLS
        model with time-based regressors to the data with and without applying a PowerTransformer.
        It will then choose the transformation with better MSE.

        If multivariate data is passed to this transformer, each column will be assessed
        independently.
        """
        # Approximately equivalent to a unit variance transform where 99.9% of the data is within
        # 3 standard deviations
        self._pipeline_a = Pipeline([("scaler", prep.MinMaxScaler((1, 7)))])
        self._pipeline_b = Pipeline(
            [
                ("scaler", prep.MinMaxScaler((1, 7))),
                ("power", prep.PowerTransformer(method="yeo-johnson")),
            ]
        )
        self._pipeline_b_mask: Optional[np.ndarray] = None
        self._fit_cols: Optional[List] = None
        self._high_dim_shape: Tuple[int] = tuple()
        self._no_op: bool = False

    @decorators.update_fit_attributes
    def fit(
        self, data: TimeIndexedData, covariates: Optional[TimeIndexedData]
    ) -> AutoTrendTransformer:
        if data.ndim > 2:
            raise ValueError("AutoTrendTransformer only supports 1D or 2D data")

        data = data.dropna()
        if len(data) < 4:
            self._no_op = True
            return self

        y_arr = data.values_at_least_2d
        n_cols = y_arr.shape[1]

        v1 = self._pipeline_a.fit_transform(y_arr)
        v2 = self._pipeline_b.fit_transform(y_arr)
        combined = np.hstack([v1, v2])

        exog = time_based_regressors(data)
        preds_transformed = LinearRegression().fit(exog, combined).predict(exog)
        preds_a = self._pipeline_a.inverse_transform(preds_transformed[:, :n_cols])
        preds_b = self._pipeline_b.inverse_transform(preds_transformed[:, n_cols:])

        ssr_linear = np.sum((y_arr - preds_a) ** 2, axis=0)
        ssr_exponential = np.sum((y_arr - preds_b) ** 2, axis=0)

        ssr_hstack = np.vstack([ssr_linear, ssr_exponential])
        self._pipeline_b_mask = np.argmin(ssr_hstack, axis=0) == 1
        self._fit_cols = data.column_tuples
        self._high_dim_shape = data.shape[1:]
        return self

    @decorators.check_state_and_input
    def transform(self, data: TimeIndexedData, **kwargs) -> TimeIndexedOutput:
        if self._no_op:
            return TimeIndexedOutput(data)

        self._check_columns(data)
        values_2d = data.values_at_least_2d
        a_transform = self._pipeline_a.transform(values_2d)
        b_transform = self._pipeline_b.transform(values_2d)
        new_values = np.where(self._pipeline_b_mask, b_transform, a_transform)
        return self._get_result(data, new_values)

    @decorators.check_state_and_input
    def inverse_transform(self, data: TimeIndexedData) -> TimeIndexedOutput:
        if self._no_op:
            return TimeIndexedOutput(data)

        self._check_columns(data)
        values_2d = data.values_at_least_2d
        a_inverse = self._pipeline_a.inverse_transform(values_2d)
        b_inverse = self._pipeline_b.inverse_transform(values_2d)
        new_values = np.where(self._pipeline_b_mask, b_inverse, a_inverse)
        return self._get_result(data, new_values)

    def _get_result(self, data: TimeIndexedData, new_values: np.ndarray) -> TimeIndexedOutput:
        new_values = new_values.reshape((len(data),) + self._high_dim_shape)
        result = TimeIndexedData.from_time_index(
            data.time_index, new_values, column_names=data.column_tuples
        )
        return TimeIndexedOutput(result)

    def _check_columns(self, data: TimeIndexedData) -> None:
        if data.column_tuples != self._fit_cols:
            raise ValueError(
                "The provided data has a different schema compared to the data used for fitting"
            )
