#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

import pickle
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np
import numpy.typing as npt

from ...base import Transformer, decorators
from ...io import cloudpickle_dump, cloudpickle_load
from ...tstypes import TimeIndexedData, TimeIndexedOutput


@dataclass
class RanSynCodersOutput(TimeIndexedOutput):
    """A container for RanSynCodersTransformer output

    Attributes
    ----------
    out: TimeIndexedData
        The synchronized TimeIndexedData. If no common oscillations were found this will be the
        same as the input. Column names from the transformed time series will be preserved.
    upper_estimates: TimeIndexedData
        The output of the `n_estimators` upper bound estimates. values shape will be
        `(T, C, n_estimators)` where (T, C) is the time index length and number of columns in the
        input. Column names from the transformed time series will be preserved.
    lower_estimates: TimeIndexedData
        The output of the `n_estimators` lower bound estimates. This will have the same shape as
        upper_estimates.
    delta: float
        The percentile value used to compute the upper and lower bounds. The lower bound
        estimates represent the `delta`-th percentile and the upper bound estimates represent
        the `(1 - delta)`-th percentile.
    was_synchronized: bool
        True if RanSynCodersTransformer.synchronize == True and common oscillations were found in
        the input series.
    """

    out: TimeIndexedData
    upper_estimates: TimeIndexedData
    lower_estimates: TimeIndexedData
    delta: float
    was_synchronized: bool


class RanSynCodersTransformer(Transformer):
    """RANSynCoders Transformer

    RANSynCoders is a representation learning + synchronization procedure. Please consult the
    following publications for details.

    Abdulaal, A., Lancewicki, T. (2021).
    Real-Time Synchronization in Neural Networks for Multivariate Time Series Anomaly Detection.
    2021 IEEE International Conference on Acoustics, Speech, and Signal Processing, June 6-11, 2021

    Abdulaal, A., Liu, Z., Lancewicki, T. (2021).
    Practical Approach to Asynchronous Multivariate Time Series Anomaly Detection and Localization.
    Proceedings of the 27th ACM SIGKDD International Conference on Knowledge Discovery & Data
    Mining, August 14-18, 2021

    RANCoders are a deep learning architecture where random feature subsets are fed into N
    autoencoders in a bagging-like manner, each optimizing the quantile reconstruction losses of
    the full multivariate set. The RANSynCoders model is a RANCoders model with optional
    synchronization representation learning preprocessing. The RANSynCoders architecture uses
    spectral analysis based on the fourier transform of the latent space representation to
    identify oscillation frequencies dominant in the raw feature space.

    The RanSynCoderTransformer performs every step listed in the paper besides the detection step.
    From the N upper & lower bound decoders, the user is left to perform the final detection
    step based on some function of the bounds and the (optionally) synchronized time series.

    Find the paper here: https://drive.google.com/file/d/11EEzSGOhRXE76239E8aXnfNjKdRUBJd6/view
    """

    @decorators.set_init_attributes(ray_serializable=False, joblib_serializable=False)
    def __init__(
        self,
        n_estimators: int = 100,
        max_features: int = 3,
        encoding_depth: int = 2,
        latent_dim: int = 2,
        decoding_depth: int = 2,
        activation: str = "linear",
        output_activation: str = "linear",
        delta: float = 0.05,
        synchronize: bool = True,
        min_periods: int = 3,
        freq_init: Optional[List[float]] = None,
        max_freqs: int = 1,
        min_dist: int = 60,
        trainable_freq: bool = False,
    ) -> None:
        """Initialize a RanSynCoderTransformer

        Parameters
        ----------
        n_estimators: int, default 100
            The number of upper & lower bound decoders to train. The shape out
            `RanSynCoderOutput.out.values` will be (T, 2, n_estimators, C) where C is the number
            of columns in the input data.
        max_features: int, default 3
            The number of features to sample for each autoencoder. This must be smaller than the
            number of columns in the input data.
        encoding_depth: int, default 2
            The number of hidden layers for each encoder
        latent_dim: int, default 2
            The size of the latent space (in RANCoders, after bootstrapping)
        activation: str, default "linear"
            The string name of a Keras activation function. See
            https://keras.io/api/layers/activations/. This will be used as the activation function
            of the hidden layer (before the upper/lower decoders)
        output_activation: str, default "linear"
            The string name of a Keras activation function. See
            https://keras.io/api/layers/activations/. This will be used as the activation function
            on the output of the upper/lower decoders.
        delta: float, default 0.05
            The quantile bound for regression
        synchronize: bool, default True
            Whether or not to run the Sincoder and Synchronization steps before the RANCoder
            architecture. The RANSynCoder architecture may still short-circuit this step if no
            common oscillations are found. Note that in UFF, `synchronize=True` is equivalent to
            `synchronize=True, force_synchronization=True`
        min_periods: int, default 3
            The minimum bound on cycles to look for. At least one of the `max_freqs` peak
            frequencies must have an index larger than `min_periods` in the power spectral
            density estimate for `synchronized` to not be `None` in the
            `RanSynCoderTransformer.transform` output.
        freq_init: Optional[List[float]], default None
            An optional initial guess at the dominant angular frequencies (2*pi / T)
        max_freqs: int, default 1
            The number of sinusoidal signals to fit to the 1D latent representation.
        min_dist: int, default 60
            The minimum horizontal distance (>= 1) in samples between neighboring peaks of the
            power spectral density estimate.
        trainable_freq: bool, default False
            If True, then frequency is included as a variable that can be optimized during the
            model training
        """
        from ._ransyncoders_impl import RANSynCoders

        self.model = RANSynCoders(
            n_estimators=n_estimators,
            max_features=max_features,
            encoding_depth=encoding_depth,
            latent_dim=latent_dim,
            decoding_depth=decoding_depth,
            activation=activation,
            output_activation=output_activation,
            delta=delta,
            synchronize=synchronize,
            force_synchronization=synchronize,
            min_periods=min_periods,
            freq_init=freq_init,
            max_freqs=max_freqs,
            min_dist=min_dist,
            trainable_freq=trainable_freq,
        )
        self.fit_data: Optional[TimeIndexedData] = None

    def save(self, path: str) -> None:
        """Persist this estimator at the location specified by `path`

        Parameters
        ----------
        path: str
            A path to the serialized Estimator's output destination.
        """
        out = {
            "fit_data": self.fit_data,
            "model": {
                "params": self.model.get_config(),
            },
        }

        for attr in ("freqcoder", "sincoder", "rancoders"):
            if hasattr(self.model, attr):
                out["model"][attr] = {
                    "model": getattr(self.model, attr).to_json(),
                    "weights": getattr(self.model, attr).get_weights(),
                }

        with Path(path).open("wb") as f:
            cloudpickle_dump(out, f, protocol=pickle.DEFAULT_PROTOCOL)

    @classmethod
    def load(cls, path: str) -> RanSynCodersTransformer:
        """Load a previously saved Estimator instance from `path`

        Parameters
        ----------
        path: str
            A path to the serialized Estimator
        """
        from tensorflow.python.keras.models import model_from_json

        from . import _ransyncoders_impl as rsc

        with Path(path).open("rb") as f:
            data = cloudpickle_load(f)

        instance = cls()
        instance.fit_data = data["fit_data"]
        instance.model = rsc.RANSynCoders()

        for param, val in data["model"]["params"].items():
            setattr(instance.model, param, val)

        attr_to_objs = {
            "freqcoder": {"freqcoder": rsc.freqcoder},
            "sincoder": {"sincoder": rsc.sincoder},
            "rancoders": {"RANCoders": rsc.RANCoders},
        }

        for attr, objs in attr_to_objs.items():
            if attr in data["model"]:
                layer = model_from_json(data["model"][attr]["model"], custom_objects=objs)
                layer.set_weights(data["model"][attr]["weights"])
                setattr(instance.model, attr, layer)

        return instance

    @decorators.update_fit_attributes
    def fit(
        self,
        data: TimeIndexedData,
        covariates: Optional[TimeIndexedData] = None,
        epochs: int = 100,
        batch_size: int = 360,
        shuffle: bool = True,
        freq_warmup: int = 10,
        sin_warmup: int = 10,
        pos_amp: bool = True,
    ) -> RanSynCodersTransformer:
        """Fit the RANSynCoders transformer

        Parameters
        ----------
        data: TimeIndexedData
            Time series data with values.ndim <= 2
        _: Optional[TimeIndexedData], default None
            Covariates are not supported by RANSynCoders. This is kept only for function signature
            compatibility with the parent class.
        epochs: int, default 100
            The number of epochs to train the RANCoders
        batch_size: int, default 360
            Mini-batch size to use during training
        shuffle: bool, default True
            Whether or not to shuffle the input data before training
        freq_warmup: int, default 10
            The number of epochs to perform when pre-training the 1D autoencoder
        sin_warmup: int, default 10
            The number of epochs to perform when pre-training the sincoder.
        pos_amp: bool, default True
            If true, shift sine wave amplitudes to always be > 0

        Returns
        -------
        RanSynCodersTransformer
            self, for method chaining

        Raises
        ------
        ValueError
            If data.values does not have proper dimensionality
        """
        if data.values.ndim > 2:
            raise ValueError("RanSynCoders implementation only supports values.ndim <= 2")

        self.model.fit(
            *self._x_t(data),
            epochs=epochs,
            batch_size=batch_size,
            shuffle=shuffle,
            freq_warmup=freq_warmup,
            sin_warmup=sin_warmup,
            pos_amp=pos_amp,
        )
        self.fit_data = data
        return self

    @decorators.check_state_and_input
    def transform(
        self,
        data: TimeIndexedData,
        batch_size: int = 1000,
        desync: bool = False,
    ) -> RanSynCodersOutput:
        """Use the fitted parameters to transform a new TimeIndexedData

        Parameters
        ----------
        data: TimeIndexedData
            The data to transform. Should have the same shape as self.fit_data
        batch_size: int, default 1000
            Computation is vectorized over batches of this size.
        desync: bool, default False
            If true, return the upper and lower bounds in their original scale and phase.

        Returns
        -------
        RanSynCodersOutput
            See RanSynCodersOutput docstring
        """
        if (
            data.unixtime_t0 != self.fit_data.unixtime_t0
            or data.unixtime_unit != self.fit_data.unixtime_unit
        ):
            raise ValueError("Integer time scale must be the same as the training data")
        res = self.model.predict(*self._x_t(data), batch_size=batch_size, desync=desync)
        if self.model.synchronize:
            # RANSynCoders may have turned this off if no common oscillations were found
            _, out, upper, lower = res
            out = TimeIndexedData.from_time_index(data.time_index, out, data.column_names)
            synchronized = True
        else:
            upper, lower = res
            out = data
            synchronized = False

        # Preserve column names in output
        upper = np.swapaxes(upper, 1, 2)
        lower = np.swapaxes(lower, 1, 2)

        return RanSynCodersOutput(
            out=out,
            upper_estimates=TimeIndexedData.from_time_index(
                data.time_index, upper, data.column_names
            ),
            lower_estimates=TimeIndexedData.from_time_index(
                data.time_index, lower, data.column_names
            ),
            delta=self.model.delta,
            was_synchronized=synchronized,
        )

    @staticmethod
    def _x_t(data: TimeIndexedData) -> Tuple["npt.NDArray", "npt.NDArray"]:
        """Create X and T tensors to pass into rsc.RANSynCoders

        Parameters
        ----------
        data: TimeIndexedDAta
            The input data

        Returns
        -------
        Tuple[npt.NDArray, npt.NDArray]
            And X tensor and a T tensor. T is `data.time_index.int_values` broadcasted to be the
            same shape as `data.values`. X is equal to `data.values`.
        """
        x = data.values
        if x.ndim == 1:
            x = x.reshape(-1, 1)

        t = np.array(data.int_time_index(), dtype=np.int_)
        t = t.reshape([len(t)] + [1 for _ in range(x.ndim - 1)])
        t = np.ones_like(x) * t

        return x, t
