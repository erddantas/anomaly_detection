#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from statsmodels.tsa.seasonal import STL

from .. import utils
from ..base import Transformer, decorators
from ..tstypes import TimeIndexedData, TimeIndexedOutput


@dataclass
class StlOutput(TimeIndexedOutput):
    """A container for StlTransformer output

    Attributes
    ----------
    out: TimeIndexedData
        The residuals of the decomposed time series
    trend: TimeIndexedData
        The decomposed trend component
    seasonal: TimeIndexedData
        The decomposed seasonal component
    """

    out: TimeIndexedData
    trend: TimeIndexedData
    seasonal: TimeIndexedData


class StlTransformer(Transformer):
    @decorators.set_init_attributes(requires_fit=False)
    def __init__(
        self,
        period: int,
        seasonal_smoother_length: int = 7,
        trend_smoother_length: Optional[int] = None,
        low_pass: Optional[int] = None,
        seasonal_deg: int = 1,
        trend_deg: int = 1,
        low_pass_deg: int = 1,
        robust: bool = False,
    ) -> None:
        """Initialize an STL Transformer

        Parameters
        ----------
        period: int
            Periodicity of the sequence, expressed in a number of steps.
        seasonal_smoother_length: int, default 7
            Length of the seasonal smoother. Must be an odd integer, and should normally be >= 7
        trend_smoother_length: Optional[int], default None
            Length of the trend smoother. Must be an odd integer. If not provided STL uses the
            smallest odd integer greater than 1.5 * period / (1 - 1.5 / seasonal_smoother_length)
        low_pass: Optional[int], default None
            Length of the low-pass filter. Must be an odd integer >=3. If not provided, STL uses
            the smallest odd integer > period.
        seasonal_deg: int, default 1
            Degree of seasonal LOESS. 0 (constant) or 1 (constant and trend).
        trend_deg: int, default 1
            Degree of trend LOESS. 0 (constant) or 1 (constant and trend).
        low_pass_deg: int, default 1
            Degree of low pass LOESS. 0 (constant) or 1 (constant and trend).
        robust: bool, default False
            Flag indicating whether to use a weighted version that is robust to some forms of
            outliers.
        """
        self.kwargs = {
            "period": period,
            "seasonal": seasonal_smoother_length,
            "trend": trend_smoother_length,
            "low_pass": low_pass,
            "seasonal_deg": seasonal_deg,
            "trend_deg": trend_deg,
            "low_pass_deg": low_pass_deg,
            "robust": robust,
        }

    @decorators.check_state_and_input
    def transform(self, data: TimeIndexedData, **kwargs: Any) -> StlOutput:
        """Perform an STL decomposition on the time series

        Parameters
        ----------
        data: TimeIndexedData
            A univariate time series. Before fitting, data is made dense with NaNs populating the
            missing entries.

        Returns
        -------
        StlOutput
            The residual, trend, and seasonal components
        """
        if not utils.is_univariate(data):
            raise ValueError("STL Transformer expects univariate data")

        input_shape = data.shape

        data = data.reshape(len(data))
        dense = utils.make_dense(data)
        mask = dense.time_index.isin(data)
        res = STL(dense, **self.kwargs).fit()
        tup = tuple(
            TimeIndexedData.from_time_index(data.time_index, v[mask], data.column_names).reshape(
                input_shape
            )
            for v in (res.resid, res.trend, res.seasonal)
        )
        return StlOutput(*tup)
