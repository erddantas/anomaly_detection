#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2023-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from __future__ import annotations

import functools
import inspect
import json
import pkgutil
import random
from contextlib import contextmanager
from importlib import import_module
from pathlib import Path
from random import Random
from typing import (
    Any,
    Callable,
    Collection,
    Dict,
    List,
    Optional,
    Set,
    Tuple,
    Type,
    Union,
    overload,
)

import numpy as np
import numpy.typing as npt
import pandas as pd

from .base import Estimator, InitializationSpec
from .consts import EPOCH_TIME_NO_TZ, ONE_SECOND
from .tstypes import (
    ColumnPath,
    FloatTensor,
    TimeIndex,
    TimeIndexedData,
    TimeStamp,
    TimeUnit,
    _get_custom_granularity,
    _infer_granularity,
    _round,
    _time_range,
)

get_custom_granularity = _get_custom_granularity

time_range = _time_range

round = _round

infer_granularity = _infer_granularity


__global_rng: np.random.Generator = np.random.default_rng()


def global_rng() -> np.random.Generator:
    return __global_rng


def random_seed() -> int:
    return int(global_rng().integers(2**32))


def _coalesce(seed):
    """This function will coalesce a non-None seed.

    If the state of np.random has been seeded then the output will be random but deterministic
    within a process.
    """
    if seed is None:
        return random_seed()
    return seed


def load_estimator_from_json(json_data: Union[str, Dict[str, Any]]) -> Estimator:
    """Load an Estimator from a JSON string or dictionary

    Parameters
    ----------
    json_data: Union[str, Dict[str, Any]]
        A JSON string or dictionary containing the Estimator specification

    Returns
    -------
    Estimator
        An Estimator instance
    """
    if isinstance(json_data, str):
        json_data = json.loads(json_data)

    return InitializationSpec.from_dict(json_data).create_instance()


@contextmanager
def deterministic_rng(valid_seed: int) -> None:
    """Reseeds all known random number generators and blocks common sources of nondeterminism

    This is a best-effort attempt to make all enclosed code deterministic. This context manager
    seeds `random` and `np.random` global states with `valid_seed`. This context manager also
    monkey-patches functions that can introduce non-determinism (random.seed, Random.seed,
    np.random.seed, np.random.default_rng). The patching is performed in such a way that the RNGs
    are still reseeded upon request, but any non-specified seed value is drawn from the
    previously-seeded np.random state rather than the OS (keeping the following operations
    deterministic).

    There are a few ways nondeterminism can still be introduced within this context manager.

    * External sources of randomness (e.g. asynchronous code) affecting the order of code execution.
    * Modules that use a library besides numpy or random for random number generation.
    * Modules that make direct use of bit generators like np.random.PCg64
    * Modules that make direct references to the random state attribute (from numpy.random import
      RandomState) rather than the module (import numpy; numpy.random.RandomState())
    * Any pre-existing RNG instances or new ones that don't use the patched constructors in this
      context manager.

    In general, a `random_state` or `seed` API should be preferred if it is offered by a
    class/function; this context manager should be used as a best-effort attempt to apply
    determinism to objects that don't offer such an API.

    Parameters
    ----------
    valid_seed: int
        The new global seed value

    Yields
    ------
    None

    Raises
    ------
    ValueError
        If valid_seed is None, as this would not guarantee determinism
    """
    if valid_seed is None:
        raise ValueError("Setting seed to None does not guarantee determinism")

    # Set global RNG
    global __global_rng
    old_rng_snapshot = __global_rng

    __global_rng = np.random.default_rng(valid_seed)

    # Take state snapshots
    random_state = random.getstate()
    np_random_state = np.random.get_state()

    # Seed the global RNGs
    random.seed(valid_seed)
    np.random.seed(valid_seed)

    # Snapshot and patch known RNG callables
    random_seed = random.seed
    random.seed = lambda a=None, **kwargs: random_seed(_coalesce(a), **kwargs)

    Random_seed = Random.seed
    Random.seed = lambda self, a=None, **kwargs: Random_seed(self, _coalesce(a), **kwargs)

    np_seed = np.random.seed
    np.random.seed = lambda seed=None: np_seed(_coalesce(seed))

    default_rng = np.random.default_rng
    np.random.default_rng = lambda seed=None: default_rng(_coalesce(seed))

    try:
        yield
    finally:
        # Reset global seed
        __global_rng = old_rng_snapshot

        # Reinstate the original callables
        random.seed = random_seed
        Random.seed = Random_seed
        np.random.seed = np_seed
        np.random.default_rng = default_rng

        # Reset the original global states
        random.setstate(random_state)
        np.random.set_state(np_random_state)


def make_deterministic(valid_seed: int) -> Callable:
    """Decorator to make wrapped function deterministic by reseeding all known RNGs

    See `deterministic_rng` for details on how this is achieved.

    Parameters
    ----------
    valid_seed: int
        The new global seed value

    Returns
    -------
    Callable
    """

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            with deterministic_rng(valid_seed):
                return func(*args, **kwargs)

        return wrapper

    return decorator


class _ModelLookup:
    _short_names: Dict[str, str] = {
        "arima": "ArimaForecaster",
        "sarima": "ArimaForecaster",
        "sarimax": "ArimaForecaster",
        "prophet": "ProhpetForecaster",
        "stl": "StlTransformer",
    }
    _estimator_dict: Optional[Dict[str, Type]] = None
    _all_estimators: Optional[Set[Type]] = None

    def __init__(self):
        if _ModelLookup._estimator_dict is None:
            # Initialization
            estimators = set()
            base_classes = {cls for _, cls in _get_classes("uff.base")}
            for subdir in ("forecasters", "transformers", "meta"):
                for _, module_name, _ in pkgutil.walk_packages(
                    path=[str(Path(__file__).parent / subdir)],
                    prefix=f"uff.{subdir}.",
                ):
                    estimators |= {
                        cls
                        for name, cls in _get_classes(module_name)
                        if not name.startswith("_") and "base" not in name.lower()
                    }
            _ModelLookup._all_estimators = tuple(estimators - base_classes)
            _ModelLookup._estimator_dict = {e.__name__: e for e in _ModelLookup._all_estimators}

    def get(self, name: str) -> Type[Estimator]:
        if name.lower() in self._short_names:
            name = self._short_names[name.lower()]

        return self._estimator_dict[name]

    @property
    def all_estimators(self) -> Tuple[Type]:
        return _ModelLookup._all_estimators


def all_estimators(subclasses: Union[Type, Tuple[Type, ...]] = Estimator) -> Tuple[Type[Estimator]]:
    """Return a tuple of all UFF estimators matching the optional subclasses

    Parameters
    ----------
    subclasses: Union[Type, Tuple[Type, ...]], default Estimator
        The subclass(es) that should be used to filter the returned estimators. By default all
        non-ABC subclasses of `Estimator` are returned.

    Returns
    -------
    Tuple[Type[Estimator]]
        A tuple of Estimator classes
    """
    return tuple(e for e in _ModelLookup().all_estimators if np.issubclass_(e, subclasses))


@overload
def get_estimator(name: str) -> Type[Estimator]: ...


@overload
def get_estimator(name: List[str]) -> List[Type[Estimator]]: ...


def get_estimator(name: Union[str, List[str]]) -> Union[Type[Estimator], List[Type[Estimator]]]:
    """Fetch an Estimator subclass by its classname

    Parameters
    ----------
    name: Union[str, List[str]]
        The name(s) of the desired estimator(s)

    Returns
    -------
    Union[Type[Estimator], List[Type[Estimator]]]
        The estimato(s)r subclass matching the specified name

    Raises
    ------
    KeyError
        If the estimator is not found
    """
    singleton = _ModelLookup()
    if isinstance(name, str):
        return singleton.get(name)
    else:
        return [singleton.get(n) for n in name]


def _get_classes(module_name: str) -> List[Tuple[str, Type]]:
    """Import a module by name and get all member classes

    Parameters
    ----------
    module_name: str
        The name of the module to import

    Returns
    -------
    List[Tuple[str, Type]]
        A list of names (str) and class objects (type) discovered in the module
    """
    try:
        module = import_module(module_name)
        return inspect.getmembers(module, inspect.isclass)
    except Exception:
        return []


def concatenate(
    time_series: Collection[TimeIndexedData],
    raise_on_duplicates: bool = False,
    raise_on_out_of_order: bool = False,
    granularity: Optional[TimeUnit] = None,
    unixtime_t0: Optional[pd.Timestamp] = None,
    unixtime_unit: Optional[pd.Timedelta] = None,
) -> TimeIndexedData:
    """Concatenate multiple TimeIndexedData objects into a single object.

    Parameters
    ----------
    time_series: Collection[TimeIndexedData]
        The TimeIndexedData objects to concatenate together. This is assumed to be ordered
        with the "earliest" TimeIndexedData object appearing first.
    raise_on_duplicates: bool, default False
        If True, duplicate timestamps in the concatenated TimeIndex objects will cause
        a ValueError. Otherwise, duplicates will be ignored.
    raise_on_out_of_order: bool, default False
        If True, out-of-order timestamps in the concatenated TimeIndex objects will cause a
        ValueError. Otherwise, the concatenated timestamps and values will be sorted according
        to the timestamps.
    granularity: Optional[TimeUnit], default None
        The granularity of the TimeIndex, used to generate future values. If not provided,
        the granularity of the first TimeIndexedData object will be used.
    unixtime_t0: Optional[pd.Timestamp], default None
        A point in time represented by "0" on the integer scale. If not provided, unixtime_t0
        from the first TimeIndexedData object will be used.
    unixtime_unit: Optional[pd.Timedelta], default None
        The unit of the integer unixtime scale. If not provided, unixtime_unit from the first
        TimeIndexedData object will be used.


    Returns
    -------
    TimeIndexedData
        A single object containing the concatenation of the provided objects.

    Raises
    ------
    ValueError
        If raise_on_duplicates is True and duplicate time stamps are discovered.
    ValueError
        if raise_on_out_of_order is True and there are some out-of-order timestamps
        in the concatenated TimeIndex
    """
    if len(time_series) == 0:
        return TimeIndexedData([], [])

    granularity = granularity or time_series[0].granularity
    unixtime_t0 = unixtime_t0 or time_series[0].unixtime_t0
    unixtime_unit = unixtime_unit or time_series[0].unixtime_unit
    columns = time_series[0].column_names
    for ts in time_series[1:]:
        if ts.column_names != columns:
            raise ValueError("All concatenated time series must have the same column names")

    time_array = np.concatenate(tuple(t.pd_timestamp_index() for t in time_series))
    values = np.concatenate(tuple(t.values for t in time_series))

    uniq_t, uniq_idx = np.unique(time_array, return_index=True)

    if len(time_array) != len(uniq_t):
        if raise_on_duplicates:
            raise ValueError("Duplicate time stamps in concatenated time series")
        time_array = time_array[uniq_idx]
        values = values[uniq_idx, ...]

    if not np.all(time_array[:-1] < time_array[1:]):
        if raise_on_out_of_order:
            raise ValueError("Concatenated time indices are out of order")

        sort_idx = np.argsort(time_array)
        time_array = time_array[sort_idx]
        values = values[sort_idx, ...]

    return TimeIndexedData(
        time_array,
        values,
        column_names=columns,
        granularity=granularity,
        unixtime_t0=unixtime_t0,
        unixtime_unit=unixtime_unit,
    )


def make_dense(data: TimeIndexedData, fill_value: "npt.ArrayLike" = np.nan) -> TimeIndexedData:
    """Create a dense time series based on TimeIndexedData granularity.

    New rows in `values` will be created with the same shape as the current values, filled with
    `fill_value`. Within the bounds of data.time_index there will be no missing time stamps.
    If data.time_index is empty then this function is a no-op

    Parameters
    ----------
    data: TimeIndexedData
        Data to apply the operation to.
    fill_value: npt.ArrayLike, default np.nan
        The value that will be used to fill the entries in missing time stamps
    Returns
    -------
    TimeIndexedData
        A new TimeIndexedData object with no missing entries in the TimeIndex
    """
    missing = data.missing_time_stamps()
    if len(data) > 0:
        fill_value = _correct_shape(fill_value, data.values[0].shape)

    missing_v_shape = (len(missing),) + data.values.shape[1:]
    missing_values = np.ones(missing_v_shape, dtype=np.float64) * fill_value
    new_entries = TimeIndexedData(
        missing,
        missing_values,
        column_names=data.column_names,
        granularity=data.granularity,
        unixtime_t0=data.unixtime_t0,
        unixtime_unit=data.unixtime_unit,
    )
    return concatenate((data, new_entries))


def fill_values(data: TimeIndexedData, fill_value: float) -> TimeIndexedData:
    """Fill any `np.nan` in `self.values` with `fill_value`.

    Parameters
    ----------
    data: TimeIndexedData
        A time series that may contain some np.nan values
    fill_value: float
        The value that will be used to replace any np.nan.

    Returns
    -------
    TimeIndexedData
        A new TimeIndexedData object with no `np.nan` appering in `values`
    """
    return TimeIndexedData(
        data.pd_timestamp_index(),
        np.nan_to_num(data.values, nan=fill_value),
        column_names=data.column_names,
        granularity=data.granularity,
        unixtime_t0=data.unixtime_t0,
        unixtime_unit=data.unixtime_unit,
    )


def hstack(
    objs: Collection[TimeIndexedData],
    column_prefixes: Optional[Collection[ColumnPath]] = None,
) -> TimeIndexedData:
    """Combine TimeIndexedData objects along axis 1 (the groups dimension)

    The `time_index` must be identical for all objects.

    Parameters
    ----------
    objs: Collection[TimeIndexedData]
        The objects to hstack
    column_prefixes: Optional[Collection[ColumnPath]] = None
        If provided, a set of prefixes to apply to the column names in objs. This collection must
        be the same length as `objs`. Prefixes will be added as a tuple, making the resulting
        dataset hierarchical.

    Returns
    -------
    TimeIndexedData
        The result of the hstack operation. The output shape will be (T, C1 + C2 + ..., ...)

    Raises
    ------
    ValueError
        If 0 objects are provided, if any of the objects have a different time_index, or if
        column_prefixes and objs have unequal lengths.
    """
    if len(objs) < 1:
        raise ValueError("Must have at least one object to concatenate")
    if any([o.time_index != objs[0].time_index for o in objs]):
        raise ValueError("All objects must have the same time index to concatenate")

    time_index = objs[0].time_index

    if column_prefixes is None:
        column_prefixes = [tuple() for _ in objs]
    else:
        column_prefixes = [p if isinstance(p, tuple) else (p,) for p in column_prefixes]

    if len(column_prefixes) != len(objs):
        raise ValueError("Objects to concatenate and prefixes must have the same length")

    has_columns = [len(o.column_names) > 0 for o in objs]
    objs = [o for o, has_cols in zip(objs, has_columns) if has_cols]
    column_prefixes = [p for p, has_cols in zip(column_prefixes, has_columns) if has_cols]

    if len(objs) == 0:
        # All objects have empty column sets
        return TimeIndexedData.from_time_index(
            time_index, np.empty((len(time_index), 0)), column_names=[]
        )

    return TimeIndexedData.from_time_index(
        objs[0].time_index,
        np.hstack(tuple([o.values_at_least_2d for o in objs])),
        column_names=[
            prefix + col for obj, prefix in zip(objs, column_prefixes) for col in obj.column_tuples
        ],
    )


def auto_impute(data: TimeIndexedData) -> TimeIndexedData:
    """Impute missing values in a TimeIndexedData object

    This function will automatically impute any missing entries in the input data. If the data is
    at least at least 2 non-NaN observations, then the imputation is performed by
    MiniProphetForecaster, which is designed to preserve the trend, daily & weekly seasonality
    throughout the regions of missing or NaN data. If the data has <= 1 non-NaN observation, then
    the missing values will be filled with 0.

    Parameters
    ----------
    data: TimeIndexedData
        The data to impute

    Returns
    -------
    TimeIndexedData
        A new TimeIndexedData object with no missing or NaN values.
    """
    from .forecasters.miniprophet import MiniProphetForecaster
    from .meta import ColumnEnsembleEstimator

    data = make_dense(data)
    insample_preds = (
        ColumnEnsembleEstimator(MiniProphetForecaster(), permissive=True)
        .fit(data)
        .forecast(data)
        .out
    )

    new_values = np.where(np.isnan(data.values), insample_preds, data.values)
    new_values = np.where(np.isnan(new_values), 0.0, new_values)
    data.values = new_values
    return data


def interpolate(
    time_index: TimeIndex,
    data: TimeIndexedData,
    interp: str = "linear",
    left: Optional["npt.ArrayLike"] = None,
    right: Optional["npt.ArrayLike"] = None,
) -> TimeIndexedData:
    """Interpolate points between a given TimeIndexedData object.

    For ndim > 1 the interpolation is performed element-wise. Note that because the time scales
    in `time_index` and `data` are unrelated we use constant time units to perform the
    interpolation. As an illuminating example, imagine that the granularity of `data` is "business
    days", and `data` contains entries for a Friday and a Tuesday. If we interpolate a value for
    Monday, it will be 75% between the Friday value and the Tuesday value, even though Monday is
    exactly half way between Friday and Tuesday in the time scale of `data`.

    Parameters
    ----------
    time_index: TimeIndex
        The points to perform the interpolation. The output TimeIndexedData
        will have this as the TimeIndex.
    data: TimeIndexedData
        The observed data to interpolate between
    interp: str, default "linear"
        One of "linear", "left", "right", "nearest", or "nan". "linear" specifies a linear
        interpolation. "left" will reflect the closest value <= the target time; "right" will
        reflect the closest value >= the target time. "nearest" places the step halfway between
        observations and will choose the closer of the two values. If interp is "nan" then np.nan
        will be used to fill all missing values (`left` and `right` settings will be ignored)
    left: Optional[npt.ArrayLike], default None
        Value to return when t is less than the first time value in data. Default is data.values[0]
    right: Optional[npt.ArrayLike], default None
        Value to return when t is greater than the last time value in data. Default is
        data.values[-1]

    Returns
    -------
    TimeIndexedData
        A new object with the provided time_index and interpolated values. Column names are carried
        over from `data`
    """
    if len(data) == 0:
        raise ValueError("Cannot interpolate from an empty time series")

    interp = interp.lower()
    if interp not in {"linear", "left", "right", "nearest", "nan"}:
        raise ValueError(f"Unexpected interpolation: {interp}")

    # Correct shapes
    shape = data.values[0].shape
    reshaped_nan = _correct_shape(np.nan, shape)
    left = _correct_shape(left, shape) if left is not None else data.values[0]
    right = _correct_shape(right, shape) if right is not None else data.values[-1]

    t_values = time_index.timestamp_values
    t_obs = data.time_index.timestamp_values
    idx = np.searchsorted(t_obs, t_values)

    new_values = []
    for i, t in zip(idx, t_values):
        if 0 <= i < len(t_obs) and t_obs[i] == t:
            new_values.append(data.values[i])
        elif interp == "nan":
            new_values.append(reshaped_nan)
        elif t < t_obs[0]:
            new_values.append(left)
        elif t > t_obs[-1]:
            new_values.append(right)
        elif interp == "left":
            new_values.append(data.values[i - 1])
        elif interp == "right":
            new_values.append(data.values[i])
        elif interp == "nearest":
            new_values.append(
                data.values[i - 1] if abs(t - t_obs[i - 1]) < abs(t - t_obs[i]) else data.values[i]
            )
        else:
            tl, tr = t_obs[i - 1], t_obs[i]
            vl, vr = data.values[i - 1], data.values[i]
            pct = (t - tl) / (tr - tl)
            new_values.append((pct * (vr - vl)) + vl)

    if len(new_values) == 0 and data.values.ndim > 1:
        new_values = np.empty((0,) + data.values.shape[1:], dtype=np.float64)

    return TimeIndexedData(
        time_index.timestamp_values,
        new_values,
        column_names=data.column_names,
        granularity=time_index.granularity,
        unixtime_t0=time_index.unixtime_t0,
        unixtime_unit=time_index.unixtime_unit,
    )


def temporal_split(data: TimeIndexedData, p: float) -> Tuple[TimeIndexedData, TimeIndexedData]:
    """Split a single TimeIndexedData object into a past / future objects.

    Parameters
    ----------
    data: TimeIndexedData
        The data to split
    p: float
        The fraction of data that will go into the left half of the split. E.g. 0.7 will create
        a 70/30 split.

    Returns
    -------
    Tuple[TimeIndexedData, TimeIndexedData]
        The past and future TimeIndexedData objects.
    """
    if p < 0 or p > 1:
        raise ValueError("Split fraction must be a value in [0, 1]")
    slice_end = int(len(data) * p)
    return (data.slice(0, slice_end), data.slice(slice_end))


def load_multi_from_pandas(
    df: pd.DataFrame,
    value_sets: List[List[str]],
    time_col: Optional[str] = None,
    granularity: Optional[TimeUnit] = None,
    unixtime_t0: pd.Timestamp = EPOCH_TIME_NO_TZ,
    unixtime_unit: pd.Timedelta = ONE_SECOND,
) -> Tuple[TimeIndexedData, ...]:
    """Load multiple TimeIndexedData objects from a single pandas dataframe

    Each TimeIndexedData object will contain one entry per row in the dataframe, and a subset
    of the columns. The number of objects returned will be the same length as `value_sets`

    Parameters
    ----------
    df: pd.DataFrame
        A dataframe
    value_sets: List[List[str]]
        The columns to extract for each of the returned TimeIndexedData objects.
    time_col: Optional[str], default None
        The column of the dataframe containing the time variable. If not provided, then the
        index of the dataframe is used. The entries of `time_col` should be one of the
        acceptable `TimeStamp` types or integers.
    granularity: Optional[TimeUnit], default None
        The granularity of the time series. If not provided, TimeIndexedData will attempt to
        determine a reasonable granularity value given the input.
    unixtime_t0: pd.Timestamp, default pd.Timestamp('1970-01-01 00:00:00')
        Time zero; used by the TimeIndex to provide unambiguous conversions between integers
        and timestamps.
    unixtime_unit: pd.Timedelta, default pd.Timedelta(seconds=1)
        The unit used by the TimeIndex to provide unambiguous conversions between integers and
        timestamps.

    Returns
    -------
    Tuple[TimeIndexedData, ...]
        A tuple of TimeIndexedData objects with the same length of `value_sets`.
    """
    return tuple(
        TimeIndexedData.from_pandas(
            df,
            cols,
            time_col=time_col,
            granularity=granularity,
            unixtime_t0=unixtime_t0,
            unixtime_unit=unixtime_unit,
        )
        for cols in value_sets
    )


def to_utc(ts: TimeStamp) -> pd.Timestamp:
    """Convert a TimeStamp to UTC

    Parameters
    ----------
    ts: TimeStamp
        The input data

    Returns
    -------
    pd.Timestamp
        A timestamp with UTC timezone. TimeStamp will first be converted to pd.Timestamp. If no
        tzinfo is present then <UTC> tzinfo will be added without changing the timestamp values.
        Otherwise tz_convert will be used to convert the input timestamp to UTC. The result will
        always have tzinfo = pytz.UTC()
    """
    pdt = pd.Timestamp(ts)
    if pdt.tzinfo is None:
        return pdt.tz_localize("UTC")
    return pdt.tz_convert("UTC")


def is_univariate(data: TimeIndexedData) -> bool:
    return len(data.column_names) == 1 and data.values.ndim < 3


def prophet_future_dataframe(
    data: Union[TimeIndex, TimeIndexedData], *, time_col: str = "ds", value_col: str = "y"
) -> pd.DataFrame:
    """Create a prophet-style "future" dataframe

    A future dataframe is a dataframe with "ds" as the time column and optional regressor columns.

    Parameters
    ----------
    data: Union[TimeIndex, TimeIndexedData]
        ds (the time index) and optional regressors
    time_col: str
        time column name, by default "ds"
    value_col: str
        value column name, by default "y"

    Returns
    -------
    pd.DataFrame
    """
    if isinstance(data, TimeIndexedData):
        ds, covariates = data.time_index, data
    else:
        ds, covariates = data, None

    return prophet_style_dataframe(ds, covariates, time_col=time_col, value_col=value_col)


def prophet_style_dataframe(
    data: Union[TimeIndex, TimeIndexedData],
    covariates: Optional[TimeIndexedData] = None,
    *,
    time_col: str = "ds",
    value_col: str = "y",
) -> pd.DataFrame:
    """Create a Prophet-style dataframe with data and covariates

    A Prophet-style dataframe is a univariate time series with "ds" as the time column name and
    "y" as the observable column name (if provided). All of the columns from `covariates` are
    included as extra regressor columns.

    Parameters
    ----------
    data: Union[TimeIndex, TimeIndexedData]
        The observable columns. If a TimeIndex is provided then only the `time_col` column will
        be populated, not the `value_col` column. This is useful for generating future dataframes.
    covariates: Optional[TimeIndexedData], default None
        If applicalble, a set of extra regressors.
    time_col: str
        time column name, by default "ds"
    value_col: str
        value column name, by default "y"

    Returns
    -------
    pd.DataFrame

    Raises
    ------
    ValueError
        If `data` is multivariate, or the `covariate` time index does not match the one from
        `data`, or any regressors are named `time_col` or `value_col`.
    """
    obs_col, regressor_cols = {}, {}

    if isinstance(data, TimeIndexedData):
        if not is_univariate(data):
            raise ValueError("Expecting univariate time series data")
        obs_col = {value_col: data.values.flatten()}

    if covariates is not None:
        index = data if isinstance(data, TimeIndex) else data.time_index
        if not index.values_match(covariates.time_index):
            raise ValueError("Covariate time index does not match expected")
        if any(c in (time_col, value_col) for c in covariates.column_names):
            raise ValueError(f"Regressors cannot be named {time_col} or {value_col}")
        regressor_cols = {c: covariates[c].flatten() for c in covariates.column_names}

    time_col = {time_col: data.pd_timestamp_index()}

    union = {}
    for d in (obs_col, time_col, regressor_cols):
        union.update(d)

    return pd.DataFrame(union)


def clip(data: TimeIndexedData, lower: float, upper: float) -> TimeIndexedData:
    """Clip (limit) the values in an TimeIndexedData object

    Given an interval, values outside the interval are clipped to the interval edges. For example,
    if an interval of [0, 1] is specified, values smaller than 0 become 0, and values larger than
    1 become 1.

    Parameters
    ----------
    data: TimeIndexedData
        A time series
    lower: float
        The value below which entries in `data` will be truncated.
    upper: float
        The value above which entries in `data` will be truncated.

    Returns
    -------
    TimeIndexedData
        The clipped time series
    """
    return TimeIndexedData.from_time_index(
        data.time_index,
        np.clip(data.values, lower, upper),
        column_names=data.column_tuples,
    )


def sliding_window(
    data: TimeIndexedData,
    window_size: int,
    mask: Optional[List[Union[int, bool]]] = None,
) -> TimeIndexedData:
    """Create a sliding window view of `data`

    Parameters
    ----------
    data: TimeIndexedData
        A time series with shape (T, ...)
    window_size: int
        The size of the sliding window (will be applied along the time axis)
    mask: Optional[List[Union[int, bool]]], default None
        An optional mask to apply to the results of the sliding window. E.g. the combination
        `window_size=4, mask=[True, True, False, True]` will return LAG(3), LAG(2) and the current
        row.

    Returns
    -------
    TimeIndexedData
        A new time series where each entry has an optionally masked sliding window. `values` will
        be expanded to at least 3 dimensions in order to preserve column names before/after the
        sliding window.
    """
    pad_width = np.zeros((data.values.ndim, 2), dtype=int)
    pad_width[0][0] = window_size - 1
    new_values = np.lib.stride_tricks.sliding_window_view(
        np.pad(data.values, pad_width, constant_values=np.nan),
        window_size,
        axis=0,
    )
    if data.values.ndim < 2:
        # Expand dimensions to preserve column names
        new_values = np.expand_dims(new_values, 1)
    if mask:
        new_values = new_values[..., mask]

    return TimeIndexedData.from_time_index(
        data.time_index,
        new_values,
        data.column_names,
    )


def time_based_regressors(
    data: Union[TimeIndex, TimeIndexedData],
    time_regressor: str = "t",
    one_hot_encode: bool = False,
    add_intercept: bool = False,
    intercept_name: str = "b",
) -> TimeIndexedData:
    """Construct a new object of time-based regressors

    The resulting object will have the following columns if `one_hot_encode` is False:

    `time_regressor`: The integer values from the TimeIndex
    hour_of_day: A number between 0 and 23
    day_of_week: The day of the week with Monday=0, Sunday=6.
    month_of_year: The month of the year with January=1, December=12.

    If `one_hot_encode` is True, then the `hour_of_day`, `day_of_week` and `month_of_year` columns
    will be one-hot encoded and provided names

    `hour_of_day_0`, `hour_of_day_1`, ...
    `day_of_week_0, `day_of_week_1`, ...
    `month_of_year_1`, `month_of_year_2`, ...

    Parameters
    ----------
    data: Union[TimeIndex, TimeIndexedData]
        The time index to use for the regressors. If a TimeIndexedData object is provided, then the
        time index from that object will be used.
    time_regressor: str, default "t"
        The name of the time regressor column
    one_hot_encode: bool, default False
        If True, then the hour_of_day, day_of_week, and month_of_year columns will be one-hot
        encoded.
    add_intercept: bool, default False
        If True, then an intercept column will be added to the regressors
    intercept_name: str, default "b"
        The name of the intercept column, if `add_intercept` is True.

    Returns
    -------
    TimeIndexedData
        A new TimeIndexedData object with the time-based regressors
    """
    if isinstance(data, TimeIndexedData):
        data = data.time_index

    if one_hot_encode:
        cols = (
            [time_regressor]
            + ["hour_of_day_" + str(i) for i in range(24)]
            + ["day_of_week_" + str(i) for i in range(7)]
            + ["month_of_year_" + str(i) for i in range(1, 13)]
        )
        values = [
            [int_t]
            + [int(ts.hour == i) for i in range(24)]
            + [int(ts.dayofweek == i) for i in range(7)]
            + [int(ts.month == i) for i in range(1, 13)]
            for int_t, ts in zip(data.int_values, data.timestamp_values)
        ]
        varying_data = TimeIndexedData.from_time_index(
            data,
            np.array(values, dtype=np.float64).reshape(len(data), len(cols)),
            column_names=cols,
        )
    else:
        values = [
            [int_t, t.hour, t.dayofweek, t.month]
            for int_t, t in zip(data.int_values, data.timestamp_values)
        ]
        cols = [time_regressor, "hour_of_day", "day_of_week", "month_of_year"]
        varying_data = TimeIndexedData.from_time_index(
            data,
            np.array(values, dtype=np.float64).reshape(len(data), len(cols)),
            column_names=cols,
        )

    if add_intercept:
        intercept = TimeIndexedData.from_time_index(
            data,
            np.ones(len(data), dtype=np.float64),
            column_names=[intercept_name],
        )
        return intercept.merge(varying_data)

    return varying_data


def _correct_shape(value: "npt.ArrayLike", shape: Tuple[int, ...]) -> FloatTensor:
    """Create a FloatTensor from an array with a compatible shape.

    Parameters
    ----------
    value: npt.ArrayLike
        A scalar or array to cast to the proper shape
    shape: Tuple[int, ...]
        The desired output shape

    Returns
    -------
    FloatTensor
        An NDArray filled with the value (see numpy's broadcasting rules:
        https://numpy.org/doc/stable/user/basics.broadcasting.html) with dtype=np.float64
    """
    value = np.array(value)
    in_shape = value.shape
    extra_dims = len(shape) - len(in_shape)
    if extra_dims > 0:
        new_shape = in_shape + tuple(1 for _ in range(extra_dims))
        value = value.reshape(new_shape)

    return (np.ones(shape) * np.array(value)).astype(np.float64)
